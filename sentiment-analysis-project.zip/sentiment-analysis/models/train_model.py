"""
models/train_model.py
---------------------
Train a custom TF-IDF + Logistic Regression sentiment classifier.

Steps:
  1. Load labeled data (Amazon, Twitter, or News CSV)
  2. Preprocess text
  3. Extract TF-IDF features
  4. Train + evaluate Logistic Regression model
  5. Save model for inference

Usage:
  python models/train_model.py --data data/sample_reviews.csv --label_col label
"""

import argparse
import sys
import os
import pickle
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import (
    classification_report, confusion_matrix,
    accuracy_score, f1_score
)
from sklearn.pipeline import Pipeline
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
from preprocessor import TextPreprocessor

MODEL_DIR = Path(__file__).parent
MODEL_DIR.mkdir(exist_ok=True)


# ------------------------------------------------------------------ #
#  Feature engineering                                                 #
# ------------------------------------------------------------------ #

class SentimentTFIDF:
    """TF-IDF feature extractor with n-grams."""

    def __init__(self):
        self.vectorizer = TfidfVectorizer(
            ngram_range=(1, 3),   # unigrams, bigrams, trigrams
            max_features=50_000,
            min_df=2,
            max_df=0.95,
            sublinear_tf=True,    # log TF scaling
            analyzer="word",
            token_pattern=r"\b[a-zA-Z][a-zA-Z0-9']+\b",
        )

    def fit_transform(self, texts):
        return self.vectorizer.fit_transform(texts)

    def transform(self, texts):
        return self.vectorizer.transform(texts)


# ------------------------------------------------------------------ #
#  Training                                                            #
# ------------------------------------------------------------------ #

def preprocess_texts(texts: list, mode: str = "generic") -> list:
    pp = TextPreprocessor(mode=mode, remove_stopwords=False)
    return [pp.clean(t) for t in texts]


def train_and_evaluate(X_train, X_test, y_train, y_test):
    """Train multiple models and pick the best."""
    models = {
        "Logistic Regression": LogisticRegression(
            C=5.0, max_iter=1000, multi_class="multinomial", solver="lbfgs"),
        "Linear SVM": LinearSVC(C=1.0, max_iter=2000),
        "Naive Bayes": MultinomialNB(alpha=0.1),
    }

    best_model = None
    best_f1    = 0.0
    results    = {}

    for name, model in models.items():
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        acc = accuracy_score(y_test, y_pred)
        f1  = f1_score(y_test, y_pred, average="macro")
        results[name] = {"accuracy": acc, "f1": f1, "model": model, "y_pred": y_pred}
        print(f"\n[{name}]  Accuracy: {acc:.4f}  |  Macro F1: {f1:.4f}")

        if f1 > best_f1:
            best_f1    = f1
            best_model = (name, model)

    print(f"\n🏆 Best model: {best_model[0]} (F1={best_f1:.4f})")
    return best_model[1], results


def plot_confusion_matrix(y_true, y_pred, labels, filename: str):
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    fig, ax = plt.subplots(figsize=(7, 5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=labels, yticklabels=labels,
                linewidths=0.5, ax=ax)
    ax.set_title("Confusion Matrix", fontsize=14, pad=12)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    fig.savefig(filename, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  ✓ Confusion matrix → {filename}")


def plot_feature_importance(vectorizer, model, top_n: int = 20, filename: str = "features.png"):
    """Show most influential TF-IDF features per class."""
    if not hasattr(model, "coef_"):
        print("  (Feature importance not available for this model)")
        return

    feature_names = vectorizer.get_feature_names_out()
    classes = model.classes_

    n_classes = len(classes)
    fig, axes = plt.subplots(1, n_classes, figsize=(6 * n_classes, 8))
    if n_classes == 1:
        axes = [axes]

    for ax, cls, coefs in zip(axes, classes, model.coef_):
        top_idx  = np.argsort(coefs)[-top_n:]
        top_feat = feature_names[top_idx]
        top_coef = coefs[top_idx]

        ax.barh(range(top_n), top_coef, color="#3B82F6", edgecolor="none")
        ax.set_yticks(range(top_n))
        ax.set_yticklabels(top_feat, fontsize=9)
        ax.set_title(f"Top features — {cls}", fontsize=12)
        ax.grid(axis="x", alpha=0.3)

    fig.tight_layout()
    fig.savefig(filename, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  ✓ Feature importance → {filename}")


# ------------------------------------------------------------------ #
#  Save / Load                                                         #
# ------------------------------------------------------------------ #

def save_model(model, vectorizer, metadata: dict, name: str = "sentiment_model"):
    path = MODEL_DIR / f"{name}.pkl"
    payload = {"model": model, "vectorizer": vectorizer, "metadata": metadata}
    with open(path, "wb") as f:
        pickle.dump(payload, f)
    print(f"\n✓ Model saved → {path}")
    return path


def load_model(name: str = "sentiment_model"):
    path = MODEL_DIR / f"{name}.pkl"
    with open(path, "rb") as f:
        payload = pickle.load(f)
    return payload["model"], payload["vectorizer"], payload["metadata"]


# ------------------------------------------------------------------ #
#  Inference helper                                                    #
# ------------------------------------------------------------------ #

class TrainedPredictor:
    """Lightweight wrapper around a saved model for inference."""

    def __init__(self, model_name: str = "sentiment_model"):
        self.model, self.vectorizer, self.meta = load_model(model_name)
        self.preprocessor = TextPreprocessor(mode=self.meta.get("mode", "generic"))

    def predict(self, text: str) -> dict:
        cleaned = self.preprocessor.clean(text)
        X = self.vectorizer.transform([cleaned])
        label = self.model.predict(X)[0]

        # Probability if available
        confidence = None
        if hasattr(self.model, "predict_proba"):
            proba = self.model.predict_proba(X)[0]
            confidence = float(max(proba))
        elif hasattr(self.model, "decision_function"):
            scores = self.model.decision_function(X)[0]
            confidence = float(np.exp(max(scores)) / np.sum(np.exp(scores)))

        return {"label": label, "confidence": confidence, "cleaned_text": cleaned}


# ------------------------------------------------------------------ #
#  CLI                                                                 #
# ------------------------------------------------------------------ #

def generate_synthetic_data(n: int = 500) -> pd.DataFrame:
    """Create a labeled dataset when no real data is provided."""
    import random
    random.seed(42)

    pos_texts = [
        "This product is absolutely amazing and I love it!",
        "Best purchase ever, exceeded all my expectations!",
        "Incredible quality, fast shipping, highly recommend!",
        "Very happy with this product. Works perfectly.",
        "Outstanding! Will definitely buy again.",
    ]
    neg_texts = [
        "Terrible quality, broke after one day. Total waste of money.",
        "Very disappointed. Does not work as advertised at all.",
        "Worst product I ever bought. Returning immediately.",
        "Absolutely awful. Do not buy this garbage.",
        "Complete scam. Nothing like the description.",
    ]
    neu_texts = [
        "It's an okay product. Does what it's supposed to.",
        "Average quality. Neither good nor bad.",
        "Item arrived on time. Nothing special about it.",
        "It works. Not amazing but not terrible either.",
        "Decent product for the price. Fairly standard.",
    ]

    rows = []
    for _ in range(n // 3):
        rows.append({"review_text": random.choice(pos_texts), "label": "POSITIVE"})
        rows.append({"review_text": random.choice(neg_texts), "label": "NEGATIVE"})
        rows.append({"review_text": random.choice(neu_texts), "label": "NEUTRAL"})

    df = pd.DataFrame(rows).sample(frac=1, random_state=42).reset_index(drop=True)
    return df


def main():
    parser = argparse.ArgumentParser(description="Train sentiment classifier")
    parser.add_argument("--data",      type=str, default=None, help="Path to labeled CSV")
    parser.add_argument("--text_col",  type=str, default="review_text")
    parser.add_argument("--label_col", type=str, default="label")
    parser.add_argument("--source",    type=str, default="amazon")
    parser.add_argument("--test_size", type=float, default=0.2)
    parser.add_argument("--output",    type=str, default="sentiment_model")
    args = parser.parse_args()

    print("🧠 Sentiment Classifier Training\n" + "="*40)

    # Load data
    if args.data and os.path.exists(args.data):
        df = pd.read_csv(args.data)
        print(f"✓ Loaded {len(df)} rows from {args.data}")
    else:
        print("⚠ No data file provided. Using synthetic data for demonstration.")
        df = generate_synthetic_data(600)

    print(f"\nLabel distribution:\n{df[args.label_col].value_counts()}")

    # Preprocess
    print("\n📝 Preprocessing texts...")
    df["cleaned"] = preprocess_texts(df[args.text_col].astype(str).tolist(), args.source)

    # Features
    print("🔢 Extracting TF-IDF features...")
    tfidf = SentimentTFIDF()
    X = tfidf.fit_transform(df["cleaned"])
    y = df[args.label_col]

    # Split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=args.test_size, random_state=42, stratify=y)
    print(f"  Train: {X_train.shape[0]} | Test: {X_test.shape[0]}")

    # Train
    print("\n🏋️ Training models...")
    best_model, all_results = train_and_evaluate(X_train, X_test, y_train, y_test)

    # Full report
    best_name = max(all_results, key=lambda k: all_results[k]["f1"])
    y_pred    = all_results[best_name]["y_pred"]
    labels    = sorted(y.unique().tolist())

    print("\n📊 Classification Report:")
    print(classification_report(y_test, y_pred, target_names=labels))

    # Plots
    chart_dir = "static/charts"
    os.makedirs(chart_dir, exist_ok=True)
    plot_confusion_matrix(y_test, y_pred, labels, f"{chart_dir}/confusion_matrix.png")
    plot_feature_importance(tfidf.vectorizer, best_model, filename=f"{chart_dir}/feature_importance.png")

    # Save
    metadata = {
        "mode": args.source,
        "classes": labels,
        "train_size": int(X_train.shape[0]),
        "test_size": int(X_test.shape[0]),
        "accuracy": round(accuracy_score(y_test, y_pred), 4),
        "f1_macro": round(f1_score(y_test, y_pred, average="macro"), 4),
    }
    save_model(best_model, tfidf.vectorizer, metadata, args.output)

    print("\n✅ Training complete!")
    print(f"   Accuracy : {metadata['accuracy']:.4f}")
    print(f"   F1 Macro : {metadata['f1_macro']:.4f}")


if __name__ == "__main__":
    main()
