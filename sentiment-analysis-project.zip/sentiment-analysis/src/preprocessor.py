"""
preprocessor.py
---------------
Text cleaning and normalization pipeline for sentiment analysis.
Handles Amazon reviews, tweets, and news articles.
"""

import re
import string
import nltk
import emoji
import contractions
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize

# Download required NLTK resources (run once)
for resource in ["stopwords", "punkt", "wordnet", "averaged_perceptron_tagger"]:
    try:
        nltk.download(resource, quiet=True)
    except Exception:
        pass

STOP_WORDS = set(stopwords.words("english"))
LEMMATIZER = WordNetLemmatizer()

# Sentiment-important words to KEEP even if they're stop words
SENTIMENT_KEEP = {
    "not", "no", "never", "neither", "nor", "but", "however",
    "very", "extremely", "absolutely", "totally", "quite",
    "hardly", "barely", "scarcely", "against"
}
FILTERED_STOPS = STOP_WORDS - SENTIMENT_KEEP


class TextPreprocessor:
    """
    Multi-mode text preprocessor.
    Modes: 'amazon', 'twitter', 'news', 'generic'
    """

    def __init__(self, mode: str = "generic", remove_stopwords: bool = False):
        self.mode = mode
        self.remove_stopwords = remove_stopwords

    def clean(self, text: str) -> str:
        """Full cleaning pipeline."""
        if not isinstance(text, str) or not text.strip():
            return ""

        text = self._decode_emojis(text)
        text = self._expand_contractions(text)
        text = self._remove_noise(text)
        text = self._normalize_whitespace(text)

        if self.remove_stopwords:
            text = self._filter_stopwords(text)

        return text.strip()

    def tokenize(self, text: str) -> list:
        """Tokenize cleaned text into word list."""
        cleaned = self.clean(text)
        tokens = word_tokenize(cleaned.lower())
        tokens = [LEMMATIZER.lemmatize(t) for t in tokens if t.isalpha()]
        return tokens

    # ------------------------------------------------------------------ #
    #  Private helpers                                                     #
    # ------------------------------------------------------------------ #

    def _decode_emojis(self, text: str) -> str:
        """Convert emojis to descriptive text (e.g. 😊 → ':smiling_face:')."""
        return emoji.demojize(text, delimiters=(" ", " "))

    def _expand_contractions(self, text: str) -> str:
        """Expand contractions: don't → do not, I'm → I am."""
        try:
            return contractions.fix(text)
        except Exception:
            return text

    def _remove_noise(self, text: str) -> str:
        """Remove URLs, mentions, hashtags, HTML tags, and special chars."""
        # URLs
        text = re.sub(r"http\S+|www\.\S+", "", text)
        # HTML tags
        text = re.sub(r"<[^>]+>", "", text)

        if self.mode == "twitter":
            # Remove @mentions but keep hashtag words
            text = re.sub(r"@\w+", "", text)
            text = re.sub(r"#(\w+)", r"\1", text)  # keep word, drop #
            # Remove RT prefix
            text = re.sub(r"^RT[\s]+", "", text)

        # Repeated punctuation → single (e.g. !!! → !)
        text = re.sub(r"([!?.]){2,}", r"\1", text)
        # Elongated words (e.g. sooooo → so)
        text = re.sub(r"(.)\1{2,}", r"\1\1", text)
        # Remove non-ASCII
        text = text.encode("ascii", "ignore").decode("ascii")
        # Remove remaining special characters (keep apostrophes)
        text = re.sub(r"[^a-zA-Z0-9\s'!?.,]", " ", text)

        return text

    def _normalize_whitespace(self, text: str) -> str:
        return re.sub(r"\s+", " ", text).strip()

    def _filter_stopwords(self, text: str) -> str:
        words = text.split()
        return " ".join(w for w in words if w.lower() not in FILTERED_STOPS)


# ------------------------------------------------------------------ #
#  CLI usage                                                           #
# ------------------------------------------------------------------ #
if __name__ == "__main__":
    samples = [
        "I absolutely LOVED this product!!! 😍 It's amazing!! Buy it NOW → http://amzn.com",
        "@JohnDoe I can't believe how bad this is 😤 #disappointed #worstever",
        "The CEO announced today that profits won't decline despite challenges...",
    ]

    for mode, text in zip(["amazon", "twitter", "news"], samples):
        pp = TextPreprocessor(mode=mode)
        print(f"\n[{mode.upper()}]")
        print(f"  Raw    : {text}")
        print(f"  Cleaned: {pp.clean(text)}")
        print(f"  Tokens : {pp.tokenize(text)}")
