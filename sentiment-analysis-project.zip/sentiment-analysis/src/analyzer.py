"""
analyzer.py
-----------
Core sentiment analysis engine combining:
  1. VADER  — rule-based, great for social media
  2. TextBlob — lexicon polarity & subjectivity
  3. HuggingFace Transformers — deep-learning classifier (optional)

Usage:
  python src/analyzer.py --text "I love this product!"
  python src/analyzer.py --file data/sample_reviews.csv --source amazon
"""

import argparse
import json
import time
import warnings
from dataclasses import dataclass, asdict
from typing import Optional

import pandas as pd
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from textblob import TextBlob

from preprocessor import TextPreprocessor

warnings.filterwarnings("ignore")

# ------------------------------------------------------------------ #
#  Data classes                                                        #
# ------------------------------------------------------------------ #

@dataclass
class SentimentResult:
    text: str
    cleaned_text: str
    label: str            # POSITIVE / NEGATIVE / NEUTRAL
    confidence: float     # 0.0 – 1.0
    polarity: float       # -1.0 to +1.0
    subjectivity: float   # 0.0 (objective) to 1.0 (subjective)
    vader_compound: float
    method: str           # vader | textblob | ensemble | transformer
    processing_ms: float

    def to_dict(self):
        return asdict(self)

    def summary(self) -> str:
        bar = "█" * int(self.confidence * 20) + "░" * (20 - int(self.confidence * 20))
        emoji = {"POSITIVE": "😊", "NEGATIVE": "😠", "NEUTRAL": "😐"}[self.label]
        return (
            f"\n{'='*55}\n"
            f"  {emoji}  Sentiment  : {self.label} ({self.confidence:.0%})\n"
            f"  [{bar}]\n"
            f"  Polarity     : {self.polarity:+.3f}\n"
            f"  Subjectivity : {self.subjectivity:.3f}\n"
            f"  VADER score  : {self.vader_compound:+.3f}\n"
            f"  Method       : {self.method}\n"
            f"  Time         : {self.processing_ms:.1f} ms\n"
            f"{'='*55}"
        )


# ------------------------------------------------------------------ #
#  Analyzer                                                            #
# ------------------------------------------------------------------ #

class SentimentAnalyzer:
    """
    Ensemble sentiment analyzer.

    Parameters
    ----------
    mode : str
        Source mode — 'amazon' | 'twitter' | 'news' | 'generic'
    use_transformer : bool
        If True, loads a pre-trained HuggingFace model for higher accuracy.
        Requires ~500 MB download on first run.
    """

    VADER_THRESHOLD_POS = 0.05
    VADER_THRESHOLD_NEG = -0.05

    def __init__(self, mode: str = "generic", use_transformer: bool = False):
        self.mode = mode
        self.preprocessor = TextPreprocessor(mode=mode)
        self.vader = SentimentIntensityAnalyzer()
        self._transformer = None

        if use_transformer:
            self._load_transformer()

    # ---------------------------------------------------------------- #
    #  Public API                                                       #
    # ---------------------------------------------------------------- #

    def analyze(self, text: str) -> SentimentResult:
        """Analyze a single piece of text."""
        t0 = time.time()
        cleaned = self.preprocessor.clean(text)

        if self._transformer:
            result = self._transformer_predict(text, cleaned)
            method = "transformer"
        else:
            result = self._ensemble_predict(cleaned)
            method = "ensemble (VADER + TextBlob)"

        result.text = text
        result.cleaned_text = cleaned
        result.method = method
        result.processing_ms = (time.time() - t0) * 1000
        return result

    def analyze_batch(self, texts: list, show_progress: bool = True) -> list:
        """Analyze a list of texts, returns list of SentimentResult."""
        from tqdm import tqdm
        iterator = tqdm(texts, desc="Analyzing") if show_progress else texts
        return [self.analyze(t) for t in iterator]

    def analyze_dataframe(self, df: pd.DataFrame, text_col: str) -> pd.DataFrame:
        """
        Analyze a full DataFrame, appending sentiment columns.
        Returns enriched DataFrame.
        """
        results = self.analyze_batch(df[text_col].astype(str).tolist())
        sentiment_df = pd.DataFrame([r.to_dict() for r in results])

        # Drop duplicate text columns
        sentiment_df = sentiment_df.drop(columns=["text", "cleaned_text"], errors="ignore")

        return pd.concat([df.reset_index(drop=True), sentiment_df], axis=1)

    # ---------------------------------------------------------------- #
    #  Prediction logic                                                 #
    # ---------------------------------------------------------------- #

    def _ensemble_predict(self, cleaned: str) -> SentimentResult:
        """Combine VADER and TextBlob scores via weighted average."""
        # --- VADER ---
        vader_scores = self.vader.polarity_scores(cleaned)
        v_compound = vader_scores["compound"]
        v_pos = vader_scores["pos"]
        v_neg = vader_scores["neg"]

        # --- TextBlob ---
        blob = TextBlob(cleaned)
        tb_polarity = blob.sentiment.polarity       # -1 to +1
        tb_subjectivity = blob.sentiment.subjectivity  # 0 to 1

        # --- Weighted ensemble polarity ---
        # VADER is slightly more reliable for social media, TextBlob for formal text
        weight_vader = 0.6 if self.mode in ("twitter", "amazon") else 0.4
        weight_tb = 1 - weight_vader
        combined = weight_vader * v_compound + weight_tb * tb_polarity

        # --- Label ---
        if combined >= self.VADER_THRESHOLD_POS:
            label = "POSITIVE"
            confidence = min(0.5 + abs(combined) * 0.5, 0.99)
        elif combined <= self.VADER_THRESHOLD_NEG:
            label = "NEGATIVE"
            confidence = min(0.5 + abs(combined) * 0.5, 0.99)
        else:
            label = "NEUTRAL"
            confidence = 1.0 - abs(combined) * 2  # higher when truly near 0

        confidence = round(max(confidence, 0.50), 3)

        return SentimentResult(
            text="",
            cleaned_text=cleaned,
            label=label,
            confidence=confidence,
            polarity=round(combined, 4),
            subjectivity=round(tb_subjectivity, 4),
            vader_compound=round(v_compound, 4),
            method="",
            processing_ms=0.0,
        )

    def _load_transformer(self):
        """Load HuggingFace distilbert sentiment model."""
        try:
            from transformers import pipeline
            print("Loading transformer model (first run may download ~250MB)...")
            self._transformer = pipeline(
                "sentiment-analysis",
                model="distilbert-base-uncased-finetuned-sst-2-english",
                truncation=True,
                max_length=512,
            )
            print("✓ Transformer model loaded.")
        except ImportError:
            print("⚠ transformers not installed. Falling back to ensemble.")
            self._transformer = None

    def _transformer_predict(self, raw: str, cleaned: str) -> SentimentResult:
        """Run HuggingFace pipeline and align with our output format."""
        output = self._transformer(cleaned[:512])[0]
        label_map = {"POSITIVE": "POSITIVE", "NEGATIVE": "NEGATIVE"}
        label = label_map.get(output["label"], "NEUTRAL")
        confidence = round(output["score"], 3)
        polarity = confidence if label == "POSITIVE" else -confidence

        blob = TextBlob(cleaned)
        vader_scores = self.vader.polarity_scores(cleaned)

        return SentimentResult(
            text=raw,
            cleaned_text=cleaned,
            label=label,
            confidence=confidence,
            polarity=polarity,
            subjectivity=round(blob.sentiment.subjectivity, 4),
            vader_compound=round(vader_scores["compound"], 4),
            method="",
            processing_ms=0.0,
        )


# ------------------------------------------------------------------ #
#  CSV file analysis helper                                            #
# ------------------------------------------------------------------ #

def analyze_csv(filepath: str, source: str, text_col: str = None) -> pd.DataFrame:
    """Load a CSV and run sentiment analysis."""
    df = pd.read_csv(filepath)

    # Auto-detect text column
    if text_col is None:
        candidates = ["review_text", "text", "tweet", "content", "body", "title", "comment"]
        for col in candidates:
            if col in df.columns:
                text_col = col
                break
        if text_col is None:
            text_col = df.columns[0]

    print(f"✓ Loaded {len(df)} rows | Text column: '{text_col}'")
    analyzer = SentimentAnalyzer(mode=source)
    result_df = analyzer.analyze_dataframe(df, text_col)

    out_path = filepath.replace(".csv", "_analyzed.csv")
    result_df.to_csv(out_path, index=False)
    print(f"✓ Results saved to: {out_path}")

    # Summary
    counts = result_df["label"].value_counts()
    print("\n📊 Sentiment Distribution:")
    for label, count in counts.items():
        pct = count / len(result_df) * 100
        bar = "█" * int(pct / 5)
        print(f"  {label:10s}: {bar} {count} ({pct:.1f}%)")

    return result_df


# ------------------------------------------------------------------ #
#  CLI                                                                 #
# ------------------------------------------------------------------ #

def main():
    parser = argparse.ArgumentParser(description="Sentiment Analysis Engine")
    parser.add_argument("--text", type=str, help="Analyze a single text string")
    parser.add_argument("--file", type=str, help="Path to CSV file")
    parser.add_argument("--col", type=str, default=None, help="Text column name in CSV")
    parser.add_argument("--source", type=str, default="generic",
                        choices=["amazon", "twitter", "news", "generic"],
                        help="Data source type")
    parser.add_argument("--transformer", action="store_true",
                        help="Use HuggingFace transformer (slower, more accurate)")
    args = parser.parse_args()

    if args.text:
        analyzer = SentimentAnalyzer(mode=args.source, use_transformer=args.transformer)
        result = analyzer.analyze(args.text)
        print(result.summary())

    elif args.file:
        analyze_csv(args.file, args.source, args.col)

    else:
        # Demo mode
        print("\n🧠 Sentiment Analysis Engine — Demo\n")
        samples = [
            ("amazon",  "This product exceeded all my expectations! Best purchase ever. Highly recommend!"),
            ("amazon",  "Broke after 3 days. Terrible quality, don't waste your money on this garbage."),
            ("twitter", "Just watched the new movie... it was okay I guess 🤷"),
            ("news",    "The Federal Reserve announced a 0.25% interest rate hike amid inflation concerns."),
            ("twitter", "I can't believe how AMAZING this concert was!!! 🎵🔥 Best night of my life!!"),
        ]

        for source, text in samples:
            analyzer = SentimentAnalyzer(mode=source)
            result = analyzer.analyze(text)
            print(f"\n[{source.upper()}] {text[:70]}...")
            print(result.summary())


if __name__ == "__main__":
    main()
