# Sentiment Analysis Engine
from .analyzer import SentimentAnalyzer, SentimentResult
from .preprocessor import TextPreprocessor
from .emotion_detector import EmotionDetector

__version__ = "1.0.0"
__author__  = "Your Name"
