"""
emotion_detector.py
-------------------
Detects 8 core emotions using an NRC-style word-emotion lexicon:
  joy, sadness, anger, fear, surprise, disgust, trust, anticipation

Also computes an intensity-weighted emotion profile for each text.
"""

import re
from collections import defaultdict
from dataclasses import dataclass
from typing import Dict, List, Tuple

# ------------------------------------------------------------------ #
#  Embedded mini emotion lexicon (production: use NRC EmoLex dataset) #
# ------------------------------------------------------------------ #
# Format: "word": {"emotion": weight}
# Full NRC lexicon has ~14,000 words — install via:
#   pip install nrclex
#   from nrclex import NRCLex

EMOTION_LEXICON: Dict[str, Dict[str, float]] = {
    # JOY
    "love": {"joy": 1.0, "trust": 0.6},
    "happy": {"joy": 1.0},
    "happiness": {"joy": 1.0},
    "wonderful": {"joy": 0.9},
    "fantastic": {"joy": 0.9},
    "amazing": {"joy": 0.85},
    "excellent": {"joy": 0.8},
    "great": {"joy": 0.7},
    "good": {"joy": 0.6},
    "nice": {"joy": 0.5},
    "pleased": {"joy": 0.7},
    "delighted": {"joy": 0.9},
    "thrilled": {"joy": 0.9},
    "ecstatic": {"joy": 1.0},
    "bliss": {"joy": 1.0},
    "enjoy": {"joy": 0.7},
    "fun": {"joy": 0.7},
    "laugh": {"joy": 0.7},
    "smile": {"joy": 0.6},
    "celebrate": {"joy": 0.8, "anticipation": 0.4},

    # SADNESS
    "sad": {"sadness": 1.0},
    "unhappy": {"sadness": 0.9},
    "depressed": {"sadness": 1.0},
    "miserable": {"sadness": 1.0},
    "cry": {"sadness": 0.8},
    "tears": {"sadness": 0.7},
    "grief": {"sadness": 1.0},
    "sorrow": {"sadness": 0.9},
    "mourn": {"sadness": 0.9},
    "heartbroken": {"sadness": 1.0},
    "disappointed": {"sadness": 0.7},
    "regret": {"sadness": 0.7},
    "lonely": {"sadness": 0.8},
    "hopeless": {"sadness": 0.9},
    "tragic": {"sadness": 0.9, "fear": 0.3},

    # ANGER
    "angry": {"anger": 1.0},
    "furious": {"anger": 1.0},
    "rage": {"anger": 1.0},
    "hate": {"anger": 0.9, "disgust": 0.6},
    "hatred": {"anger": 0.9, "disgust": 0.6},
    "annoyed": {"anger": 0.7},
    "irritated": {"anger": 0.7},
    "outraged": {"anger": 1.0},
    "frustrated": {"anger": 0.8},
    "furry": {"anger": 0.3},  # low — often misspelling
    "hostile": {"anger": 0.9},
    "aggressive": {"anger": 0.8},
    "terrible": {"anger": 0.5, "disgust": 0.5},
    "awful": {"anger": 0.4, "disgust": 0.5},
    "horrible": {"anger": 0.5, "disgust": 0.7},

    # FEAR
    "afraid": {"fear": 1.0},
    "scared": {"fear": 1.0},
    "fear": {"fear": 1.0},
    "frightened": {"fear": 1.0},
    "terrified": {"fear": 1.0},
    "worried": {"fear": 0.7},
    "anxious": {"fear": 0.8},
    "nervous": {"fear": 0.7},
    "dread": {"fear": 0.9},
    "panic": {"fear": 1.0},
    "horror": {"fear": 1.0, "disgust": 0.5},
    "threat": {"fear": 0.7},
    "danger": {"fear": 0.8},
    "risky": {"fear": 0.5},
    "uncertain": {"fear": 0.4},

    # SURPRISE
    "surprised": {"surprise": 1.0},
    "astonished": {"surprise": 1.0},
    "shocked": {"surprise": 0.9, "fear": 0.3},
    "unexpected": {"surprise": 0.8},
    "sudden": {"surprise": 0.6},
    "wow": {"surprise": 0.9, "joy": 0.4},
    "incredible": {"surprise": 0.7, "joy": 0.5},
    "unbelievable": {"surprise": 0.8},
    "stunning": {"surprise": 0.7, "joy": 0.5},
    "remarkable": {"surprise": 0.5, "trust": 0.3},

    # DISGUST
    "disgusting": {"disgust": 1.0},
    "revolting": {"disgust": 1.0},
    "nasty": {"disgust": 0.9, "anger": 0.3},
    "gross": {"disgust": 0.9},
    "repulsive": {"disgust": 1.0},
    "offensive": {"disgust": 0.7, "anger": 0.4},
    "vile": {"disgust": 1.0, "anger": 0.5},
    "filthy": {"disgust": 0.8},
    "foul": {"disgust": 0.8},
    "abhorrent": {"disgust": 1.0, "anger": 0.6},

    # TRUST
    "trust": {"trust": 1.0},
    "reliable": {"trust": 0.9},
    "honest": {"trust": 0.9},
    "dependable": {"trust": 0.9},
    "safe": {"trust": 0.8},
    "secure": {"trust": 0.8},
    "confident": {"trust": 0.7},
    "faithful": {"trust": 0.9},
    "transparent": {"trust": 0.7},
    "authentic": {"trust": 0.7},

    # ANTICIPATION
    "excited": {"anticipation": 0.9, "joy": 0.6},
    "eager": {"anticipation": 0.8, "joy": 0.4},
    "hope": {"anticipation": 0.8, "joy": 0.3},
    "hopeful": {"anticipation": 0.8, "joy": 0.4},
    "expect": {"anticipation": 0.7},
    "looking forward": {"anticipation": 0.9, "joy": 0.5},
    "upcoming": {"anticipation": 0.5},
    "await": {"anticipation": 0.7},
    "soon": {"anticipation": 0.4},
    "planned": {"anticipation": 0.4},
}

EMOTION_COLORS = {
    "joy":          "#FFD700",
    "sadness":      "#4A90D9",
    "anger":        "#E74C3C",
    "fear":         "#8E44AD",
    "surprise":     "#F39C12",
    "disgust":      "#27AE60",
    "trust":        "#2ECC71",
    "anticipation": "#E67E22",
}

EMOTION_EMOJIS = {
    "joy": "😊", "sadness": "😢", "anger": "😠",
    "fear": "😨", "surprise": "😲", "disgust": "🤢",
    "trust": "🤝", "anticipation": "🤩",
}


@dataclass
class EmotionResult:
    text: str
    emotions: Dict[str, float]       # emotion → normalised score 0-1
    dominant_emotion: str
    dominant_score: float
    emotion_words: List[Tuple[str, str, float]]  # (word, emotion, score)

    def summary(self) -> str:
        lines = [f"\n🎭 Emotion Analysis", f"  Dominant: {EMOTION_EMOJIS[self.dominant_emotion]} "
                 f"{self.dominant_emotion.upper()} ({self.dominant_score:.2f})", ""]
        for emotion, score in sorted(self.emotions.items(), key=lambda x: -x[1]):
            if score > 0:
                bar = "█" * int(score * 15) + "░" * (15 - int(score * 15))
                lines.append(f"  {EMOTION_EMOJIS[emotion]} {emotion:12s} [{bar}] {score:.3f}")
        if self.emotion_words:
            lines.append(f"\n  Key emotion words:")
            for word, emotion, score in self.emotion_words[:8]:
                lines.append(f"    '{word}' → {emotion} ({score:.2f})")
        return "\n".join(lines)


class EmotionDetector:
    """
    Lexicon-based multi-emotion classifier.

    Optionally uses nrclex if installed (pip install nrclex) for
    the full 14,000-word NRC EmoLex dataset.
    """

    ALL_EMOTIONS = ["joy", "sadness", "anger", "fear",
                    "surprise", "disgust", "trust", "anticipation"]

    def __init__(self, use_nrclex: bool = True):
        self._nrclex_available = False
        if use_nrclex:
            try:
                from nrclex import NRCLex  # noqa: F401
                self._nrclex_available = True
            except ImportError:
                pass

    def detect(self, text: str) -> EmotionResult:
        """Detect emotions in text."""
        if self._nrclex_available:
            return self._nrclex_detect(text)
        return self._lexicon_detect(text)

    def detect_batch(self, texts: list) -> list:
        return [self.detect(t) for t in texts]

    # ---------------------------------------------------------------- #
    #  Detection methods                                                #
    # ---------------------------------------------------------------- #

    def _lexicon_detect(self, text: str) -> EmotionResult:
        """Use embedded mini-lexicon."""
        words = re.findall(r"\b\w+\b", text.lower())
        emotion_scores: Dict[str, float] = defaultdict(float)
        emotion_words = []

        for word in words:
            if word in EMOTION_LEXICON:
                for emotion, weight in EMOTION_LEXICON[word].items():
                    emotion_scores[emotion] += weight
                    emotion_words.append((word, emotion, weight))

        # Normalise to 0-1
        total = sum(emotion_scores.values()) or 1
        normalised = {e: round(emotion_scores.get(e, 0) / total, 4)
                      for e in self.ALL_EMOTIONS}

        dominant = max(normalised, key=normalised.get)
        return EmotionResult(
            text=text,
            emotions=normalised,
            dominant_emotion=dominant,
            dominant_score=normalised[dominant],
            emotion_words=emotion_words,
        )

    def _nrclex_detect(self, text: str) -> EmotionResult:
        """Use full NRC EmoLex via nrclex package."""
        from nrclex import NRCLex
        nrc = NRCLex(text)
        raw = nrc.raw_emotion_scores

        # Normalise
        total = sum(raw.values()) or 1
        normalised = {e: round(raw.get(e, 0) / total, 4) for e in self.ALL_EMOTIONS}

        # Emotion word list
        emotion_words = []
        for word, emotions in nrc.affect_dict.items():
            for emo in emotions:
                if emo in self.ALL_EMOTIONS:
                    emotion_words.append((word, emo, 1.0))

        dominant = max(normalised, key=normalised.get) if any(normalised.values()) else "neutral"

        return EmotionResult(
            text=text,
            emotions=normalised,
            dominant_emotion=dominant,
            dominant_score=normalised.get(dominant, 0),
            emotion_words=emotion_words,
        )

    def emotion_profile(self, texts: list) -> Dict[str, float]:
        """Aggregate emotion profile across multiple texts."""
        aggregated = defaultdict(float)
        for text in texts:
            result = self.detect(text)
            for emotion, score in result.emotions.items():
                aggregated[emotion] += score
        total = sum(aggregated.values()) or 1
        return {e: round(aggregated[e] / total, 4) for e in self.ALL_EMOTIONS}


# ------------------------------------------------------------------ #
#  CLI demo                                                            #
# ------------------------------------------------------------------ #
if __name__ == "__main__":
    detector = EmotionDetector()
    texts = [
        "I absolutely love this! It made me so happy and excited for more!",
        "I'm furious about this terrible product. It's disgusting and awful.",
        "I'm scared and worried about the upcoming changes. Very uncertain.",
        "Wow, I was completely shocked and surprised by the unexpected result!",
        "I trust this brand completely. They are reliable and always honest.",
    ]
    for text in texts:
        result = detector.detect(text)
        print(result.summary())
        print()
