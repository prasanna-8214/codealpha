"""
visualizer.py
-------------
Generates charts and visualizations for sentiment analysis results:
  - Sentiment distribution bar/pie charts
  - Emotion radar chart
  - Sentiment trend over time
  - Word cloud by sentiment
  - Source comparison heatmap
"""

import os
import warnings
from collections import Counter
from typing import Dict, List, Optional

import matplotlib
matplotlib.use("Agg")  # non-interactive backend
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
import pandas as pd
import seaborn as sns

warnings.filterwarnings("ignore")

# ------------------------------------------------------------------ #
#  Style config                                                        #
# ------------------------------------------------------------------ #

PALETTE = {
    "POSITIVE": "#2ECC71",
    "NEGATIVE": "#E74C3C",
    "NEUTRAL":  "#95A5A6",
}

EMOTION_COLORS = {
    "joy":          "#FFD700",
    "sadness":      "#4A90D9",
    "anger":        "#E74C3C",
    "fear":         "#8E44AD",
    "surprise":     "#F39C12",
    "disgust":      "#27AE60",
    "trust":        "#2ECC71",
    "anticipation": "#E67E22",
}

plt.rcParams.update({
    "figure.facecolor": "#0F1117",
    "axes.facecolor":   "#1A1D27",
    "axes.edgecolor":   "#2D3142",
    "axes.labelcolor":  "#E0E0E0",
    "xtick.color":      "#A0A0A0",
    "ytick.color":      "#A0A0A0",
    "text.color":       "#E0E0E0",
    "grid.color":       "#2D3142",
    "grid.alpha":       0.5,
    "font.family":      "DejaVu Sans",
})

OUTPUT_DIR = "static/charts"
os.makedirs(OUTPUT_DIR, exist_ok=True)


def _save(fig, name: str) -> str:
    path = f"{OUTPUT_DIR}/{name}.png"
    fig.savefig(path, dpi=150, bbox_inches="tight", facecolor=fig.get_facecolor())
    plt.close(fig)
    return path


# ------------------------------------------------------------------ #
#  Chart functions                                                     #
# ------------------------------------------------------------------ #

def plot_sentiment_distribution(df: pd.DataFrame,
                                 title: str = "Sentiment Distribution",
                                 filename: str = "sentiment_dist") -> str:
    """Bar chart of POSITIVE / NEGATIVE / NEUTRAL counts."""
    counts = df["label"].value_counts()
    labels = [l for l in ["POSITIVE", "NEUTRAL", "NEGATIVE"] if l in counts]
    values = [counts[l] for l in labels]
    colors = [PALETTE[l] for l in labels]

    fig, ax = plt.subplots(figsize=(8, 5))
    bars = ax.bar(labels, values, color=colors, edgecolor="none", width=0.5)

    for bar, val in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.5,
                f"{val}\n({val/sum(values)*100:.1f}%)",
                ha="center", va="bottom", fontsize=11, color="#E0E0E0")

    ax.set_title(title, fontsize=16, pad=15, color="white")
    ax.set_ylabel("Count", fontsize=12)
    ax.set_ylim(0, max(values) * 1.2)
    ax.grid(axis="y", linestyle="--")
    ax.set_axisbelow(True)

    return _save(fig, filename)


def plot_sentiment_pie(df: pd.DataFrame,
                       title: str = "Sentiment Breakdown",
                       filename: str = "sentiment_pie") -> str:
    """Donut pie chart."""
    counts = df["label"].value_counts()
    labels = list(counts.index)
    values = list(counts.values)
    colors = [PALETTE.get(l, "#888") for l in labels]

    fig, ax = plt.subplots(figsize=(7, 7))
    wedges, texts, autotexts = ax.pie(
        values, labels=labels, autopct="%1.1f%%",
        colors=colors, startangle=90,
        wedgeprops={"width": 0.55, "edgecolor": "#0F1117", "linewidth": 2},
        pctdistance=0.75
    )
    for at in autotexts:
        at.set_fontsize(12)
        at.set_color("white")

    ax.set_title(title, fontsize=16, pad=20, color="white")
    return _save(fig, filename)


def plot_emotion_radar(emotion_scores: Dict[str, float],
                       title: str = "Emotion Profile",
                       filename: str = "emotion_radar") -> str:
    """Spider/radar chart of emotion scores."""
    emotions = list(emotion_scores.keys())
    scores   = list(emotion_scores.values())
    N = len(emotions)

    angles = np.linspace(0, 2 * np.pi, N, endpoint=False).tolist()
    scores_plot = scores + [scores[0]]
    angles += angles[:1]

    fig, ax = plt.subplots(figsize=(7, 7), subplot_kw={"polar": True})
    ax.set_facecolor("#1A1D27")
    fig.patch.set_facecolor("#0F1117")

    ax.plot(angles, scores_plot, "o-", linewidth=2, color="#F39C12")
    ax.fill(angles, scores_plot, alpha=0.25, color="#F39C12")

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels([e.capitalize() for e in emotions], fontsize=11, color="#E0E0E0")
    ax.set_ylim(0, max(scores) * 1.2 or 1)
    ax.set_title(title, size=16, pad=20, color="white")
    ax.yaxis.set_tick_params(labelcolor="#555")
    ax.grid(color="#2D3142", alpha=0.5)

    return _save(fig, filename)


def plot_sentiment_trend(df: pd.DataFrame,
                          date_col: str = "date",
                          title: str = "Sentiment Trend Over Time",
                          filename: str = "sentiment_trend") -> str:
    """Line chart of daily sentiment percentages."""
    df = df.copy()
    try:
        df[date_col] = pd.to_datetime(df[date_col])
    except Exception:
        return ""

    df["day"] = df[date_col].dt.date
    grouped = df.groupby(["day", "label"]).size().unstack(fill_value=0)
    grouped_pct = grouped.div(grouped.sum(axis=1), axis=0) * 100

    fig, ax = plt.subplots(figsize=(12, 5))
    for label in ["POSITIVE", "NEUTRAL", "NEGATIVE"]:
        if label in grouped_pct.columns:
            ax.plot(grouped_pct.index, grouped_pct[label],
                    color=PALETTE[label], linewidth=2.5, label=label, marker="o", markersize=4)
            ax.fill_between(grouped_pct.index, grouped_pct[label],
                            alpha=0.1, color=PALETTE[label])

    ax.set_title(title, fontsize=16, pad=15, color="white")
    ax.set_ylabel("Percentage (%)", fontsize=12)
    ax.legend(loc="upper right", framealpha=0.2, labelcolor="white")
    ax.grid(linestyle="--")
    ax.set_axisbelow(True)
    plt.xticks(rotation=30, ha="right")

    return _save(fig, filename)


def plot_wordcloud(df: pd.DataFrame, text_col: str = "review_text",
                   sentiment: Optional[str] = None,
                   filename: str = "wordcloud") -> str:
    """Generate a word cloud from text."""
    try:
        from wordcloud import WordCloud, STOPWORDS
    except ImportError:
        print("wordcloud not installed. Run: pip install wordcloud")
        return ""

    subset = df if sentiment is None else df[df["label"] == sentiment]
    text = " ".join(subset[text_col].dropna().astype(str).tolist())

    color_map = {"POSITIVE": "Greens", "NEGATIVE": "Reds", "NEUTRAL": "Blues"}.get(sentiment, "viridis")

    wc = WordCloud(
        width=1000, height=500,
        background_color="#1A1D27",
        colormap=color_map,
        stopwords=STOPWORDS,
        max_words=150,
        prefer_horizontal=0.7,
    ).generate(text)

    fig, ax = plt.subplots(figsize=(12, 5))
    ax.imshow(wc, interpolation="bilinear")
    ax.axis("off")
    label_str = sentiment if sentiment else "All"
    ax.set_title(f"Word Cloud — {label_str}", fontsize=16, color="white", pad=10)

    return _save(fig, filename)


def plot_source_comparison(dfs: Dict[str, pd.DataFrame],
                           filename: str = "source_comparison") -> str:
    """Heatmap comparing sentiment % across different data sources."""
    records = {}
    for source, df in dfs.items():
        counts = df["label"].value_counts(normalize=True) * 100
        records[source] = counts

    heatmap_df = pd.DataFrame(records).T.fillna(0)
    for col in ["POSITIVE", "NEUTRAL", "NEGATIVE"]:
        if col not in heatmap_df.columns:
            heatmap_df[col] = 0

    heatmap_df = heatmap_df[["POSITIVE", "NEUTRAL", "NEGATIVE"]]

    fig, ax = plt.subplots(figsize=(8, 4))
    sns.heatmap(heatmap_df, annot=True, fmt=".1f", cmap="RdYlGn",
                linewidths=0.5, ax=ax, cbar_kws={"label": "%"},
                annot_kws={"size": 12})

    ax.set_title("Sentiment % by Data Source", fontsize=15, pad=15, color="white")
    ax.set_xlabel("")

    return _save(fig, filename)


def plot_polarity_histogram(df: pd.DataFrame,
                             filename: str = "polarity_hist") -> str:
    """Histogram of polarity scores."""
    fig, ax = plt.subplots(figsize=(9, 4))
    ax.hist(df["polarity"].dropna(), bins=40, color="#4A90D9",
            edgecolor="#0F1117", alpha=0.85)
    ax.axvline(0, color="#E74C3C", linewidth=2, linestyle="--", label="Neutral boundary")
    ax.set_title("Polarity Score Distribution", fontsize=15, pad=15, color="white")
    ax.set_xlabel("Polarity Score", fontsize=12)
    ax.set_ylabel("Count", fontsize=12)
    ax.legend(labelcolor="white", framealpha=0.2)
    ax.grid(linestyle="--")

    return _save(fig, filename)


# ------------------------------------------------------------------ #
#  Full report generator                                               #
# ------------------------------------------------------------------ #

def generate_full_report(df: pd.DataFrame, source: str = "generic"):
    """Generate all charts for a dataset."""
    print(f"\n📊 Generating visualizations for {source} data ({len(df)} records)...")
    charts = {}

    charts["distribution"] = plot_sentiment_distribution(
        df, title=f"Sentiment Distribution — {source.capitalize()}", filename=f"{source}_dist")
    charts["pie"] = plot_sentiment_pie(
        df, title=f"Sentiment Breakdown — {source.capitalize()}", filename=f"{source}_pie")
    charts["polarity"] = plot_polarity_histogram(df, filename=f"{source}_polarity")

    text_col = next((c for c in ["review_text", "text", "title", "content"] if c in df.columns), None)
    if text_col:
        for sentiment in ["POSITIVE", "NEGATIVE", "NEUTRAL"]:
            charts[f"wc_{sentiment.lower()}"] = plot_wordcloud(
                df, text_col, sentiment, filename=f"{source}_wc_{sentiment.lower()}")

    if "date" in df.columns:
        charts["trend"] = plot_sentiment_trend(df, filename=f"{source}_trend")

    print(f"  ✓ Saved {len(charts)} charts to {OUTPUT_DIR}/")
    return charts


if __name__ == "__main__":
    # Quick demo with synthetic data
    import random
    from datetime import datetime, timedelta

    random.seed(42)
    n = 200
    labels = random.choices(["POSITIVE", "NEGATIVE", "NEUTRAL"], weights=[5, 3, 2], k=n)
    polarities = [
        random.uniform(0.1, 1.0) if l == "POSITIVE" else
        random.uniform(-1.0, -0.1) if l == "NEGATIVE" else
        random.uniform(-0.1, 0.1)
        for l in labels
    ]
    dates = [(datetime.now() - timedelta(days=random.randint(0, 30))).strftime("%Y-%m-%d") for _ in range(n)]

    demo_df = pd.DataFrame({
        "review_text": [f"Sample review text for testing visualization {i}" for i in range(n)],
        "label":       labels,
        "polarity":    polarities,
        "date":        dates,
    })

    generate_full_report(demo_df, "demo")
    print("\nDemo charts saved to static/charts/")
