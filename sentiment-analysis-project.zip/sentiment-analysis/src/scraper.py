"""
scraper.py
----------
Data collection utilities for sentiment analysis.

Sources:
  - Amazon product reviews (via BeautifulSoup demo / mock)
  - Twitter-like social posts (simulated dataset)
  - News headlines (via requests + BeautifulSoup)

Note: For production use, use official APIs:
  - Amazon Product Advertising API
  - Twitter/X API v2
  - NewsAPI (newsapi.org)
"""

import csv
import json
import random
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Dict, Optional

import requests
from bs4 import BeautifulSoup

# ------------------------------------------------------------------ #
#  Mock data generators (used when live scraping is not available)    #
# ------------------------------------------------------------------ #

AMAZON_MOCK = [
    ("B001", "Wireless Headphones", 5, "Absolutely incredible sound quality! Best headphones I've ever owned. Very comfortable for long sessions."),
    ("B001", "Wireless Headphones", 1, "Broke after two weeks. The left ear stopped working. Complete waste of money. Very disappointed."),
    ("B001", "Wireless Headphones", 4, "Great sound but the battery life could be better. Overall happy with my purchase."),
    ("B001", "Wireless Headphones", 2, "Uncomfortable after 30 minutes. Sound is okay but not worth the price at all."),
    ("B001", "Wireless Headphones", 5, "Perfect gift! My son loves them. Crystal clear audio and stylish design. Highly recommend!"),
    ("B002", "Coffee Maker", 5, "Makes the best coffee every morning. Easy to use and clean. Love it!"),
    ("B002", "Coffee Maker", 3, "Average coffee maker. Works fine but nothing special about it."),
    ("B002", "Coffee Maker", 1, "Leaked everywhere and broke on day 3. Terrible build quality. Returning immediately."),
    ("B002", "Coffee Maker", 4, "Very good coffee maker for the price. Fast brewing and keeps coffee hot."),
    ("B003", "Smart Watch", 5, "Amazing fitness tracker! Tracks everything accurately. Very happy with this purchase."),
    ("B003", "Smart Watch", 2, "The app crashes constantly and syncing is a nightmare. Frustrating experience."),
    ("B003", "Smart Watch", 4, "Good smartwatch overall. Battery lasts 2 days which is decent. Nice display."),
    ("B004", "Laptop Stand", 5, "Ergonomic and sturdy. My neck pain disappeared after using this. Worth every penny!"),
    ("B004", "Laptop Stand", 3, "It's okay. Does the job but feels a bit wobbly on my desk."),
    ("B005", "Yoga Mat", 5, "Non-slip and very comfortable. Perfect thickness. Best yoga mat I've used!"),
    ("B005", "Yoga Mat", 4, "Good mat but has a slight rubber smell at first. Goes away after a few uses."),
    ("B005", "Yoga Mat", 1, "Peeling after 2 months of regular use. Would not recommend for serious practitioners."),
]

TWITTER_MOCK = [
    ("tech",     "Just upgraded to the new iPhone and honestly it's not that different from my old one... 🤔"),
    ("tech",     "ChatGPT just solved a bug I've been stuck on for 3 days in 30 seconds. The future is wild 🤯"),
    ("tech",     "Social media is ruining our attention spans. Can't focus on anything anymore. #DigitalDetox"),
    ("politics", "Finally some good news from the government! New infrastructure bill will create thousands of jobs 👏"),
    ("politics", "Absolutely disgusted by the latest policy changes. This is not what we voted for. #Disappointed"),
    ("politics", "The economy is a complicated mess and nobody seems to have any real solutions. Just tired of it all."),
    ("sports",   "WHAT A GAME!!! Last minute goal!!! I'm literally shaking right now!! 🔥⚽🔥"),
    ("sports",   "Referees completely robbed us tonight. Terrible decisions. So angry right now."),
    ("sports",   "Good match today. Both teams played well. Deserved draw I think."),
    ("food",     "Tried that new restaurant downtown and honestly it was life-changing 🍜 10/10 would go again!"),
    ("food",     "Waited 2 hours for cold food. Never going back. Worst dining experience of my life."),
    ("food",     "The burger was decent. Nothing to write home about but it filled me up."),
    ("health",   "30 days of daily exercise and I feel absolutely incredible!!! Best decision I ever made 💪"),
    ("health",   "Dealing with anxiety is exhausting. Some days are just really hard. 😔"),
    ("health",   "Started meditation this week. Not sure if it's working yet but trying to stay consistent."),
]

NEWS_MOCK = [
    ("economy",     "Markets surge to record highs as inflation data shows significant improvement"),
    ("economy",     "Unemployment hits 50-year low as job market continues strong recovery"),
    ("economy",     "Central bank raises interest rates again amid persistent inflation concerns"),
    ("economy",     "Housing market crashes in major cities as mortgage rates reach historic levels"),
    ("technology",  "Breakthrough AI model outperforms humans in complex reasoning tasks"),
    ("technology",  "Major data breach exposes millions of users' personal information"),
    ("technology",  "Tech giants report mixed quarterly earnings amid global uncertainty"),
    ("environment", "Scientists celebrate major milestone in renewable energy adoption worldwide"),
    ("environment", "Devastating wildfires destroy thousands of acres across the western region"),
    ("environment", "New climate agreement signed by 150 nations in historic global summit"),
    ("health",      "Promising cancer vaccine shows 90% success rate in clinical trials"),
    ("health",      "Hospital overcrowding reaches crisis levels in major urban centers"),
    ("politics",    "Landmark bipartisan legislation passes with overwhelming congressional support"),
    ("politics",    "Diplomatic tensions escalate between major world powers over trade disputes"),
]


# ------------------------------------------------------------------ #
#  Scrapers                                                            #
# ------------------------------------------------------------------ #

class AmazonScraper:
    """
    Amazon review collector.
    Uses mock data for demonstration; swap with real API for production.
    """

    def get_reviews(self, product_id: Optional[str] = None,
                    product_name: Optional[str] = None,
                    max_reviews: int = 100) -> List[Dict]:
        """Return a list of review dicts."""
        print(f"[Amazon] Collecting reviews (mock mode)...")
        reviews = []

        # Filter by product if specified
        pool = [r for r in AMAZON_MOCK
                if product_id is None or r[0] == product_id]
        if not pool:
            pool = AMAZON_MOCK

        # Sample from pool with repetition to reach max_reviews
        for i in range(min(max_reviews, len(pool) * 3)):
            item = pool[i % len(pool)]
            # Add slight variation
            reviews.append({
                "product_id":   item[0],
                "product_name": item[1],
                "rating":       item[2],
                "review_text":  item[3],
                "date":         self._random_date(),
                "verified":     random.choice([True, True, True, False]),
                "helpful_votes": random.randint(0, 50),
                "source":       "amazon",
            })

        print(f"  ✓ Collected {len(reviews)} Amazon reviews")
        return reviews

    @staticmethod
    def _random_date() -> str:
        d = datetime.now() - timedelta(days=random.randint(1, 365))
        return d.strftime("%Y-%m-%d")


class TwitterScraper:
    """
    Social media post collector.
    Uses mock data for demonstration; replace with Twitter API v2 in production.
    """

    def get_tweets(self, query: Optional[str] = None,
                   topic: Optional[str] = None,
                   max_tweets: int = 100) -> List[Dict]:
        print(f"[Twitter] Collecting tweets (mock mode)...")
        tweets = []

        pool = [t for t in TWITTER_MOCK
                if topic is None or t[0] == topic]
        if not pool:
            pool = TWITTER_MOCK

        for i in range(min(max_tweets, len(pool) * 5)):
            item = pool[i % len(pool)]
            tweets.append({
                "tweet_id":     f"tw_{random.randint(100000, 999999)}",
                "topic":        item[0],
                "text":         item[1],
                "likes":        random.randint(0, 10000),
                "retweets":     random.randint(0, 1000),
                "date":         self._random_date(),
                "source":       "twitter",
            })

        print(f"  ✓ Collected {len(tweets)} tweets")
        return tweets

    @staticmethod
    def _random_date() -> str:
        d = datetime.now() - timedelta(hours=random.randint(1, 72))
        return d.strftime("%Y-%m-%d %H:%M")


class NewsScraper:
    """
    News headline collector.
    Uses mock data. For production: use newsapi.org with an API key.
    """

    NEWSAPI_URL = "https://newsapi.org/v2/everything"

    def get_headlines(self, query: Optional[str] = None,
                      category: Optional[str] = None,
                      max_articles: int = 50,
                      newsapi_key: Optional[str] = None) -> List[Dict]:

        if newsapi_key:
            return self._fetch_newsapi(query or "technology", max_articles, newsapi_key)

        print(f"[News] Collecting headlines (mock mode)...")
        pool = [n for n in NEWS_MOCK
                if category is None or n[0] == category]
        if not pool:
            pool = NEWS_MOCK

        articles = []
        for i in range(min(max_articles, len(pool) * 3)):
            item = pool[i % len(pool)]
            articles.append({
                "article_id":  f"art_{i:04d}",
                "category":    item[0],
                "title":       item[1],
                "content":     item[1],  # In real scraping this would be full article
                "date":        self._random_date(),
                "source":      "news",
            })

        print(f"  ✓ Collected {len(articles)} news articles")
        return articles

    def _fetch_newsapi(self, query: str, max_articles: int, api_key: str) -> List[Dict]:
        """Fetch from NewsAPI.org (requires free API key)."""
        try:
            resp = requests.get(self.NEWSAPI_URL, params={
                "q": query, "pageSize": min(max_articles, 100),
                "apiKey": api_key, "language": "en"
            }, timeout=10)
            data = resp.json()
            articles = []
            for art in data.get("articles", []):
                articles.append({
                    "article_id": art.get("url", "")[-20:],
                    "category":   query,
                    "title":      art.get("title", ""),
                    "content":    art.get("description", "") or art.get("title", ""),
                    "date":       art.get("publishedAt", ""),
                    "source":     art.get("source", {}).get("name", "news"),
                })
            return articles
        except Exception as e:
            print(f"  NewsAPI error: {e}. Falling back to mock data.")
            return self.get_headlines(query, max_articles=max_articles)

    @staticmethod
    def _random_date() -> str:
        d = datetime.now() - timedelta(hours=random.randint(1, 48))
        return d.strftime("%Y-%m-%d %H:%M")


# ------------------------------------------------------------------ #
#  CSV export                                                          #
# ------------------------------------------------------------------ #

def save_to_csv(data: List[Dict], filepath: str):
    """Save list of dicts to CSV."""
    if not data:
        print("No data to save.")
        return
    Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=data[0].keys())
        writer.writeheader()
        writer.writerows(data)
    print(f"  ✓ Saved {len(data)} records → {filepath}")


# ------------------------------------------------------------------ #
#  CLI                                                                 #
# ------------------------------------------------------------------ #

if __name__ == "__main__":
    # Collect and save sample data
    amazon  = AmazonScraper().get_reviews(max_reviews=50)
    tweets  = TwitterScraper().get_tweets(max_tweets=50)
    news    = NewsScraper().get_headlines(max_articles=30)

    save_to_csv(amazon, "data/sample_reviews.csv")
    save_to_csv(tweets, "data/sample_tweets.csv")
    save_to_csv(news,   "data/sample_news.csv")

    print("\n✓ All sample data files created in data/")
