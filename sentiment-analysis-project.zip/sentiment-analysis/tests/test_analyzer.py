"""
tests/test_analyzer.py
----------------------
Unit tests for the Sentiment Analysis Engine.

Run with: pytest tests/test_analyzer.py -v
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from preprocessor import TextPreprocessor
from analyzer import SentimentAnalyzer, SentimentResult
from emotion_detector import EmotionDetector


# ------------------------------------------------------------------ #
#  TextPreprocessor tests                                              #
# ------------------------------------------------------------------ #

class TestTextPreprocessor:

    def test_removes_url(self):
        pp = TextPreprocessor()
        cleaned = pp.clean("Check this out http://example.com great!")
        assert "http" not in cleaned

    def test_removes_html_tags(self):
        pp = TextPreprocessor()
        cleaned = pp.clean("<p>Hello <b>world</b></p>")
        assert "<" not in cleaned and "Hello" in cleaned

    def test_twitter_removes_mentions(self):
        pp = TextPreprocessor(mode="twitter")
        cleaned = pp.clean("@JohnDoe this is great!")
        assert "@JohnDoe" not in cleaned

    def test_twitter_keeps_hashtag_word(self):
        pp = TextPreprocessor(mode="twitter")
        cleaned = pp.clean("I love #Python programming!")
        assert "Python" in cleaned
        assert "#" not in cleaned

    def test_expands_contractions(self):
        pp = TextPreprocessor()
        cleaned = pp.clean("I can't believe this isn't great")
        assert "cannot" in cleaned.lower() or "can not" in cleaned.lower()

    def test_empty_string(self):
        pp = TextPreprocessor()
        assert pp.clean("") == ""
        assert pp.clean("   ") == ""

    def test_tokenize_returns_list(self):
        pp = TextPreprocessor()
        tokens = pp.tokenize("The quick brown fox jumps")
        assert isinstance(tokens, list)
        assert len(tokens) > 0

    def test_non_string_input(self):
        pp = TextPreprocessor()
        assert pp.clean(None) == ""
        assert pp.clean(123) == ""


# ------------------------------------------------------------------ #
#  SentimentAnalyzer tests                                             #
# ------------------------------------------------------------------ #

class TestSentimentAnalyzer:

    @pytest.fixture
    def analyzer(self):
        return SentimentAnalyzer(mode="generic")

    def test_positive_text(self, analyzer):
        result = analyzer.analyze("This is absolutely amazing! I love it so much!")
        assert result.label == "POSITIVE"

    def test_negative_text(self, analyzer):
        result = analyzer.analyze("This is terrible. I hate it. Completely broken and useless.")
        assert result.label == "NEGATIVE"

    def test_neutral_text(self, analyzer):
        result = analyzer.analyze("The item arrived in a brown box. It is a medium size.")
        # Neutral or could be classified either way — just check it returns a valid label
        assert result.label in {"POSITIVE", "NEGATIVE", "NEUTRAL"}

    def test_result_has_all_fields(self, analyzer):
        result = analyzer.analyze("Great product!")
        assert isinstance(result, SentimentResult)
        assert result.label in {"POSITIVE", "NEGATIVE", "NEUTRAL"}
        assert 0.0 <= result.confidence <= 1.0
        assert -1.0 <= result.polarity <= 1.0
        assert 0.0 <= result.subjectivity <= 1.0
        assert result.processing_ms >= 0

    def test_confidence_in_range(self, analyzer):
        texts = [
            "Best product ever!!!",
            "Worst experience of my life.",
            "It came in a box.",
        ]
        for text in texts:
            result = analyzer.analyze(text)
            assert 0.0 <= result.confidence <= 1.0, f"Confidence out of range for: {text}"

    def test_batch_analyze(self, analyzer):
        texts = ["I love this!", "I hate this!", "It is okay."]
        results = analyzer.analyze_batch(texts, show_progress=False)
        assert len(results) == 3
        for r in results:
            assert r.label in {"POSITIVE", "NEGATIVE", "NEUTRAL"}

    def test_amazon_mode(self):
        analyzer = SentimentAnalyzer(mode="amazon")
        result = analyzer.analyze("Great product, fast shipping, very happy!")
        assert result.label == "POSITIVE"

    def test_twitter_mode(self):
        analyzer = SentimentAnalyzer(mode="twitter")
        result = analyzer.analyze("This is so bad I can't even 😤")
        assert result.label in {"NEGATIVE", "NEUTRAL"}

    def test_empty_text_handled(self, analyzer):
        # Should not crash
        result = analyzer.analyze("")
        assert result.label in {"POSITIVE", "NEGATIVE", "NEUTRAL"}

    def test_very_long_text(self, analyzer):
        text = "This is great! " * 200
        result = analyzer.analyze(text)
        assert result.label == "POSITIVE"

    def test_special_characters(self, analyzer):
        result = analyzer.analyze("🔥🔥🔥 Amazing!!! 💯💯")
        assert result.label in {"POSITIVE", "NEGATIVE", "NEUTRAL"}

    def test_summary_string(self, analyzer):
        result = analyzer.analyze("Good stuff!")
        summary = result.summary()
        assert "POSITIVE" in summary or "NEGATIVE" in summary or "NEUTRAL" in summary
        assert "Polarity" in summary

    def test_to_dict(self, analyzer):
        result = analyzer.analyze("Nice product.")
        d = result.to_dict()
        assert "label" in d
        assert "polarity" in d
        assert "confidence" in d


# ------------------------------------------------------------------ #
#  EmotionDetector tests                                               #
# ------------------------------------------------------------------ #

class TestEmotionDetector:

    @pytest.fixture
    def detector(self):
        return EmotionDetector(use_nrclex=False)  # use embedded lexicon

    def test_detects_joy(self, detector):
        result = detector.detect("I am so happy and love this wonderful day!")
        assert result.emotions["joy"] > 0

    def test_detects_anger(self, detector):
        result = detector.detect("I am furious and so angry about this terrible thing!")
        assert result.emotions["anger"] > 0

    def test_detects_fear(self, detector):
        result = detector.detect("I am scared and terrified of what might happen.")
        assert result.emotions["fear"] > 0

    def test_dominant_emotion_is_valid(self, detector):
        result = detector.detect("I love this so much! Amazing and wonderful!")
        assert result.dominant_emotion in [
            "joy", "sadness", "anger", "fear",
            "surprise", "disgust", "trust", "anticipation"
        ]

    def test_all_emotions_present(self, detector):
        result = detector.detect("Some random text here.")
        assert len(result.emotions) == 8

    def test_emotion_scores_sum_to_one(self, detector):
        result = detector.detect("I love this amazing product so much!")
        total = sum(result.emotions.values())
        assert abs(total - 1.0) < 0.01 or total == 0.0  # normalised or all zero

    def test_emotion_batch(self, detector):
        texts = ["I'm so happy!", "I'm so angry!", "I'm afraid."]
        results = detector.detect_batch(texts)
        assert len(results) == 3

    def test_emotion_profile(self, detector):
        texts = ["I love this!", "Amazing!", "So happy today!"]
        profile = detector.emotion_profile(texts)
        assert isinstance(profile, dict)
        assert "joy" in profile

    def test_summary_string(self, detector):
        result = detector.detect("I'm very happy today!")
        summary = result.summary()
        assert "Emotion" in summary


# ------------------------------------------------------------------ #
#  Integration test                                                    #
# ------------------------------------------------------------------ #

class TestIntegration:

    def test_full_pipeline(self):
        """End-to-end: preprocess → analyze → detect emotions."""
        text = "This product is absolutely wonderful! I'm so thrilled and happy with my purchase!"

        pp = TextPreprocessor(mode="amazon")
        cleaned = pp.clean(text)
        assert cleaned

        analyzer = SentimentAnalyzer(mode="amazon")
        result = analyzer.analyze(text)
        assert result.label == "POSITIVE"
        assert result.confidence >= 0.5

        detector = EmotionDetector(use_nrclex=False)
        emotions = detector.detect(cleaned)
        assert emotions.dominant_emotion in {"joy", "anticipation", "trust", "surprise"}

    def test_negative_pipeline(self):
        text = "Terrible product. Broke on day one. Worst purchase ever. I hate it."
        analyzer = SentimentAnalyzer(mode="amazon")
        result = analyzer.analyze(text)
        assert result.label == "NEGATIVE"

        detector = EmotionDetector(use_nrclex=False)
        emotions = detector.detect(text)
        assert emotions.emotions["anger"] > 0 or emotions.emotions["disgust"] > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
