"""
app.py
------
Flask web dashboard for the Sentiment Analysis Engine.

Endpoints:
  GET  /              → Dashboard UI
  POST /api/analyze   → Analyze a single text
  POST /api/upload    → Analyze a CSV file
  GET  /api/demo      → Run demo analysis on all sample sources
  GET  /api/stats     → Overall stats for the current session
"""

import json
import os
import sys
import io
from datetime import datetime
from pathlib import Path

import pandas as pd
from flask import Flask, request, jsonify, render_template_string, send_from_directory
from flask_cors import CORS

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from analyzer import SentimentAnalyzer
from emotion_detector import EmotionDetector

app = Flask(__name__, static_folder="static")
CORS(app)

# Session state (in-memory; use Redis/DB for production)
SESSION = {
    "history": [],
    "total_analyzed": 0,
    "label_counts": {"POSITIVE": 0, "NEGATIVE": 0, "NEUTRAL": 0},
}

# ------------------------------------------------------------------ #
#  HTML Template (single-file full-stack dashboard)                   #
# ------------------------------------------------------------------ #

DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sentiment Analysis Engine</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;600;700&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
<style>
  :root {
    --bg:       #0A0E1A;
    --surface:  #111827;
    --card:     #1A2035;
    --border:   #1E2D45;
    --accent:   #3B82F6;
    --pos:      #10B981;
    --neg:      #EF4444;
    --neu:      #6B7280;
    --text:     #E2E8F0;
    --muted:    #64748B;
    --radius:   16px;
  }

  * { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    font-family: 'Space Grotesk', sans-serif;
    background: var(--bg);
    color: var(--text);
    min-height: 100vh;
  }

  /* Header */
  header {
    background: linear-gradient(135deg, #0A0E1A 0%, #111827 100%);
    border-bottom: 1px solid var(--border);
    padding: 20px 40px;
    display: flex;
    align-items: center;
    gap: 16px;
  }

  header .logo {
    font-size: 28px;
    font-weight: 700;
    background: linear-gradient(135deg, #3B82F6, #8B5CF6);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }

  header .subtitle { color: var(--muted); font-size: 14px; }

  /* Layout */
  .container { max-width: 1280px; margin: 0 auto; padding: 40px; }

  .grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
  .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }

  /* Cards */
  .card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 28px;
    transition: border-color 0.2s;
  }

  .card:hover { border-color: var(--accent); }

  .card h3 {
    font-size: 13px;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    color: var(--muted);
    margin-bottom: 12px;
  }

  .stat-number {
    font-size: 42px;
    font-weight: 700;
    line-height: 1;
    margin-bottom: 6px;
  }

  .stat-label { color: var(--muted); font-size: 13px; }

  /* Input area */
  .analyze-section {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 32px;
    margin: 32px 0;
  }

  .analyze-section h2 {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .source-tabs {
    display: flex;
    gap: 8px;
    margin-bottom: 20px;
  }

  .source-tab {
    padding: 8px 18px;
    border-radius: 100px;
    border: 1px solid var(--border);
    background: transparent;
    color: var(--muted);
    cursor: pointer;
    font-family: 'Space Grotesk', sans-serif;
    font-size: 13px;
    transition: all 0.2s;
  }

  .source-tab.active, .source-tab:hover {
    background: var(--accent);
    border-color: var(--accent);
    color: white;
  }

  textarea {
    width: 100%;
    height: 120px;
    background: #0F1621;
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 16px;
    color: var(--text);
    font-family: 'Space Grotesk', sans-serif;
    font-size: 15px;
    resize: vertical;
    outline: none;
    transition: border-color 0.2s;
  }

  textarea:focus { border-color: var(--accent); }

  .btn {
    padding: 12px 28px;
    border-radius: 100px;
    border: none;
    font-family: 'Space Grotesk', sans-serif;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
    display: inline-flex;
    align-items: center;
    gap: 8px;
  }

  .btn-primary {
    background: linear-gradient(135deg, #3B82F6, #8B5CF6);
    color: white;
  }

  .btn-primary:hover { opacity: 0.9; transform: translateY(-1px); }

  .btn-secondary {
    background: var(--surface);
    color: var(--text);
    border: 1px solid var(--border);
  }

  /* Result panel */
  #result-panel {
    display: none;
    margin-top: 24px;
    padding: 24px;
    border-radius: 12px;
    border: 1px solid var(--border);
    background: #0F1621;
    animation: fadeIn 0.3s ease;
  }

  @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }

  .result-label {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-size: 28px;
    font-weight: 700;
    margin-bottom: 16px;
  }

  .label-badge {
    padding: 4px 14px;
    border-radius: 100px;
    font-size: 13px;
    font-weight: 600;
  }

  .POSITIVE { background: rgba(16,185,129,0.15); color: #10B981; border: 1px solid #10B981; }
  .NEGATIVE { background: rgba(239,68,68,0.15);  color: #EF4444; border: 1px solid #EF4444; }
  .NEUTRAL  { background: rgba(107,114,128,0.15);color: #9CA3AF; border: 1px solid #6B7280; }

  .metrics-row {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
    margin-top: 16px;
  }

  .metric-box {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 14px;
    text-align: center;
  }

  .metric-box .val {
    font-size: 22px;
    font-weight: 700;
    font-family: 'JetBrains Mono', monospace;
    color: var(--accent);
  }

  .metric-box .lbl { font-size: 11px; color: var(--muted); margin-top: 4px; }

  /* Emotion bars */
  .emotion-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    margin-top: 16px;
  }

  .emotion-row { display: flex; align-items: center; gap: 10px; }
  .emotion-name { width: 90px; font-size: 13px; color: var(--muted); }

  .emotion-bar-wrap {
    flex: 1;
    height: 8px;
    background: var(--border);
    border-radius: 100px;
    overflow: hidden;
  }

  .emotion-bar {
    height: 100%;
    border-radius: 100px;
    transition: width 0.6s ease;
  }

  .emotion-score { font-size: 12px; color: var(--muted); width: 40px; text-align: right; font-family: monospace; }

  /* History */
  .history-item {
    padding: 16px;
    border-bottom: 1px solid var(--border);
    display: flex;
    align-items: center;
    gap: 14px;
    cursor: pointer;
    transition: background 0.15s;
  }

  .history-item:hover { background: rgba(59,130,246,0.05); }
  .history-item:last-child { border-bottom: none; }
  .history-text { flex: 1; font-size: 14px; color: var(--muted); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

  /* Loading spinner */
  .spinner {
    width: 18px; height: 18px;
    border: 2px solid rgba(255,255,255,0.3);
    border-top-color: white;
    border-radius: 50%;
    animation: spin 0.7s linear infinite;
    display: none;
  }

  @keyframes spin { to { transform: rotate(360deg); } }

  .confidence-bar-wrap {
    height: 6px;
    background: var(--border);
    border-radius: 100px;
    overflow: hidden;
    margin-top: 12px;
    margin-bottom: 4px;
  }

  .confidence-bar {
    height: 100%;
    border-radius: 100px;
    background: linear-gradient(90deg, #3B82F6, #8B5CF6);
    transition: width 0.8s ease;
  }
</style>
</head>
<body>

<header>
  <div class="logo">🧠 SentimentAI</div>
  <div>
    <div style="font-weight:600;font-size:15px;">Sentiment Analysis Engine</div>
    <div class="subtitle">NLP-powered opinion mining across Amazon, Twitter & News</div>
  </div>
</header>

<div class="container">

  <!-- Stats row -->
  <div class="grid-3" style="margin-bottom:32px;">
    <div class="card">
      <h3>Total Analyzed</h3>
      <div class="stat-number" id="total-count">0</div>
      <div class="stat-label">texts processed this session</div>
    </div>
    <div class="card">
      <h3>Positivity Rate</h3>
      <div class="stat-number" id="pos-rate" style="color:#10B981;">—</div>
      <div class="stat-label">of all analyzed texts</div>
    </div>
    <div class="card">
      <h3>Avg. Confidence</h3>
      <div class="stat-number" id="avg-conf" style="color:#3B82F6;">—</div>
      <div class="stat-label">model certainty score</div>
    </div>
  </div>

  <!-- Analyze section -->
  <div class="analyze-section">
    <h2>⚡ Analyze Text</h2>

    <div class="source-tabs">
      <button class="source-tab active" data-source="generic">Generic</button>
      <button class="source-tab" data-source="amazon">Amazon Review</button>
      <button class="source-tab" data-source="twitter">Social Media</button>
      <button class="source-tab" data-source="news">News</button>
    </div>

    <textarea id="input-text" placeholder="Enter text to analyze... (review, tweet, headline, or any opinion)"></textarea>

    <div style="margin-top:14px;display:flex;gap:12px;align-items:center;">
      <button class="btn btn-primary" onclick="analyze()">
        <span class="spinner" id="spinner"></span>
        <span id="btn-label">Analyze Sentiment</span>
      </button>
      <button class="btn btn-secondary" onclick="runDemo()">▶ Run Demo</button>
      <button class="btn btn-secondary" onclick="clearAll()">✕ Clear</button>
    </div>

    <!-- Result panel -->
    <div id="result-panel">
      <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
        <div class="result-label" id="result-label">—</div>
        <span class="label-badge" id="result-badge">—</span>
      </div>
      <div class="confidence-bar-wrap"><div class="confidence-bar" id="conf-bar" style="width:0%"></div></div>
      <div style="font-size:12px;color:var(--muted);margin-bottom:16px;" id="conf-text">Confidence: —</div>

      <div class="metrics-row">
        <div class="metric-box"><div class="val" id="m-polarity">—</div><div class="lbl">Polarity</div></div>
        <div class="metric-box"><div class="val" id="m-subjectivity">—</div><div class="lbl">Subjectivity</div></div>
        <div class="metric-box"><div class="val" id="m-vader">—</div><div class="lbl">VADER Score</div></div>
        <div class="metric-box"><div class="val" id="m-time">—</div><div class="lbl">Process Time</div></div>
      </div>

      <div style="margin-top:24px;">
        <h3 style="color:var(--muted);font-size:12px;letter-spacing:1.5px;text-transform:uppercase;margin-bottom:14px;">🎭 Emotion Profile</h3>
        <div class="emotion-grid" id="emotion-grid"></div>
      </div>
    </div>
  </div>

  <!-- History -->
  <div class="card">
    <h3>📋 Analysis History</h3>
    <div id="history-list" style="margin-top:16px;">
      <div style="color:var(--muted);font-size:14px;padding:20px 0;text-align:center;">No analyses yet — try analyzing some text above!</div>
    </div>
  </div>

</div>

<script>
let selectedSource = "generic";
let history = [];
let stats = { total: 0, pos: 0, confidences: [] };

document.querySelectorAll(".source-tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".source-tab").forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    selectedSource = tab.dataset.source;
  });
});

async function analyze() {
  const text = document.getElementById("input-text").value.trim();
  if (!text) { alert("Please enter some text to analyze."); return; }

  setLoading(true);

  try {
    const res = await fetch("/api/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, source: selectedSource })
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error);
    showResult(data);
    addToHistory(data);
    updateStats(data);
  } catch (err) {
    alert("Error: " + err.message);
  } finally {
    setLoading(false);
  }
}

function showResult(d) {
  document.getElementById("result-panel").style.display = "block";

  const emoji = { POSITIVE: "😊", NEGATIVE: "😠", NEUTRAL: "😐" }[d.label];
  document.getElementById("result-label").textContent = emoji + " " + d.label;

  const badge = document.getElementById("result-badge");
  badge.textContent = (d.confidence * 100).toFixed(1) + "% confident";
  badge.className = "label-badge " + d.label;

  document.getElementById("conf-bar").style.width = (d.confidence * 100) + "%";
  document.getElementById("conf-text").textContent = "Confidence: " + (d.confidence * 100).toFixed(1) + "%";

  document.getElementById("m-polarity").textContent     = (d.polarity >= 0 ? "+" : "") + d.polarity.toFixed(3);
  document.getElementById("m-subjectivity").textContent = d.subjectivity.toFixed(3);
  document.getElementById("m-vader").textContent        = (d.vader_compound >= 0 ? "+" : "") + d.vader_compound.toFixed(3);
  document.getElementById("m-time").textContent         = d.processing_ms.toFixed(0) + "ms";

  // Emotion bars
  const emoColors = {
    joy: "#FFD700", sadness: "#4A90D9", anger: "#E74C3C",
    fear: "#8E44AD", surprise: "#F39C12", disgust: "#27AE60",
    trust: "#2ECC71", anticipation: "#E67E22"
  };
  const emoEmoji = {
    joy: "😊", sadness: "😢", anger: "😠", fear: "😨",
    surprise: "😲", disgust: "🤢", trust: "🤝", anticipation: "🤩"
  };

  const grid = document.getElementById("emotion-grid");
  grid.innerHTML = "";
  for (const [emo, score] of Object.entries(d.emotions || {})) {
    const row = document.createElement("div");
    row.className = "emotion-row";
    row.innerHTML = `
      <span class="emotion-name">${emoEmoji[emo] || ""} ${emo}</span>
      <div class="emotion-bar-wrap">
        <div class="emotion-bar" style="width:${(score*100).toFixed(1)}%;background:${emoColors[emo]||'#888'}"></div>
      </div>
      <span class="emotion-score">${score.toFixed(3)}</span>
    `;
    grid.appendChild(row);
  }
}

function addToHistory(d) {
  history.unshift(d);
  const list = document.getElementById("history-list");
  if (history.length === 1) list.innerHTML = "";

  const el = document.createElement("div");
  el.className = "history-item";
  const badge = d.label === "POSITIVE" ? "🟢" : d.label === "NEGATIVE" ? "🔴" : "⚪";
  el.innerHTML = `
    <span style="font-size:18px;">${badge}</span>
    <span class="history-text">${d.text.slice(0, 80)}${d.text.length > 80 ? "..." : ""}</span>
    <span class="label-badge ${d.label}" style="white-space:nowrap;font-size:11px;">${d.label}</span>
    <span style="color:var(--muted);font-size:12px;white-space:nowrap;">${(d.confidence*100).toFixed(0)}%</span>
  `;
  list.prepend(el);
}

function updateStats(d) {
  stats.total++;
  if (d.label === "POSITIVE") stats.pos++;
  stats.confidences.push(d.confidence);

  document.getElementById("total-count").textContent = stats.total;
  document.getElementById("pos-rate").textContent = (stats.pos / stats.total * 100).toFixed(1) + "%";
  const avgConf = stats.confidences.reduce((a, b) => a + b, 0) / stats.confidences.length;
  document.getElementById("avg-conf").textContent = (avgConf * 100).toFixed(1) + "%";
}

function setLoading(on) {
  document.getElementById("spinner").style.display = on ? "block" : "none";
  document.getElementById("btn-label").textContent = on ? "Analyzing..." : "Analyze Sentiment";
}

async function runDemo() {
  const demos = [
    { text: "This product is absolutely amazing! Best purchase I've made all year. Highly recommended!", source: "amazon" },
    { text: "Worst experience ever. The item broke on day one. Complete waste of money.", source: "amazon" },
    { text: "I can't believe how AMAZING this concert was!!! 🔥🎵", source: "twitter" },
    { text: "The Federal Reserve raised interest rates amid growing economic concerns.", source: "news" },
  ];
  for (const d of demos) {
    document.getElementById("input-text").value = d.text;
    document.querySelectorAll(".source-tab").forEach(t => {
      t.classList.toggle("active", t.dataset.source === d.source);
    });
    selectedSource = d.source;
    await analyze();
    await new Promise(r => setTimeout(r, 600));
  }
}

function clearAll() {
  document.getElementById("input-text").value = "";
  document.getElementById("result-panel").style.display = "none";
}

// Allow Ctrl+Enter to analyze
document.getElementById("input-text").addEventListener("keydown", e => {
  if (e.ctrlKey && e.key === "Enter") analyze();
});
</script>

</body>
</html>
"""


# ------------------------------------------------------------------ #
#  Routes                                                              #
# ------------------------------------------------------------------ #

@app.route("/")
def index():
    return render_template_string(DASHBOARD_HTML)


@app.route("/api/analyze", methods=["POST"])
def api_analyze():
    """Analyze a single text string."""
    body = request.get_json(force=True)
    text   = body.get("text", "").strip()
    source = body.get("source", "generic")

    if not text:
        return jsonify({"error": "No text provided"}), 400

    try:
        analyzer = SentimentAnalyzer(mode=source)
        result   = analyzer.analyze(text)

        emotion_detector = EmotionDetector()
        emotion_result   = emotion_detector.detect(result.cleaned_text or text)

        response = result.to_dict()
        response["emotions"] = emotion_result.emotions
        response["dominant_emotion"] = emotion_result.dominant_emotion

        SESSION["history"].append(response)
        SESSION["total_analyzed"] += 1
        SESSION["label_counts"][result.label] = SESSION["label_counts"].get(result.label, 0) + 1

        return jsonify(response)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/upload", methods=["POST"])
def api_upload():
    """Accept a CSV file and return analysis summary."""
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file   = request.files["file"]
    source = request.form.get("source", "generic")

    try:
        df = pd.read_csv(io.StringIO(file.read().decode("utf-8")))

        # Find text column
        text_col = next(
            (c for c in ["review_text", "text", "tweet", "content", "title", "body"]
             if c in df.columns),
            df.columns[0]
        )

        analyzer   = SentimentAnalyzer(mode=source)
        result_df  = analyzer.analyze_dataframe(df, text_col)

        # Summary
        counts = result_df["label"].value_counts().to_dict()
        total  = len(result_df)

        return jsonify({
            "total":     total,
            "counts":    counts,
            "positive_pct": round(counts.get("POSITIVE", 0) / total * 100, 1),
            "negative_pct": round(counts.get("NEGATIVE", 0) / total * 100, 1),
            "neutral_pct":  round(counts.get("NEUTRAL",  0) / total * 100, 1),
            "avg_polarity": round(result_df["polarity"].mean(), 4),
            "avg_subjectivity": round(result_df["subjectivity"].mean(), 4),
            "sample_results": result_df.head(10).to_dict(orient="records"),
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/stats")
def api_stats():
    """Return session-wide statistics."""
    total = SESSION["total_analyzed"]
    counts = SESSION["label_counts"]
    return jsonify({
        "total_analyzed": total,
        "label_counts": counts,
        "positive_pct": round(counts.get("POSITIVE", 0) / max(total, 1) * 100, 1),
        "history_count": len(SESSION["history"]),
    })


@app.route("/api/demo")
def api_demo():
    """Run a full demo analysis on built-in samples."""
    samples = [
        {"text": "Absolutely loved this! Best purchase ever.", "source": "amazon"},
        {"text": "Terrible product. Broke immediately. Waste of money.", "source": "amazon"},
        {"text": "I can't believe how amazing this concert was!!! 🔥", "source": "twitter"},
        {"text": "The market showed mixed signals amid uncertainty.", "source": "news"},
        {"text": "Average experience. Nothing special but nothing bad.", "source": "generic"},
    ]

    results = []
    for s in samples:
        analyzer = SentimentAnalyzer(mode=s["source"])
        result = analyzer.analyze(s["text"])
        detector = EmotionDetector()
        emotion = detector.detect(s["text"])
        r = result.to_dict()
        r["emotions"] = emotion.emotions
        r["dominant_emotion"] = emotion.dominant_emotion
        results.append(r)

    return jsonify({"results": results, "count": len(results)})


# ------------------------------------------------------------------ #
#  Run                                                                 #
# ------------------------------------------------------------------ #

if __name__ == "__main__":
    print("🧠 Sentiment Analysis Dashboard starting...")
    print("   Visit: http://localhost:5000")
    app.run(debug=True, port=5000, host="0.0.0.0")
