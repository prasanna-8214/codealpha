# 📊 Data Visualization Portfolio

A comprehensive data visualization project showcasing interactive charts, dashboards, and data storytelling using **Python (Matplotlib, Seaborn, Plotly)** and a **live HTML/CSS/JS dashboard**.

---

## 🚀 Project Structure

```
data-viz-portfolio/
│
├── data/                        # Raw & processed datasets
│   ├── sales_data.csv
│   ├── world_population.csv
│   └── stock_prices.csv
│
├── notebooks/                   # Jupyter Notebooks
│   ├── 01_matplotlib_basics.ipynb
│   ├── 02_seaborn_advanced.ipynb
│   └── 03_plotly_interactive.ipynb
│
├── src/                         # Python source scripts
│   ├── generate_data.py
│   ├── matplotlib_charts.py
│   ├── seaborn_charts.py
│   ├── plotly_dashboard.py
│   └── utils.py
│
├── dashboard/index.html         # Standalone HTML dashboard
├── requirements.txt
└── README.md
```

---

## 📦 Installation

```bash
git clone https://github.com/YOUR_USERNAME/data-viz-portfolio.git
cd data-viz-portfolio
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

---

## 🎯 Features

| Visualization | Tool | Description |
|---|---|---|
| Bar, Line, Pie Charts | Matplotlib | Classic static charts with custom themes |
| Heatmaps, Pairplots | Seaborn | Statistical relationship visualizations |
| Interactive Charts | Plotly | Hover, zoom, filter interactivity |
| Live Dashboard | Dash + HTML | Real-time KPI & analytics dashboard |
| Data Story | Jupyter | Narrative-driven EDA notebooks |

---

## 🖥️ Running the Project

```bash
python src/generate_data.py       # Generate sample data
python src/matplotlib_charts.py   # Static charts → saved to assets/
python src/seaborn_charts.py      # Seaborn charts → saved to assets/
python src/plotly_dashboard.py    # Launch Dash at http://127.0.0.1:8050
```

Open `dashboard/index.html` in any browser for the standalone HTML dashboard.

---

## 🛠️ Tech Stack

Python 3.10+ · Matplotlib · Seaborn · Plotly/Dash · Pandas · NumPy · Chart.js · HTML5/CSS3

---

## 📚 License

MIT License
