"""
dashboard.py
============
Main interactive Dash application — the portfolio centerpiece.
A fully-featured, dark-themed analytics dashboard with:
  • KPI summary cards
  • Interactive time-series with filters
  • Treemap + choropleth side-by-side
  • Funnel & radar charts
  • Customer distribution deep-dive tab
  • 3D surface & animated bar race tab

Run:  python dashboard.py
URL:  http://127.0.0.1:8050
"""

import dash
from dash import dcc, html, Input, Output, callback
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np

# ── Local imports ──
from src.data.data_generator import (
    generate_sales_data, generate_customer_data,
    generate_funnel_data, generate_geo_data,
    generate_radar_data, generate_treemap_data, generate_stock_data
)
from src.utils.theme import (
    PALETTE_PRIMARY, BG_DARK, BG_CARD, TEXT_PRIMARY,
    TEXT_SECONDARY, BORDER_COLOR, PLOTLY_DARK_TEMPLATE
)
from src.components.advanced_charts import (
    plot_treemap_plotly, plot_choropleth,
    plot_3d_surface, plot_animated_bar_race,
    plot_funnel, plot_radar_chart
)


# ──────────────────────────────────────────────────────
# Data Load (cached at startup)
# ──────────────────────────────────────────────────────
print("⏳ Generating datasets…")
df_sales = generate_sales_data(36)
df_customers = generate_customer_data(1200)
df_funnel = generate_funnel_data()
df_geo = generate_geo_data()
df_radar = generate_radar_data()
df_treemap = generate_treemap_data()
df_stocks = generate_stock_data()
print("✅ All datasets ready.\n")

REGIONS = sorted(df_sales["region"].unique())
PRODUCTS = sorted(df_sales["product"].unique())


# ──────────────────────────────────────────────────────
# Plotly Chart Factory Functions
# ──────────────────────────────────────────────────────

LAYOUT_BASE = {
    **PLOTLY_DARK_TEMPLATE["layout"],
    "margin": dict(t=50, l=50, r=20, b=50),
    "height": 380,
}


def make_kpi_cards(df: pd.DataFrame) -> list:
    """Compute KPI metrics from sales data."""
    total_sales = df["sales"].sum()
    total_profit = df["profit"].sum()
    total_units = df["units"].sum()
    margin = total_profit / total_sales * 100

    # YoY comparison
    latest_year = df["year"].max()
    prev_year = latest_year - 1
    s_latest = df[df["year"] == latest_year]["sales"].sum()
    s_prev = df[df["year"] == prev_year]["sales"].sum()
    yoy = (s_latest - s_prev) / s_prev * 100 if s_prev > 0 else 0

    kpis = [
        {"label": "Total Revenue", "value": f"${total_sales/1e6:.1f}M",
         "delta": f"{'▲' if yoy >= 0 else '▼'} {abs(yoy):.1f}% YoY",
         "positive": yoy >= 0, "color": "#2563EB"},
        {"label": "Gross Profit", "value": f"${total_profit/1e6:.1f}M",
         "delta": f"Margin: {margin:.1f}%",
         "positive": True, "color": "#059669"},
        {"label": "Units Sold", "value": f"{total_units/1e3:.1f}K",
         "delta": "Across all channels",
         "positive": True, "color": "#7C3AED"},
        {"label": "Active Customers", "value": f"{len(df_customers):,}",
         "delta": f"Churn: {df_customers['churned'].mean()*100:.1f}%",
         "positive": df_customers["churned"].mean() < 0.1, "color": "#D97706"},
    ]
    return kpis


def revenue_line_fig(df: pd.DataFrame, regions: list, products: list) -> go.Figure:
    """Interactive revenue time series."""
    filtered = df[df["region"].isin(regions) & df["product"].isin(products)]
    monthly = (
        filtered.groupby(["date", "region"])["sales"]
        .sum().reset_index()
    )
    monthly["sales_M"] = monthly["sales"] / 1e6

    fig = px.line(
        monthly, x="date", y="sales_M", color="region",
        color_discrete_sequence=PALETTE_PRIMARY,
        labels={"sales_M": "Revenue ($M)", "date": "", "region": "Region"},
    )
    fig.update_traces(line_width=2, mode="lines+markers",
                      marker=dict(size=3))
    fig.update_layout(
        **LAYOUT_BASE,
        title="Monthly Revenue by Region",
        yaxis_tickprefix="$", yaxis_ticksuffix="M",
        legend=dict(orientation="h", y=1.1, x=0),
    )
    return fig


def channel_donut_fig(df: pd.DataFrame) -> go.Figure:
    """Donut chart for channel mix."""
    channel_rev = df.groupby("channel")["sales"].sum()
    fig = go.Figure(go.Pie(
        labels=channel_rev.index,
        values=channel_rev.values,
        hole=0.55,
        marker_colors=PALETTE_PRIMARY,
        textfont_size=11,
        textinfo="label+percent",
        hovertemplate="<b>%{label}</b><br>Revenue: $%{value:,.0f}<extra></extra>",
    ))
    total = channel_rev.sum()
    fig.add_annotation(
        text=f"${total/1e6:.0f}M<br><span style='font-size:10px;color:{TEXT_SECONDARY}'>Total</span>",
        x=0.5, y=0.5, showarrow=False,
        font=dict(size=16, color=TEXT_PRIMARY),
        xanchor="center",
    )
    fig.update_layout(
        **LAYOUT_BASE,
        title="Revenue by Sales Channel",
        showlegend=False,
        height=350,
    )
    return fig


def top_products_bar_fig(df: pd.DataFrame) -> go.Figure:
    """Horizontal bar for product ranking."""
    prod_rev = (
        df.groupby("product")["sales"].sum()
        .sort_values(ascending=True) / 1e6
    )
    fig = go.Figure(go.Bar(
        x=prod_rev.values,
        y=prod_rev.index,
        orientation="h",
        marker_color=PALETTE_PRIMARY[:len(prod_rev)],
        marker_line_color=BG_DARK,
        marker_line_width=0.5,
        text=[f"${v:.1f}M" for v in prod_rev.values],
        textposition="outside",
        textfont=dict(color=TEXT_PRIMARY, size=10),
        hovertemplate="<b>%{y}</b><br>Revenue: $%{x:.1f}M<extra></extra>",
    ))
    fig.update_layout(
        **LAYOUT_BASE,
        title="Revenue by Product",
        xaxis_tickprefix="$", xaxis_ticksuffix="M",
        height=320,
    )
    return fig


def customer_segment_fig(df: pd.DataFrame) -> go.Figure:
    """Scatter: income vs spend colored by segment."""
    sample = df.sample(600, random_state=42)
    fig = px.scatter(
        sample, x="income", y="annual_spend",
        color="segment", size="tenure_months",
        color_discrete_sequence=PALETTE_PRIMARY,
        opacity=0.65,
        hover_data=["age", "satisfaction_score", "churned"],
        labels={"income": "Annual Income ($)", "annual_spend": "Annual Spend ($)"},
    )
    fig.update_layout(
        **LAYOUT_BASE,
        title="Customer Income vs. Annual Spend",
        xaxis_tickprefix="$",
        yaxis_tickprefix="$",
        legend=dict(orientation="h", y=1.1),
    )
    return fig


def satisfaction_histogram(df: pd.DataFrame) -> go.Figure:
    """Histogram of satisfaction scores by segment."""
    fig = px.histogram(
        df, x="satisfaction_score", color="segment",
        nbins=20, barmode="overlay",
        color_discrete_sequence=PALETTE_PRIMARY,
        opacity=0.7,
        labels={"satisfaction_score": "Satisfaction Score (1–5)"},
    )
    fig.update_layout(
        **LAYOUT_BASE,
        title="Satisfaction Score Distribution by Segment",
        bargap=0.1,
    )
    return fig


def churn_by_segment_fig(df: pd.DataFrame) -> go.Figure:
    """Grouped bar: churn rate vs satisfaction by segment."""
    agg = df.groupby("segment").agg(
        churn_rate=("churned", "mean"),
        avg_satisfaction=("satisfaction_score", "mean"),
    ).reset_index()

    fig = go.Figure()
    fig.add_trace(go.Bar(
        name="Churn Rate",
        x=agg["segment"],
        y=agg["churn_rate"] * 100,
        marker_color=PALETTE_PRIMARY[4],
        yaxis="y1",
        text=[f"{v*100:.1f}%" for v in agg["churn_rate"]],
        textposition="outside",
    ))
    fig.add_trace(go.Scatter(
        name="Avg Satisfaction",
        x=agg["segment"],
        y=agg["avg_satisfaction"],
        mode="lines+markers+text",
        marker=dict(size=10, color=PALETTE_PRIMARY[1]),
        line=dict(width=2),
        yaxis="y2",
        text=[f"{v:.2f}" for v in agg["avg_satisfaction"]],
        textposition="top center",
    ))
    fig.update_layout(
        **LAYOUT_BASE,
        title="Churn Rate vs. Satisfaction by Segment",
        yaxis=dict(title="Churn Rate (%)", ticksuffix="%",
                   gridcolor=BORDER_COLOR, color=TEXT_SECONDARY),
        yaxis2=dict(title="Avg Satisfaction", overlaying="y", side="right",
                    range=[1, 5], gridcolor="transparent", color=TEXT_SECONDARY),
        legend=dict(orientation="h", y=1.1),
    )
    return fig


# ──────────────────────────────────────────────────────
# App Initialization
# ──────────────────────────────────────────────────────

app = dash.Dash(
    __name__,
    external_stylesheets=[dbc.themes.BOOTSTRAP],
    suppress_callback_exceptions=True,
    title="Data Viz Portfolio",
    meta_tags=[{"name": "viewport", "content": "width=device-width, initial-scale=1"}],
)

# Inline the CSS directly to avoid file path issues
INLINE_CSS = open("src/styles/dashboard.css").read()

kpis = make_kpi_cards(df_sales)


def kpi_card(kpi: dict) -> html.Div:
    return html.Div(className="kpi-card", style={"--accent-color": kpi["color"]}, children=[
        html.Div(kpi["label"], className="kpi-label"),
        html.Div(kpi["value"], className="kpi-value"),
        html.Div(kpi["delta"], className=f"kpi-delta {'positive' if kpi['positive'] else 'negative'}"),
    ])


# ──────────────────────────────────────────────────────
# Layout
# ──────────────────────────────────────────────────────

app.layout = html.Div([
    html.Style(INLINE_CSS),

    # ── Header ──
    html.Div(className="header", children=[
        html.Div([
            html.Div("📊 Data Visualization Portfolio", className="header-title"),
            html.Div("Interactive Analytics Dashboard | Python · Plotly · Dash",
                     className="header-subtitle"),
        ]),
        html.Div([
            html.Span("● ", style={"color": "#4ADE80", "fontSize": "0.7rem"}),
            html.Span("Live Dashboard", style={"color": TEXT_SECONDARY, "fontSize": "0.8rem"}),
        ]),
    ]),

    # ── Main Content ──
    html.Div(style={"padding": "24px 32px"}, children=[

        # ── KPI Row ──
        html.Div(style={"display": "grid", "gridTemplateColumns": "repeat(4, 1fr)",
                        "gap": "16px", "marginBottom": "24px"},
                 children=[kpi_card(k) for k in kpis]),

        # ── Filter Panel ──
        html.Div(className="control-panel", children=[
            html.Div(style={"display": "grid", "gridTemplateColumns": "1fr 1fr 1fr",
                            "gap": "20px", "alignItems": "end"}, children=[
                html.Div([
                    html.Div("Regions", className="control-label"),
                    dcc.Dropdown(
                        id="region-filter",
                        options=[{"label": r, "value": r} for r in REGIONS],
                        value=REGIONS, multi=True, clearable=False,
                    ),
                ]),
                html.Div([
                    html.Div("Products", className="control-label"),
                    dcc.Dropdown(
                        id="product-filter",
                        options=[{"label": p, "value": p} for p in PRODUCTS],
                        value=PRODUCTS, multi=True, clearable=False,
                    ),
                ]),
                html.Div([
                    html.Div("Year", className="control-label"),
                    dcc.Dropdown(
                        id="year-filter",
                        options=[{"label": str(y), "value": y}
                                 for y in sorted(df_sales["year"].unique())],
                        value=sorted(df_sales["year"].unique()),
                        multi=True, clearable=False,
                    ),
                ]),
            ]),
        ]),

        # ── Tabs ──
        dcc.Tabs(id="main-tabs", value="sales", className="custom-tabs", children=[

            # ── Tab 1: Sales Overview ──
            dcc.Tab(label="📈 Sales Overview", value="sales", children=[
                html.Div(style={"marginTop": "20px"}, children=[
                    # Revenue line chart (full width)
                    html.Div(className="chart-card", style={"marginBottom": "16px"}, children=[
                        dcc.Graph(id="revenue-line", config={"displayModeBar": False}),
                    ]),
                    # Channel donut + Product bar
                    html.Div(style={"display": "grid", "gridTemplateColumns": "1fr 1fr",
                                    "gap": "16px"}, children=[
                        html.Div(className="chart-card", children=[
                            dcc.Graph(id="channel-donut", config={"displayModeBar": False}),
                        ]),
                        html.Div(className="chart-card", children=[
                            dcc.Graph(id="product-bar", config={"displayModeBar": False}),
                        ]),
                    ]),
                ]),
            ]),

            # ── Tab 2: Geography ──
            dcc.Tab(label="🗺️ Geography", value="geo", children=[
                html.Div(style={"marginTop": "20px"}, children=[
                    html.Div(style={"display": "grid", "gridTemplateColumns": "3fr 2fr",
                                    "gap": "16px"}, children=[
                        html.Div(className="chart-card", children=[
                            dcc.Graph(
                                figure=plot_choropleth(df_geo),
                                config={"displayModeBar": True},
                                style={"height": "450px"},
                            ),
                        ]),
                        html.Div(className="chart-card", children=[
                            dcc.Graph(
                                figure=plot_treemap_plotly(df_treemap),
                                config={"displayModeBar": False},
                                style={"height": "450px"},
                            ),
                        ]),
                    ]),
                ]),
            ]),

            # ── Tab 3: Customers ──
            dcc.Tab(label="👥 Customers", value="customers", children=[
                html.Div(style={"marginTop": "20px"}, children=[
                    html.Div(style={"display": "grid", "gridTemplateColumns": "1fr 1fr",
                                    "gap": "16px", "marginBottom": "16px"}, children=[
                        html.Div(className="chart-card", children=[
                            dcc.Graph(
                                figure=customer_segment_fig(df_customers),
                                config={"displayModeBar": False},
                            ),
                        ]),
                        html.Div(className="chart-card", children=[
                            dcc.Graph(
                                figure=churn_by_segment_fig(df_customers),
                                config={"displayModeBar": False},
                            ),
                        ]),
                    ]),
                    html.Div(className="chart-card", children=[
                        dcc.Graph(
                            figure=satisfaction_histogram(df_customers),
                            config={"displayModeBar": False},
                        ),
                    ]),
                ]),
            ]),

            # ── Tab 4: Advanced ──
            dcc.Tab(label="🚀 Advanced", value="advanced", children=[
                html.Div(style={"marginTop": "20px"}, children=[
                    html.Div(style={"display": "grid", "gridTemplateColumns": "1fr 1fr",
                                    "gap": "16px", "marginBottom": "16px"}, children=[
                        html.Div(className="chart-card", children=[
                            dcc.Graph(
                                figure=plot_animated_bar_race(df_sales),
                                config={"displayModeBar": False},
                                style={"height": "400px"},
                            ),
                        ]),
                        html.Div(className="chart-card", children=[
                            dcc.Graph(
                                figure=plot_3d_surface(),
                                config={"displayModeBar": True},
                                style={"height": "400px"},
                            ),
                        ]),
                    ]),
                ]),
            ]),
        ]),
    ]),

    # Footer
    html.Div(
        "Data Visualization Portfolio | Built with Python, Plotly & Dash | Synthetic Data Only",
        style={
            "textAlign": "center", "padding": "16px",
            "color": TEXT_SECONDARY, "fontSize": "0.75rem",
            "borderTop": f"1px solid {BORDER_COLOR}", "marginTop": "20px",
        }
    ),
])


# ──────────────────────────────────────────────────────
# Callbacks
# ──────────────────────────────────────────────────────

@app.callback(
    Output("revenue-line", "figure"),
    Output("channel-donut", "figure"),
    Output("product-bar", "figure"),
    Input("region-filter", "value"),
    Input("product-filter", "value"),
    Input("year-filter", "value"),
)
def update_sales_charts(regions, products, years):
    filtered = df_sales[
        df_sales["region"].isin(regions) &
        df_sales["product"].isin(products) &
        df_sales["year"].isin(years)
    ]
    return (
        revenue_line_fig(filtered, regions, products),
        channel_donut_fig(filtered),
        top_products_bar_fig(filtered),
    )


# ──────────────────────────────────────────────────────
# Entry Point
# ──────────────────────────────────────────────────────

if __name__ == "__main__":
    print("\n🚀 Starting dashboard at http://127.0.0.1:8050\n")
    app.run(debug=True, host="127.0.0.1", port=8050)
