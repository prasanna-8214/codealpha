"""
generate_static_plots.py
========================
Batch generate all static Matplotlib & Seaborn charts.
Saves every chart to ./output/ as high-resolution PNG files.

Usage:
    python generate_static_plots.py
"""

import os
import sys
import time
import warnings

warnings.filterwarnings("ignore")

# ── Ensure src is importable ──
sys.path.insert(0, os.path.dirname(__file__))

from src.data.data_generator import load_all_datasets
from src.utils.helpers import section_header, ensure_output_dir, save_figure

from src.components.bar_charts import (
    plot_grouped_bar, plot_stacked_bar,
    plot_horizontal_bar, plot_diverging_bar,
)
from src.components.line_charts import (
    plot_multi_line, plot_area_chart,
    plot_candlestick, plot_gradient_line,
)
from src.components.heatmaps import (
    plot_correlation_heatmap, plot_pivot_heatmap,
    plot_calendar_heatmap, plot_clustermap,
)
from src.components.scatter_plots import (
    plot_bubble_chart, plot_violin_box,
    plot_pairplot, plot_hexbin,
)
from src.components.advanced_charts import (
    plot_funnel, plot_radar_chart,
    plot_treemap_plotly, plot_choropleth,
    plot_3d_surface, plot_animated_bar_race,
)


def main():
    print("\n" + "═" * 56)
    print("   📊  DATA VISUALIZATION PORTFOLIO — STATIC GENERATOR")
    print("═" * 56)

    # ── Load data ──
    section_header("Loading Datasets")
    t0 = time.time()
    data = load_all_datasets()
    df_sales = data["sales"]
    df_customers = data["customers"]
    df_stocks = data["stocks"]
    df_features = data["features"]
    df_funnel = data["funnel"]
    df_geo = data["geo"]
    df_radar = data["radar"]
    df_treemap = data["treemap"]
    print(f"  ✅ All datasets loaded in {time.time() - t0:.1f}s")

    # ── Output directory ──
    ensure_output_dir()
    ensure_output_dir("plotly_html")

    # ─────────────────────────────────────────────
    # BAR CHARTS
    # ─────────────────────────────────────────────
    section_header("Bar Charts")

    fig = plot_grouped_bar(df_sales)
    save_figure(fig, "01_grouped_bar_regional_sales.png")

    fig = plot_stacked_bar(df_sales)
    save_figure(fig, "02_stacked_bar_channel_mix.png")

    fig = plot_horizontal_bar(df_sales)
    save_figure(fig, "03_horizontal_bar_product_ranking.png")

    fig = plot_diverging_bar(df_sales)
    save_figure(fig, "04_diverging_bar_profit_variance.png")

    # ─────────────────────────────────────────────
    # LINE CHARTS
    # ─────────────────────────────────────────────
    section_header("Line Charts")

    fig = plot_multi_line(df_sales)
    save_figure(fig, "05_multi_line_revenue_trend.png")

    fig = plot_area_chart(df_sales)
    save_figure(fig, "06_area_chart_product_revenue.png")

    fig = plot_candlestick(df_stocks, ticker="ALPHA")
    save_figure(fig, "07_candlestick_stock_chart.png")

    fig = plot_gradient_line(df_customers)
    save_figure(fig, "08_gradient_line_satisfaction.png")

    # ─────────────────────────────────────────────
    # HEATMAPS
    # ─────────────────────────────────────────────
    section_header("Heatmaps")

    fig = plot_correlation_heatmap(df_features)
    save_figure(fig, "09_correlation_heatmap.png")

    fig = plot_pivot_heatmap(df_sales)
    save_figure(fig, "10_pivot_heatmap_monthly_sales.png")

    fig = plot_calendar_heatmap(df_sales)
    save_figure(fig, "11_calendar_heatmap_daily_revenue.png")

    fig = plot_clustermap(df_customers)
    save_figure(fig, "12_clustermap_customer_segments.png")

    # ─────────────────────────────────────────────
    # SCATTER / DISTRIBUTION PLOTS
    # ─────────────────────────────────────────────
    section_header("Scatter & Distribution")

    fig = plot_bubble_chart(df_customers)
    save_figure(fig, "13_bubble_chart_income_spend.png")

    fig = plot_violin_box(df_customers)
    save_figure(fig, "14_violin_box_spend_distribution.png")

    fig = plot_pairplot(df_customers)
    save_figure(fig, "15_pairplot_feature_matrix.png")

    fig = plot_hexbin(df_customers)
    save_figure(fig, "16_hexbin_income_spend_density.png")

    # ─────────────────────────────────────────────
    # ADVANCED (Matplotlib)
    # ─────────────────────────────────────────────
    section_header("Advanced Charts (Matplotlib)")

    fig = plot_funnel(df_funnel)
    save_figure(fig, "17_funnel_marketing_conversion.png")

    fig = plot_radar_chart(df_radar)
    save_figure(fig, "18_radar_competitive_kpi.png")

    # ─────────────────────────────────────────────
    # INTERACTIVE CHARTS → HTML (Plotly)
    # ─────────────────────────────────────────────
    section_header("Interactive Charts (Plotly → HTML)")

    plotly_charts = {
        "19_treemap_product_revenue.html": plot_treemap_plotly(df_treemap),
        "20_choropleth_us_states.html": plot_choropleth(df_geo),
        "21_3d_surface_revenue_landscape.html": plot_3d_surface(),
        "22_animated_bar_race.html": plot_animated_bar_race(df_sales),
    }

    for filename, fig in plotly_charts.items():
        path = f"output/plotly_html/{filename}"
        fig.write_html(path, include_plotlyjs="cdn", full_html=True)
        print(f"  💾 Saved → {path}")

    # ─────────────────────────────────────────────
    # Summary
    # ─────────────────────────────────────────────
    total_time = time.time() - t0
    print("\n" + "═" * 56)
    print(f"  ✅  All charts generated in {total_time:.1f}s")
    print(f"  📁  Static PNGs  → ./output/")
    print(f"  🌐  Interactive  → ./output/plotly_html/")
    print("═" * 56 + "\n")


if __name__ == "__main__":
    main()
