# Design Decisions & Data Storytelling Guide

## Philosophy

This portfolio follows the **"story first, chart second"** principle: every visual answers a specific business question.

---

## Chart Selection Matrix

| Question | Best Chart | Why |
|---|---|---|
| How does revenue change monthly? | Grouped/stacked bar | Comparison + composition |
| What is the category revenue share? | Donut chart | Part-to-whole ratio |
| Is there a revenue-profit correlation? | Scatter + trendline | Relationship detection |
| How do regions trend over time? | Multi-line chart | Trends + comparison |
| How are discounts distributed? | Histogram + KDE | Distribution shape |
| Who are the top performers? | Horizontal bar | Ranking |
| What correlates with what? | Heatmap | Multi-variable correlation |
| GDP vs life expectancy? | Bubble chart | 3-variable relationship |

---

## Colour Palette Rationale

- Dark background (#0F172A): Reduces eye strain, improves data contrast
- Blue (#2563EB) as primary: Trust signal for financial data
- Green (#16A34A) for profit/positive: Universal positive signal
- Amber (#D97706) for discounts: Draws attention without alarm
- Violet (#7C3AED) for derived metrics: Distinct from raw data

---

## Accessibility

- Colour + shape encoding (never colour alone)
- Minimum 4.5:1 contrast ratio on text
- All charts have axis labels and titles
- Hover tooltips for precise values

---

## Tools Comparison

| Tool | Strength | Use case |
|---|---|---|
| Matplotlib | Full control, publication quality | Static exports, reports |
| Seaborn | Statistical beauty, less code | EDA, correlation analysis |
| Plotly/Dash | Interactivity, web embedding | Dashboards, presentations |
| Chart.js | Zero dependencies, browser native | Shareable HTML reports |
