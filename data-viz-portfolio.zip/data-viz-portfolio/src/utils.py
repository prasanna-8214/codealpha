"""
utils.py
--------
Shared utility functions for all visualization scripts.
"""

import os
import pandas as pd
import matplotlib.pyplot as plt

DATA_DIR   = os.path.join(os.path.dirname(__file__), '..', 'data')
ASSETS_DIR = os.path.join(os.path.dirname(__file__), '..', 'assets')
os.makedirs(ASSETS_DIR, exist_ok=True)


def load_sales():
    return pd.read_csv(os.path.join(DATA_DIR, 'sales_data.csv'), parse_dates=['date'])

def load_population():
    return pd.read_csv(os.path.join(DATA_DIR, 'world_population.csv'))

def load_stocks():
    return pd.read_csv(os.path.join(DATA_DIR, 'stock_prices.csv'), parse_dates=['date'])


def save_fig(filename: str, dpi: int = 150):
    """Save the current matplotlib figure to the assets/ directory."""
    path = os.path.join(ASSETS_DIR, filename)
    plt.savefig(path, dpi=dpi, bbox_inches='tight')
    print(f"  💾 Saved → assets/{filename}")


# ─── Custom Matplotlib theme ──────────────────────────────────────────────────
PALETTE = ['#2563EB', '#16A34A', '#DC2626', '#D97706', '#7C3AED',
           '#0891B2', '#BE185D', '#65A30D', '#9333EA', '#EA580C']

def apply_theme():
    plt.rcParams.update({
        'figure.facecolor'  : '#0F172A',
        'axes.facecolor'    : '#1E293B',
        'axes.edgecolor'    : '#334155',
        'axes.labelcolor'   : '#CBD5E1',
        'axes.titlecolor'   : '#F1F5F9',
        'axes.titlesize'    : 14,
        'axes.labelsize'    : 11,
        'xtick.color'       : '#94A3B8',
        'ytick.color'       : '#94A3B8',
        'grid.color'        : '#334155',
        'grid.linestyle'    : '--',
        'grid.alpha'        : 0.5,
        'text.color'        : '#F1F5F9',
        'legend.facecolor'  : '#1E293B',
        'legend.edgecolor'  : '#334155',
        'figure.titlesize'  : 18,
        'font.family'       : 'DejaVu Sans',
    })
