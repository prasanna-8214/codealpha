"""
matplotlib_charts.py
--------------------
Creates 6 publication-quality static charts using Matplotlib.
Charts are saved to the assets/ directory.

Charts:
  1. Monthly Revenue Bar Chart
  2. Category Revenue Pie Chart
  3. Revenue vs Profit Scatter
  4. Multi-line Sales Trend by Region
  5. Discount Distribution Histogram
  6. Annotated Top-10 Salesperson Chart
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from matplotlib.patches import FancyArrowPatch

from utils import load_sales, save_fig, apply_theme, PALETTE

apply_theme()


def chart1_monthly_revenue(df):
    """Grouped bar chart: monthly revenue by year."""
    df['month'] = df['date'].dt.month
    df['year']  = df['date'].dt.year

    monthly = df.groupby(['year', 'month'])['revenue'].sum().reset_index()
    years   = sorted(monthly['year'].unique())
    months  = range(1, 13)
    month_labels = ['Jan','Feb','Mar','Apr','May','Jun',
                    'Jul','Aug','Sep','Oct','Nov','Dec']

    x     = np.arange(12)
    width = 0.35
    fig, ax = plt.subplots(figsize=(13, 6))
    fig.suptitle('Monthly Revenue by Year', fontsize=18, fontweight='bold', y=1.01)

    for i, year in enumerate(years):
        vals = [monthly[(monthly.year==year) & (monthly.month==m)]['revenue'].sum()
                for m in months]
        bars = ax.bar(x + i*width, vals, width, label=str(year),
                      color=PALETTE[i], alpha=0.85, edgecolor='#0F172A', linewidth=0.5)
        for bar in bars:
            h = bar.get_height()
            if h > 0:
                ax.text(bar.get_x() + bar.get_width()/2, h + 200,
                        f'${h/1000:.0f}K', ha='center', va='bottom',
                        fontsize=7, color='#CBD5E1')

    ax.set_xticks(x + width/2)
    ax.set_xticklabels(month_labels)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v,_: f'${v/1000:.0f}K'))
    ax.set_ylabel('Revenue')
    ax.legend(title='Year', loc='upper left')
    ax.grid(axis='y', alpha=0.4)
    plt.tight_layout()
    save_fig('01_monthly_revenue_bar.png')
    plt.close()


def chart2_category_pie(df):
    """Donut chart: revenue share by category."""
    cat_rev = df.groupby('category')['revenue'].sum().sort_values(ascending=False)

    fig, ax = plt.subplots(figsize=(8, 8))
    wedges, texts, autotexts = ax.pie(
        cat_rev.values,
        labels=cat_rev.index,
        autopct='%1.1f%%',
        startangle=140,
        colors=PALETTE[:len(cat_rev)],
        pctdistance=0.78,
        wedgeprops=dict(width=0.55, edgecolor='#0F172A', linewidth=2),
    )
    for t in texts:
        t.set_color('#CBD5E1'); t.set_fontsize(12)
    for at in autotexts:
        at.set_color('white'); at.set_fontweight('bold'); at.set_fontsize(10)

    ax.set_title('Revenue Share by Product Category', fontsize=16, fontweight='bold', pad=20)
    centre = plt.Circle((0, 0), 0.45, fc='#1E293B')
    ax.add_patch(centre)
    ax.text(0, 0, f'Total\n${cat_rev.sum()/1e6:.1f}M',
            ha='center', va='center', fontsize=13, fontweight='bold', color='#F1F5F9')
    save_fig('02_category_donut.png')
    plt.close()


def chart3_scatter_revenue_profit(df):
    """Scatter plot with color-coded regions."""
    fig, ax = plt.subplots(figsize=(10, 7))
    regions = df['region'].unique()
    for i, region in enumerate(regions):
        sub = df[df['region'] == region]
        ax.scatter(sub['revenue'], sub['profit'],
                   label=region, alpha=0.6, s=40,
                   color=PALETTE[i], edgecolors='none')

    # Trend line
    z = np.polyfit(df['revenue'], df['profit'], 1)
    p = np.poly1d(z)
    x_line = np.linspace(df['revenue'].min(), df['revenue'].max(), 200)
    ax.plot(x_line, p(x_line), '--', color='#F59E0B', linewidth=1.5,
            label='Trend', alpha=0.9)

    ax.set_xlabel('Revenue ($)')
    ax.set_ylabel('Profit ($)')
    ax.set_title('Revenue vs Profit by Region', fontsize=16, fontweight='bold')
    ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda v,_: f'${v:,.0f}'))
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v,_: f'${v:,.0f}'))
    ax.legend(title='Region')
    ax.grid(alpha=0.3)
    plt.tight_layout()
    save_fig('03_revenue_profit_scatter.png')
    plt.close()


def chart4_region_trend(df):
    """Multi-line chart: cumulative revenue over time per region."""
    df_sorted = df.sort_values('date')
    df_sorted['month_year'] = df_sorted['date'].dt.to_period('M')
    monthly = df_sorted.groupby(['month_year','region'])['revenue'].sum().reset_index()
    monthly['month_year'] = monthly['month_year'].dt.to_timestamp()

    fig, ax = plt.subplots(figsize=(13, 6))
    for i, region in enumerate(monthly['region'].unique()):
        sub = monthly[monthly['region']==region].sort_values('month_year')
        sub = sub.copy()
        sub['cumulative'] = sub['revenue'].cumsum()
        ax.plot(sub['month_year'], sub['cumulative'],
                label=region, color=PALETTE[i], linewidth=2.5, marker='o',
                markersize=4, alpha=0.9)
        # Annotate last point
        last = sub.iloc[-1]
        ax.annotate(f"${last['cumulative']/1000:.0f}K",
                    xy=(last['month_year'], last['cumulative']),
                    xytext=(5, 5), textcoords='offset points',
                    fontsize=8, color=PALETTE[i])

    ax.set_title('Cumulative Revenue by Region Over Time', fontsize=16, fontweight='bold')
    ax.set_xlabel('Month')
    ax.set_ylabel('Cumulative Revenue')
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v,_: f'${v/1000:.0f}K'))
    ax.legend(title='Region', loc='upper left')
    ax.grid(alpha=0.3)
    fig.autofmt_xdate()
    plt.tight_layout()
    save_fig('04_region_trend_line.png')
    plt.close()


def chart5_discount_histogram(df):
    """Histogram + KDE: discount distribution by category."""
    from scipy.stats import gaussian_kde

    fig, ax = plt.subplots(figsize=(10, 6))
    categories = df['category'].unique()

    for i, cat in enumerate(categories):
        vals = df[df['category']==cat]['discount'].values
        ax.hist(vals, bins=15, alpha=0.35, color=PALETTE[i], label=cat, density=True)
        kde = gaussian_kde(vals)
        x_range = np.linspace(0, 0.35, 200)
        ax.plot(x_range, kde(x_range), color=PALETTE[i], linewidth=2)

    ax.set_xlabel('Discount Rate')
    ax.set_ylabel('Density')
    ax.set_title('Discount Distribution by Category', fontsize=16, fontweight='bold')
    ax.legend(title='Category')
    ax.grid(alpha=0.3)
    plt.tight_layout()
    save_fig('05_discount_histogram.png')
    plt.close()


def chart6_top_salespeople(df):
    """Horizontal bar: top 10 salespeople by revenue."""
    top10 = (df.groupby('salesperson')['revenue']
               .sum()
               .sort_values(ascending=False)
               .head(10))

    fig, ax = plt.subplots(figsize=(10, 6))
    colors = [PALETTE[0]] + ['#334155'] * 9
    bars = ax.barh(top10.index[::-1], top10.values[::-1],
                   color=colors[::-1], edgecolor='#0F172A', linewidth=0.5)

    for bar in bars:
        w = bar.get_width()
        ax.text(w + 500, bar.get_y() + bar.get_height()/2,
                f'${w:,.0f}', va='center', fontsize=9, color='#CBD5E1')

    ax.set_title('Top 10 Salespeople by Total Revenue', fontsize=16, fontweight='bold')
    ax.set_xlabel('Total Revenue ($)')
    ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda v,_: f'${v/1000:.0f}K'))
    ax.grid(axis='x', alpha=0.3)
    plt.tight_layout()
    save_fig('06_top_salespeople.png')
    plt.close()


if __name__ == '__main__':
    print("📊 Generating Matplotlib charts...\n")
    df = load_sales()
    chart1_monthly_revenue(df)
    chart2_category_pie(df)
    chart3_scatter_revenue_profit(df)
    chart4_region_trend(df)
    chart5_discount_histogram(df)
    chart6_top_salespeople(df)
    print("\n✅ All Matplotlib charts saved to assets/")
