"""
theme.py
========
Custom Matplotlib & Seaborn theme definitions for a consistent, professional look.
Defines color palettes, typography settings, and rcParam configurations.
"""

import matplotlib.pyplot as plt
import matplotlib as mpl
import seaborn as sns
from cycler import cycler


# ─────────────────────────────────────────────
# Color Palettes
# ─────────────────────────────────────────────

PALETTE_PRIMARY = [
    "#2563EB",  # Blue 600
    "#7C3AED",  # Violet 600
    "#059669",  # Emerald 600
    "#D97706",  # Amber 600
    "#DC2626",  # Red 600
    "#0891B2",  # Cyan 600
    "#4F46E5",  # Indigo 600
    "#65A30D",  # Lime 600
]

PALETTE_MUTED = [
    "#93C5FD",  # Blue 300
    "#C4B5FD",  # Violet 300
    "#6EE7B7",  # Emerald 300
    "#FCD34D",  # Amber 300
    "#FCA5A5",  # Red 300
    "#67E8F9",  # Cyan 300
    "#A5B4FC",  # Indigo 300
    "#BEF264",  # Lime 300
]

PALETTE_DIVERGING = [
    "#DC2626", "#F97316", "#FBBF24",
    "#F3F4F6",
    "#60A5FA", "#3B82F6", "#1D4ED8"
]

PALETTE_SEQUENTIAL_BLUE = [
    "#EFF6FF", "#DBEAFE", "#BFDBFE",
    "#93C5FD", "#60A5FA", "#3B82F6",
    "#2563EB", "#1D4ED8", "#1E40AF", "#1E3A8A"
]

PALETTE_SEQUENTIAL_GREEN = [
    "#F0FDF4", "#DCFCE7", "#BBF7D0",
    "#86EFAC", "#4ADE80", "#22C55E",
    "#16A34A", "#15803D", "#166534", "#14532D"
]

# Background and surface colors
BG_DARK = "#0F172A"
BG_CARD = "#1E293B"
TEXT_PRIMARY = "#F8FAFC"
TEXT_SECONDARY = "#94A3B8"
BORDER_COLOR = "#334155"

BG_LIGHT = "#F8FAFC"
TEXT_ON_LIGHT = "#0F172A"
BORDER_LIGHT = "#E2E8F0"


# ─────────────────────────────────────────────
# Apply Themes
# ─────────────────────────────────────────────

def apply_dark_theme():
    """
    Apply a dark, high-contrast Matplotlib theme.
    Best for dashboards and presentation slides.
    """
    mpl.rcParams.update({
        # Figure
        "figure.facecolor": BG_DARK,
        "figure.edgecolor": BG_DARK,
        "figure.dpi": 150,
        "figure.autolayout": True,

        # Axes
        "axes.facecolor": BG_CARD,
        "axes.edgecolor": BORDER_COLOR,
        "axes.labelcolor": TEXT_SECONDARY,
        "axes.titlecolor": TEXT_PRIMARY,
        "axes.titlesize": 14,
        "axes.titleweight": "bold",
        "axes.labelsize": 11,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "axes.prop_cycle": cycler(color=PALETTE_PRIMARY),

        # Grid
        "grid.color": BORDER_COLOR,
        "grid.linewidth": 0.6,
        "grid.alpha": 0.4,

        # Ticks
        "xtick.color": TEXT_SECONDARY,
        "ytick.color": TEXT_SECONDARY,
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,

        # Legend
        "legend.facecolor": BG_CARD,
        "legend.edgecolor": BORDER_COLOR,
        "legend.labelcolor": TEXT_PRIMARY,
        "legend.fontsize": 9,

        # Lines
        "lines.linewidth": 2.0,
        "lines.markersize": 6,

        # Patches
        "patch.edgecolor": BG_DARK,

        # Font
        "font.family": "DejaVu Sans",
        "font.size": 10,

        # Save
        "savefig.facecolor": BG_DARK,
        "savefig.edgecolor": BG_DARK,
        "savefig.bbox": "tight",
        "savefig.dpi": 200,
    })


def apply_light_theme():
    """
    Apply a clean, minimal light Matplotlib theme.
    Best for reports, papers, and print-ready outputs.
    """
    mpl.rcParams.update({
        "figure.facecolor": BG_LIGHT,
        "figure.edgecolor": BG_LIGHT,
        "figure.dpi": 150,
        "figure.autolayout": True,

        "axes.facecolor": "#FFFFFF",
        "axes.edgecolor": BORDER_LIGHT,
        "axes.labelcolor": "#475569",
        "axes.titlecolor": TEXT_ON_LIGHT,
        "axes.titlesize": 14,
        "axes.titleweight": "bold",
        "axes.labelsize": 11,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "axes.prop_cycle": cycler(color=PALETTE_PRIMARY),

        "grid.color": "#E2E8F0",
        "grid.linewidth": 0.8,
        "grid.alpha": 0.7,

        "xtick.color": "#64748B",
        "ytick.color": "#64748B",
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,

        "legend.facecolor": "#FFFFFF",
        "legend.edgecolor": BORDER_LIGHT,
        "legend.fontsize": 9,

        "lines.linewidth": 2.0,
        "lines.markersize": 6,

        "font.family": "DejaVu Sans",
        "font.size": 10,

        "savefig.facecolor": BG_LIGHT,
        "savefig.bbox": "tight",
        "savefig.dpi": 200,
    })


def apply_seaborn_theme(style: str = "darkgrid", palette: str = "primary"):
    """
    Apply a Seaborn theme with custom palette.
    style: 'darkgrid', 'whitegrid', 'dark', 'white', 'ticks'
    palette: 'primary', 'muted', 'diverging'
    """
    palette_map = {
        "primary": PALETTE_PRIMARY,
        "muted": PALETTE_MUTED,
        "diverging": PALETTE_DIVERGING,
    }
    chosen_palette = palette_map.get(palette, PALETTE_PRIMARY)
    sns.set_theme(style=style, palette=chosen_palette, font_scale=1.1)
    sns.set_palette(chosen_palette)


# ─────────────────────────────────────────────
# Plotly Theme Config
# ─────────────────────────────────────────────

PLOTLY_DARK_TEMPLATE = {
    "layout": {
        "paper_bgcolor": BG_DARK,
        "plot_bgcolor": BG_CARD,
        "font": {"color": TEXT_PRIMARY, "family": "Inter, sans-serif"},
        "title": {"font": {"size": 18, "color": TEXT_PRIMARY}},
        "xaxis": {
            "gridcolor": BORDER_COLOR,
            "zerolinecolor": BORDER_COLOR,
            "tickcolor": TEXT_SECONDARY,
            "color": TEXT_SECONDARY,
        },
        "yaxis": {
            "gridcolor": BORDER_COLOR,
            "zerolinecolor": BORDER_COLOR,
            "tickcolor": TEXT_SECONDARY,
            "color": TEXT_SECONDARY,
        },
        "legend": {
            "bgcolor": BG_CARD,
            "bordercolor": BORDER_COLOR,
            "font": {"color": TEXT_PRIMARY},
        },
        "colorway": PALETTE_PRIMARY,
    }
}

PLOTLY_LIGHT_TEMPLATE = {
    "layout": {
        "paper_bgcolor": BG_LIGHT,
        "plot_bgcolor": "#FFFFFF",
        "font": {"color": TEXT_ON_LIGHT, "family": "Inter, sans-serif"},
        "title": {"font": {"size": 18, "color": TEXT_ON_LIGHT}},
        "xaxis": {
            "gridcolor": BORDER_LIGHT,
            "zerolinecolor": BORDER_LIGHT,
            "tickcolor": "#64748B",
            "color": "#64748B",
        },
        "yaxis": {
            "gridcolor": BORDER_LIGHT,
            "zerolinecolor": BORDER_LIGHT,
            "tickcolor": "#64748B",
            "color": "#64748B",
        },
        "legend": {"bgcolor": "#FFFFFF", "bordercolor": BORDER_LIGHT},
        "colorway": PALETTE_PRIMARY,
    }
}


def reset_theme():
    """Reset Matplotlib to its defaults."""
    mpl.rcParams.update(mpl.rcParamsDefault)
