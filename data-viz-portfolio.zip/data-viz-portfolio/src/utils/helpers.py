"""
helpers.py
==========
Shared utility functions for annotations, formatting, and output management.
"""

import os
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
from pathlib import Path


# ─────────────────────────────────────────────
# Output Directory
# ─────────────────────────────────────────────

OUTPUT_DIR = Path("output")


def ensure_output_dir(subdir: str = "") -> Path:
    """Create output directory (and optional subdirectory) if it doesn't exist."""
    path = OUTPUT_DIR / subdir if subdir else OUTPUT_DIR
    path.mkdir(parents=True, exist_ok=True)
    return path


def save_figure(fig: plt.Figure, filename: str, subdir: str = "") -> str:
    """
    Save a Matplotlib figure to the output directory.
    Returns the full saved path as a string.
    """
    out_dir = ensure_output_dir(subdir)
    filepath = out_dir / filename
    fig.savefig(filepath)
    plt.close(fig)
    print(f"  💾 Saved → {filepath}")
    return str(filepath)


# ─────────────────────────────────────────────
# Annotation Helpers
# ─────────────────────────────────────────────

def annotate_bars(ax, fmt: str = "{:.0f}", fontsize: int = 8,
                  color: str = "white", padding: float = 0.5):
    """Annotate bar chart bars with their values."""
    for bar in ax.patches:
        h = bar.get_height()
        if h > 0:
            ax.annotate(
                fmt.format(h),
                xy=(bar.get_x() + bar.get_width() / 2, h),
                xytext=(0, padding),
                textcoords="offset points",
                ha="center", va="bottom",
                fontsize=fontsize, color=color, fontweight="bold"
            )


def add_trend_line(ax, x, y, color: str = "#F59E0B", lw: float = 1.5, ls: str = "--"):
    """Overlay a simple linear trend line on an axes."""
    z = np.polyfit(np.arange(len(x)), y, 1)
    p = np.poly1d(z)
    ax.plot(x, p(np.arange(len(x))), color=color, linewidth=lw,
            linestyle=ls, label="Trend", zorder=5)


def add_chart_subtitle(ax, subtitle: str, color: str = "#94A3B8"):
    """Add a subtitle below the axis title."""
    title = ax.get_title()
    ax.set_title(title, pad=30)
    ax.text(
        0.5, 1.02, subtitle,
        transform=ax.transAxes,
        ha="center", va="bottom",
        fontsize=9, color=color, style="italic"
    )


def add_watermark(fig, text: str = "Data Viz Portfolio", alpha: float = 0.06):
    """Add a subtle watermark to a figure."""
    fig.text(
        0.5, 0.5, text,
        transform=fig.transFigure,
        fontsize=40, color="gray",
        alpha=alpha, ha="center", va="center",
        rotation=30, fontweight="bold"
    )


def add_source_note(fig, source: str = "Source: Synthetic Data", color: str = "#64748B"):
    """Add a source note at the bottom of a figure."""
    fig.text(
        0.01, 0.01, source,
        ha="left", va="bottom",
        fontsize=7, color=color, style="italic"
    )


# ─────────────────────────────────────────────
# Number Formatting
# ─────────────────────────────────────────────

def fmt_currency(val: float, symbol: str = "$") -> str:
    """Format a number as currency with K/M/B suffixes."""
    if abs(val) >= 1_000_000_000:
        return f"{symbol}{val / 1_000_000_000:.1f}B"
    elif abs(val) >= 1_000_000:
        return f"{symbol}{val / 1_000_000:.1f}M"
    elif abs(val) >= 1_000:
        return f"{symbol}{val / 1_000:.1f}K"
    return f"{symbol}{val:.2f}"


def fmt_pct(val: float, decimals: int = 1) -> str:
    """Format a decimal as percentage string."""
    return f"{val * 100:.{decimals}f}%"


def fmt_number(val: float) -> str:
    """Format large numbers with commas."""
    return f"{val:,.0f}"


# ─────────────────────────────────────────────
# Color Utilities
# ─────────────────────────────────────────────

def hex_to_rgba(hex_color: str, alpha: float = 1.0) -> tuple:
    """Convert hex color to RGBA tuple (0–1 range)."""
    hex_color = hex_color.lstrip("#")
    r, g, b = (int(hex_color[i:i+2], 16) / 255 for i in (0, 2, 4))
    return (r, g, b, alpha)


def make_colormap(colors: list, name: str = "custom_cmap"):
    """Create a LinearSegmentedColormap from a list of hex colors."""
    from matplotlib.colors import LinearSegmentedColormap
    rgba_colors = [hex_to_rgba(c) for c in colors]
    return LinearSegmentedColormap.from_list(name, rgba_colors)


# ─────────────────────────────────────────────
# Print Utilities
# ─────────────────────────────────────────────

def section_header(title: str):
    """Print a styled section header to console."""
    line = "─" * (len(title) + 4)
    print(f"\n┌{line}┐")
    print(f"│  {title}  │")
    print(f"└{line}┘")
