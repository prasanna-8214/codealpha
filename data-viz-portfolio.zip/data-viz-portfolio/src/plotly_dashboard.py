"""
plotly_dashboard.py
-------------------
Full interactive Dash dashboard with 4 chart panels.

Layout:
  ┌─────────────────┬─────────────────┐
  │  KPI Cards      │  KPI Cards      │
  ├─────────────────┴─────────────────┤
  │  Line: Stock Prices (filterable)  │
  ├─────────────────┬─────────────────┤
  │  Bar: Revenue   │  Scatter: World │
  │  by Category    │  Population     │
  └─────────────────┴─────────────────┘

Run:  python src/plotly_dashboard.py
Open: http://127.0.0.1:8050
"""

import os
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from dash import Dash, dcc, html, Input, Output, callback

from utils import load_sales, load_population, load_stocks

# ─── Load data ────────────────────────────────────────────────────────────────
sales  = load_sales()
stocks = load_stocks()
pop    = load_population()

# ─── KPI helpers ──────────────────────────────────────────────────────────────
total_revenue  = sales['revenue'].sum()
total_profit   = sales['profit'].sum()
total_units    = sales['units_sold'].sum()
avg_discount   = sales['discount'].mean() * 100
profit_margin  = (total_profit / total_revenue) * 100

# ─── Colour palette ───────────────────────────────────────────────────────────
BG      = '#0F172A'
CARD_BG = '#1E293B'
BORDER  = '#334155'
TEXT    = '#F1F5F9'
MUTED   = '#94A3B8'
ACCENT  = '#2563EB'
GREEN   = '#16A34A'
RED     = '#DC2626'

COLORS = ['#2563EB','#16A34A','#DC2626','#D97706','#7C3AED']

# ─── App init ─────────────────────────────────────────────────────────────────
app = Dash(__name__, title='Sales & Markets Dashboard')
app.layout = html.Div(style={'backgroundColor': BG, 'minHeight': '100vh',
                              'fontFamily': 'Segoe UI, sans-serif', 'padding': '24px'}, children=[

    # Header
    html.Div([
        html.H1('📊 Sales & Markets Dashboard',
                style={'color': TEXT, 'margin': 0, 'fontSize': '26px', 'fontWeight': 700}),
        html.P('Interactive analytics · 2022–2023 Synthetic Data',
               style={'color': MUTED, 'margin': '4px 0 0 0', 'fontSize': '13px'}),
    ], style={'marginBottom': '28px'}),

    # ── KPI Cards ──────────────────────────────────────────────────────────────
    html.Div([
        *[html.Div([
            html.P(label, style={'color': MUTED, 'fontSize': '11px',
                                  'margin': '0 0 4px 0', 'textTransform': 'uppercase',
                                  'letterSpacing': '0.08em'}),
            html.H2(value, style={'color': color, 'margin': 0,
                                   'fontSize': '28px', 'fontWeight': 700}),
            html.P(sub, style={'color': MUTED, 'fontSize': '11px', 'margin': '4px 0 0 0'}),
        ], style={'backgroundColor': CARD_BG, 'border': f'1px solid {BORDER}',
                  'borderRadius': '10px', 'padding': '18px 22px',
                  'flex': '1', 'minWidth': '160px'})
        for label, value, sub, color in [
            ('Total Revenue',  f'${total_revenue/1e6:.2f}M', 'Across all regions',   ACCENT),
            ('Total Profit',   f'${total_profit/1e6:.2f}M',  f'Margin {profit_margin:.1f}%', GREEN),
            ('Units Sold',     f'{total_units:,}',           'Across all categories', TEXT),
            ('Avg Discount',   f'{avg_discount:.1f}%',       'Applied to orders',     '#D97706'),
            ('Profit Margin',  f'{profit_margin:.1f}%',      'Revenue → Profit',      '#7C3AED'),
        ]],
    ], style={'display': 'flex', 'gap': '16px', 'flexWrap': 'wrap', 'marginBottom': '24px'}),

    # ── Stock Chart + Controls ─────────────────────────────────────────────────
    html.Div([
        html.Div([
            html.Div([
                html.H3('Stock Price Trends', style={'color': TEXT, 'margin': 0,
                                                      'fontSize': '15px', 'fontWeight': 600}),
                dcc.Checklist(
                    id='stock-ticker-filter',
                    options=[{'label': t, 'value': t} for t in stocks['ticker'].unique()],
                    value=stocks['ticker'].unique().tolist(),
                    inline=True,
                    style={'color': MUTED, 'fontSize': '12px', 'marginTop': '8px'},
                    inputStyle={'marginRight': '4px', 'marginLeft': '12px'},
                ),
            ], style={'marginBottom': '12px'}),
            dcc.Graph(id='stock-chart', style={'height': '320px'}),
        ], style={'backgroundColor': CARD_BG, 'border': f'1px solid {BORDER}',
                  'borderRadius': '10px', 'padding': '20px', 'marginBottom': '20px'}),
    ]),

    # ── Bottom Row ─────────────────────────────────────────────────────────────
    html.Div([
        # Revenue by Category
        html.Div([
            html.H3('Revenue by Category', style={'color': TEXT, 'margin': '0 0 12px 0',
                                                   'fontSize': '15px', 'fontWeight': 600}),
            dcc.Dropdown(
                id='region-filter',
                options=[{'label': 'All Regions', 'value': 'All'}] +
                        [{'label': r, 'value': r} for r in sorted(sales['region'].unique())],
                value='All',
                style={'backgroundColor': '#334155', 'color': BG,
                       'border': 'none', 'marginBottom': '12px'},
            ),
            dcc.Graph(id='category-bar', style={'height': '280px'}),
        ], style={'backgroundColor': CARD_BG, 'border': f'1px solid {BORDER}',
                  'borderRadius': '10px', 'padding': '20px', 'flex': '1'}),

        # World Population Bubble
        html.Div([
            html.H3('GDP vs Life Expectancy', style={'color': TEXT, 'margin': '0 0 12px 0',
                                                       'fontSize': '15px', 'fontWeight': 600}),
            dcc.Graph(id='world-bubble', style={'height': '310px'}),
        ], style={'backgroundColor': CARD_BG, 'border': f'1px solid {BORDER}',
                  'borderRadius': '10px', 'padding': '20px', 'flex': '1'}),
    ], style={'display': 'flex', 'gap': '20px', 'flexWrap': 'wrap'}),

])


# ─── Callbacks ────────────────────────────────────────────────────────────────
@callback(Output('stock-chart', 'figure'), Input('stock-ticker-filter', 'value'))
def update_stock(selected_tickers):
    fig = go.Figure()
    for i, ticker in enumerate(selected_tickers or []):
        sub = stocks[stocks['ticker'] == ticker].sort_values('date')
        fig.add_trace(go.Scatter(
            x=sub['date'], y=sub['close'], mode='lines',
            name=ticker, line=dict(width=2, color=COLORS[i % len(COLORS)]),
            hovertemplate=f'<b>{ticker}</b><br>%{{x|%b %d}}<br>$%{{y:.2f}}<extra></extra>',
        ))
    fig.update_layout(
        paper_bgcolor='transparent', plot_bgcolor=CARD_BG,
        font_color=TEXT, margin=dict(l=40, r=20, t=10, b=40),
        legend=dict(bgcolor='transparent', bordercolor=BORDER, borderwidth=1),
        xaxis=dict(gridcolor=BORDER, showgrid=True),
        yaxis=dict(gridcolor=BORDER, showgrid=True, tickprefix='$'),
        hovermode='x unified',
    )
    return fig


@callback(Output('category-bar', 'figure'), Input('region-filter', 'value'))
def update_category(region):
    filtered = sales if region == 'All' else sales[sales['region'] == region]
    cat_rev  = (filtered.groupby('category')[['revenue', 'profit']]
                         .sum().sort_values('revenue', ascending=True))

    fig = go.Figure()
    fig.add_trace(go.Bar(y=cat_rev.index, x=cat_rev['revenue'], name='Revenue',
                         orientation='h', marker_color=ACCENT, opacity=0.85))
    fig.add_trace(go.Bar(y=cat_rev.index, x=cat_rev['profit'],  name='Profit',
                         orientation='h', marker_color=GREEN,  opacity=0.85))
    fig.update_layout(
        barmode='overlay',
        paper_bgcolor='transparent', plot_bgcolor=CARD_BG,
        font_color=TEXT, margin=dict(l=10, r=20, t=10, b=40),
        xaxis=dict(gridcolor=BORDER, tickprefix='$',
                   tickformat=',.0f'),
        yaxis=dict(gridcolor=BORDER),
        legend=dict(bgcolor='transparent'),
    )
    return fig


@callback(Output('world-bubble', 'figure'), Input('region-filter', 'value'))
def update_bubble(_):
    fig = px.scatter(
        pop, x='gdp_per_capita_usd', y='life_expectancy',
        size='population_millions', color='continent',
        hover_name='country', log_x=True,
        size_max=55,
        color_discrete_sequence=COLORS,
        labels={'gdp_per_capita_usd': 'GDP per Capita (USD)', 'life_expectancy': 'Life Expectancy'},
    )
    fig.update_layout(
        paper_bgcolor='transparent', plot_bgcolor=CARD_BG,
        font_color=TEXT, margin=dict(l=40, r=20, t=10, b=40),
        xaxis=dict(gridcolor=BORDER, tickprefix='$'),
        yaxis=dict(gridcolor=BORDER),
        legend=dict(bgcolor='transparent', bordercolor=BORDER, borderwidth=1,
                    title_text='Continent'),
    )
    return fig


if __name__ == '__main__':
    print("🚀 Starting Dash server at http://127.0.0.1:8050")
    app.run(debug=True)
