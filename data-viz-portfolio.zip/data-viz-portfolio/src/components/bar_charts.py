"""
bar_charts.py
=============
Bar chart visualizations: grouped, stacked, horizontal, and animated.
Demonstrates sales comparisons, rankings, and categorical data.
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
import pandas as pd

from src.utils.theme import apply_dark_theme, PALETTE_PRIMARY, BG_DARK, BG_CARD, TEXT_PRIMARY, TEXT_SECONDARY
from src.utils.helpers import annotate_bars, add_source_note, save_figure, fmt_currency


# ─────────────────────────────────────────────
# 1. Grouped Bar Chart — Regional Sales by Product
# ─────────────────────────────────────────────

def plot_grouped_bar(df: pd.DataFrame) -> plt.Figure:
    """
    Grouped bar chart comparing product sales across regions.
    """
    apply_dark_theme()

    # Aggregate: mean sales per region × product
    pivot = (
        df.groupby(["region", "product"])["sales"]
        .sum()
        .unstack("product")
        .div(1_000_000)  # millions
    )

    fig, ax = plt.subplots(figsize=(13, 6))
    fig.patch.set_facecolor(BG_DARK)
    ax.set_facecolor(BG_CARD)

    x = np.arange(len(pivot.index))
    n_products = len(pivot.columns)
    width = 0.18
    offsets = np.linspace(-(n_products - 1) / 2, (n_products - 1) / 2, n_products) * width

    for i, (product, offset) in enumerate(zip(pivot.columns, offsets)):
        bars = ax.bar(
            x + offset, pivot[product], width,
            label=product,
            color=PALETTE_PRIMARY[i],
            alpha=0.88,
            edgecolor=BG_DARK,
            linewidth=0.5,
        )

    ax.set_title("Total Sales by Region & Product", color=TEXT_PRIMARY, fontsize=15, pad=14)
    ax.set_xlabel("Region", color=TEXT_SECONDARY)
    ax.set_ylabel("Sales ($ Millions)", color=TEXT_SECONDARY)
    ax.set_xticks(x)
    ax.set_xticklabels(pivot.index, color=TEXT_PRIMARY)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"${v:.0f}M"))
    ax.legend(loc="upper right", framealpha=0.2)

    # Highlight best region
    best_idx = pivot.sum(axis=1).idxmax()
    best_x = list(pivot.index).index(best_idx)
    ax.axvspan(best_x - 0.4, best_x + 0.4, color="#2563EB", alpha=0.07, zorder=0)
    ax.text(best_x, ax.get_ylim()[1] * 0.95, "★ Best Region",
            ha="center", color="#60A5FA", fontsize=8, fontweight="bold")

    add_source_note(fig)
    fig.tight_layout()
    return fig


# ─────────────────────────────────────────────
# 2. Stacked Bar Chart — Channel Revenue Mix
# ─────────────────────────────────────────────

def plot_stacked_bar(df: pd.DataFrame) -> plt.Figure:
    """
    Stacked bar chart showing channel revenue contribution per region.
    """
    apply_dark_theme()

    pivot = (
        df.groupby(["region", "channel"])["sales"]
        .sum()
        .unstack("channel")
        .div(1_000_000)
        .fillna(0)
    )

    fig, ax = plt.subplots(figsize=(12, 6))
    fig.patch.set_facecolor(BG_DARK)
    ax.set_facecolor(BG_CARD)

    bottom = np.zeros(len(pivot))
    x = np.arange(len(pivot.index))

    for i, channel in enumerate(pivot.columns):
        ax.bar(
            x, pivot[channel], bottom=bottom,
            label=channel,
            color=PALETTE_PRIMARY[i],
            alpha=0.9,
            edgecolor=BG_DARK,
            linewidth=0.6,
        )
        # Label segments if large enough
        for j, (val, bot) in enumerate(zip(pivot[channel], bottom)):
            if val > 5:
                ax.text(j, bot + val / 2, f"${val:.0f}M",
                        ha="center", va="center", fontsize=7,
                        color="white", fontweight="bold")
        bottom += pivot[channel].values

    ax.set_title("Revenue Mix by Channel Across Regions", color=TEXT_PRIMARY, fontsize=15, pad=14)
    ax.set_xlabel("Region", color=TEXT_SECONDARY)
    ax.set_ylabel("Sales ($ Millions)", color=TEXT_SECONDARY)
    ax.set_xticks(x)
    ax.set_xticklabels(pivot.index, color=TEXT_PRIMARY)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"${v:.0f}M"))
    ax.legend(loc="upper right", framealpha=0.2)

    add_source_note(fig)
    fig.tight_layout()
    return fig


# ─────────────────────────────────────────────
# 3. Horizontal Bar Chart — Product Rankings
# ─────────────────────────────────────────────

def plot_horizontal_bar(df: pd.DataFrame) -> plt.Figure:
    """
    Horizontal bar chart ranking products by total revenue.
    Includes delta annotations showing YoY change.
    """
    apply_dark_theme()

    product_sales = (
        df.groupby("product")["sales"]
        .sum()
        .sort_values(ascending=True)
        .div(1_000_000)
    )

    # Compute YoY growth (2022 vs 2021)
    yoy = df[df["year"].isin([2021, 2022])].groupby(["year", "product"])["sales"].sum().unstack("year")
    yoy["growth"] = ((yoy[2022] - yoy[2021]) / yoy[2021] * 100).round(1)

    fig, ax = plt.subplots(figsize=(10, 5))
    fig.patch.set_facecolor(BG_DARK)
    ax.set_facecolor(BG_CARD)

    colors = [PALETTE_PRIMARY[i % len(PALETTE_PRIMARY)] for i in range(len(product_sales))]
    bars = ax.barh(product_sales.index, product_sales.values, color=colors, alpha=0.88,
                   edgecolor=BG_DARK, height=0.55)

    # Value labels
    for bar, (prod, val) in zip(bars, product_sales.items()):
        growth = yoy.loc[prod, "growth"] if prod in yoy.index else 0
        sign = "+" if growth >= 0 else ""
        color_g = "#4ADE80" if growth >= 0 else "#F87171"
        ax.text(val + 1, bar.get_y() + bar.get_height() / 2,
                f"  ${val:.0f}M  ({sign}{growth:.1f}% YoY)",
                va="center", fontsize=9, color=color_g, fontweight="bold")

    ax.set_title("Product Revenue Ranking with YoY Growth", color=TEXT_PRIMARY, fontsize=15, pad=14)
    ax.set_xlabel("Total Sales ($ Millions)", color=TEXT_SECONDARY)
    ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"${v:.0f}M"))
    ax.spines["left"].set_visible(False)
    ax.tick_params(axis="y", colors=TEXT_PRIMARY)
    ax.set_xlim(0, product_sales.max() * 1.3)

    add_source_note(fig)
    fig.tight_layout()
    return fig


# ─────────────────────────────────────────────
# 4. Diverging Bar Chart — Growth vs Decline
# ─────────────────────────────────────────────

def plot_diverging_bar(df: pd.DataFrame) -> plt.Figure:
    """
    Diverging bar chart showing monthly profit variance vs. average.
    Positive = green, negative = red.
    """
    apply_dark_theme()

    monthly = (
        df.groupby(["year", "month"])["profit"]
        .sum()
        .reset_index()
    )
    monthly["label"] = monthly.apply(
        lambda r: f"{['', 'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][int(r['month'])]} {int(r['year'])}", axis=1
    )
    monthly = monthly.sort_values(["year", "month"]).tail(24)
    mean_profit = monthly["profit"].mean()
    monthly["variance"] = (monthly["profit"] - mean_profit) / 1_000_000

    fig, ax = plt.subplots(figsize=(14, 6))
    fig.patch.set_facecolor(BG_DARK)
    ax.set_facecolor(BG_CARD)

    colors = ["#4ADE80" if v >= 0 else "#F87171" for v in monthly["variance"]]
    x = np.arange(len(monthly))
    ax.bar(x, monthly["variance"], color=colors, alpha=0.85, edgecolor=BG_DARK)
    ax.axhline(0, color=TEXT_SECONDARY, linewidth=1, linestyle="--", alpha=0.5)

    ax.set_title("Monthly Profit Variance vs. 2-Year Average",
                 color=TEXT_PRIMARY, fontsize=15, pad=14)
    ax.set_xlabel("Month", color=TEXT_SECONDARY)
    ax.set_ylabel("Variance from Average ($ Millions)", color=TEXT_SECONDARY)
    ax.set_xticks(x[::3])
    ax.set_xticklabels(monthly["label"].values[::3], rotation=30, ha="right", color=TEXT_PRIMARY, fontsize=8)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"${v:+.1f}M"))

    # Legend
    pos_patch = mpatches.Patch(color="#4ADE80", label="Above Average")
    neg_patch = mpatches.Patch(color="#F87171", label="Below Average")
    ax.legend(handles=[pos_patch, neg_patch], loc="upper left", framealpha=0.2)

    add_source_note(fig)
    fig.tight_layout()
    return fig
