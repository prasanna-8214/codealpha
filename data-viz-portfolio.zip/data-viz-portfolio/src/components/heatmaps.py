"""
heatmaps.py
===========
Heatmap visualizations: correlation matrices, calendar heatmaps,
and categorical pivot heatmaps using Seaborn and Matplotlib.
"""

import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import seaborn as sns
import numpy as np
import pandas as pd
import calendar

from src.utils.theme import (
    apply_dark_theme, apply_seaborn_theme,
    PALETTE_PRIMARY, BG_DARK, BG_CARD, TEXT_PRIMARY, TEXT_SECONDARY,
    PALETTE_SEQUENTIAL_BLUE, PALETTE_DIVERGING
)
from src.utils.helpers import add_source_note, make_colormap


# ─────────────────────────────────────────────
# 1. Correlation Heatmap
# ─────────────────────────────────────────────

def plot_correlation_heatmap(df_features: pd.DataFrame) -> plt.Figure:
    """
    Full correlation matrix with masked upper triangle.
    Annotated with correlation coefficients.
    """
    apply_seaborn_theme(style="dark", palette="diverging")

    corr = df_features.corr()
    mask = np.triu(np.ones_like(corr, dtype=bool))

    custom_cmap = make_colormap(
        ["#DC2626", "#F87171", "#FCA5A5", "#F3F4F6", "#93C5FD", "#3B82F6", "#1D4ED8"],
        name="div_cmap"
    )

    fig, ax = plt.subplots(figsize=(10, 8))
    fig.patch.set_facecolor(BG_DARK)
    ax.set_facecolor(BG_CARD)

    sns.heatmap(
        corr, mask=mask, cmap=custom_cmap,
        vmin=-1, vmax=1, center=0,
        annot=True, fmt=".2f", annot_kws={"size": 10, "weight": "bold"},
        square=True, linewidths=0.5, linecolor=BG_DARK,
        cbar_kws={"shrink": 0.8, "label": "Pearson Correlation"},
        ax=ax
    )

    ax.set_title("Feature Correlation Matrix", color=TEXT_PRIMARY, fontsize=15, pad=14)
    ax.tick_params(colors=TEXT_PRIMARY, labelsize=10)

    # Style colorbar
    cbar = ax.collections[0].colorbar
    cbar.ax.yaxis.set_tick_params(color=TEXT_SECONDARY)
    cbar.ax.tick_params(labelcolor=TEXT_SECONDARY)
    cbar.set_label("Pearson Correlation", color=TEXT_SECONDARY)

    add_source_note(fig)
    fig.tight_layout()
    return fig


# ─────────────────────────────────────────────
# 2. Pivot Heatmap — Sales by Month × Region
# ─────────────────────────────────────────────

def plot_pivot_heatmap(df_sales: pd.DataFrame) -> plt.Figure:
    """
    Heatmap of monthly sales per region, showing seasonal patterns.
    """
    apply_seaborn_theme(style="dark")

    pivot = (
        df_sales[df_sales["year"] == 2023]
        .groupby(["month_name", "region"])["sales"]
        .sum()
        .unstack("region")
        .div(1_000_000)
    )

    month_order = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                   "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    pivot = pivot.reindex([m for m in month_order if m in pivot.index])

    custom_cmap = make_colormap(PALETTE_SEQUENTIAL_BLUE, "seq_blue")

    fig, ax = plt.subplots(figsize=(11, 7))
    fig.patch.set_facecolor(BG_DARK)
    ax.set_facecolor(BG_CARD)

    sns.heatmap(
        pivot, cmap=custom_cmap,
        annot=True, fmt=".1f",
        annot_kws={"size": 9, "weight": "bold", "color": "white"},
        linewidths=0.5, linecolor=BG_DARK,
        cbar_kws={"shrink": 0.8, "label": "Revenue ($M)"},
        ax=ax
    )

    ax.set_title("Monthly Sales by Region — 2023 Heatmap",
                 color=TEXT_PRIMARY, fontsize=15, pad=14)
    ax.set_xlabel("Region", color=TEXT_SECONDARY)
    ax.set_ylabel("Month", color=TEXT_SECONDARY)
    ax.tick_params(colors=TEXT_PRIMARY, labelsize=9)

    cbar = ax.collections[0].colorbar
    cbar.ax.tick_params(labelcolor=TEXT_SECONDARY)
    cbar.set_label("Revenue ($M)", color=TEXT_SECONDARY)

    add_source_note(fig)
    fig.tight_layout()
    return fig


# ─────────────────────────────────────────────
# 3. Calendar Heatmap — Daily Sales Intensity
# ─────────────────────────────────────────────

def plot_calendar_heatmap(df_sales: pd.DataFrame) -> plt.Figure:
    """
    GitHub-style calendar heatmap showing daily sales intensity for one year.
    """
    apply_dark_theme()

    # Resample to daily using the first region's data
    daily = (
        df_sales[df_sales["year"] == 2022]
        .groupby("date")["sales"]
        .sum()
        .div(1_000_000)
        .reindex(pd.date_range("2022-01-01", "2022-12-31", freq="D"), fill_value=0)
    )

    # Build 7-row (weekday) × 53-col (week) grid
    n_weeks = 53
    grid = np.zeros((7, n_weeks))
    for i, (date, val) in enumerate(daily.items()):
        week = i // 7
        day = date.weekday()
        if week < n_weeks:
            grid[day, week] = val

    custom_cmap = make_colormap(
        ["#1E293B", "#1E3A8A", "#1D4ED8", "#3B82F6", "#93C5FD", "#DBEAFE"],
        "cal_cmap"
    )

    fig, ax = plt.subplots(figsize=(16, 4))
    fig.patch.set_facecolor(BG_DARK)
    ax.set_facecolor(BG_DARK)

    im = ax.imshow(grid, cmap=custom_cmap, aspect="auto",
                   vmin=0, vmax=daily.max(), interpolation="nearest")

    # Month labels
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
              "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    month_starts = [pd.Timestamp(f"2022-{m:02d}-01") for m in range(1, 13)]
    month_weeks = [(d - pd.Timestamp("2022-01-01")).days // 7 for d in month_starts]
    ax.set_xticks(month_weeks)
    ax.set_xticklabels(months, color=TEXT_SECONDARY, fontsize=9)

    # Day labels
    day_labels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    ax.set_yticks(range(7))
    ax.set_yticklabels(day_labels, color=TEXT_SECONDARY, fontsize=8)

    plt.colorbar(im, ax=ax, label="Daily Revenue ($M)", shrink=0.6, pad=0.01,
                 orientation="vertical")

    ax.set_title("Daily Revenue Intensity — 2022 Calendar Heatmap",
                 color=TEXT_PRIMARY, fontsize=14, pad=12)
    ax.set_frame_on(False)
    ax.tick_params(length=0)

    add_source_note(fig)
    fig.tight_layout()
    return fig


# ─────────────────────────────────────────────
# 4. Clustermap — Customer Segment Profiles
# ─────────────────────────────────────────────

def plot_clustermap(df_customers: pd.DataFrame) -> plt.Figure:
    """
    Clustered heatmap grouping customer segments by behavioral metrics.
    """
    apply_seaborn_theme(style="dark")

    segment_profile = (
        df_customers.groupby("segment")
        .agg(
            avg_age=("age", "mean"),
            avg_income=("income", "mean"),
            avg_spend=("annual_spend", "mean"),
            avg_tenure=("tenure_months", "mean"),
            avg_satisfaction=("satisfaction_score", "mean"),
            churn_rate=("churned", "mean"),
        )
        .round(2)
    )

    # Normalize
    normalized = (segment_profile - segment_profile.min()) / \
                 (segment_profile.max() - segment_profile.min())

    custom_cmap = make_colormap(PALETTE_SEQUENTIAL_BLUE, "seg_cmap")

    g = sns.clustermap(
        normalized,
        cmap=custom_cmap,
        figsize=(10, 5),
        annot=segment_profile.values,
        fmt=".1f",
        annot_kws={"size": 9, "color": "white"},
        linewidths=0.5,
        linecolor=BG_DARK,
        cbar_pos=(0.02, 0.8, 0.02, 0.18),
        dendrogram_ratio=0.15,
        col_cluster=True,
        row_cluster=True,
    )

    g.fig.patch.set_facecolor(BG_DARK)
    g.ax_heatmap.set_title("Customer Segment Profiles (Normalized)",
                            color=TEXT_PRIMARY, fontsize=13, pad=10)
    g.ax_heatmap.tick_params(colors=TEXT_PRIMARY)
    g.ax_heatmap.set_xlabel("Metric", color=TEXT_SECONDARY)
    g.ax_heatmap.set_ylabel("Segment", color=TEXT_SECONDARY)

    add_source_note(g.fig)
    return g.fig
