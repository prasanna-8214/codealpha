"""
scatter_plots.py
================
Scatter plot visualizations: bubble charts, pair plots, 
regression overlays, and distribution plots.
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
import numpy as np
import pandas as pd
from scipy import stats

from src.utils.theme import (
    apply_dark_theme, apply_seaborn_theme,
    PALETTE_PRIMARY, BG_DARK, BG_CARD, TEXT_PRIMARY, TEXT_SECONDARY
)
from src.utils.helpers import add_source_note


# ─────────────────────────────────────────────
# 1. Bubble Chart — Income vs Spend vs Segment
# ─────────────────────────────────────────────

def plot_bubble_chart(df: pd.DataFrame) -> plt.Figure:
    """
    Bubble chart: x=income, y=annual_spend, size=tenure, color=segment.
    Reveals the relationship between wealth, spending, and loyalty.
    """
    apply_dark_theme()

    segments = df["segment"].unique()
    seg_colors = {seg: PALETTE_PRIMARY[i] for i, seg in enumerate(segments)}

    fig, ax = plt.subplots(figsize=(12, 7))
    fig.patch.set_facecolor(BG_DARK)
    ax.set_facecolor(BG_CARD)

    sample = df.sample(400, random_state=42)

    for seg in segments:
        sub = sample[sample["segment"] == seg]
        scatter = ax.scatter(
            sub["income"] / 1_000,
            sub["annual_spend"] / 1_000,
            s=sub["tenure_months"] * 1.5,
            c=seg_colors[seg],
            alpha=0.55,
            label=seg,
            edgecolors=BG_DARK,
            linewidth=0.4,
        )

    # Regression line
    x_vals = sample["income"] / 1_000
    y_vals = sample["annual_spend"] / 1_000
    slope, intercept, r, p, _ = stats.linregress(x_vals, y_vals)
    x_line = np.linspace(x_vals.min(), x_vals.max(), 100)
    ax.plot(x_line, slope * x_line + intercept,
            color="#FBBF24", linewidth=1.8, linestyle="--",
            label=f"Regression (r={r:.2f})", zorder=5)

    ax.set_title("Customer Income vs. Annual Spend by Segment",
                 color=TEXT_PRIMARY, fontsize=15, pad=14)
    ax.set_xlabel("Annual Income ($K)", color=TEXT_SECONDARY)
    ax.set_ylabel("Annual Spend ($K)", color=TEXT_SECONDARY)
    ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"${v:.0f}K"))
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"${v:.0f}K"))

    # Size legend
    sizes = [6, 24, 48]
    labels = ["< 6 mo", "~24 mo", "~48 mo"]
    legend_handles = [
        plt.scatter([], [], s=s * 1.5, c="#64748B", alpha=0.6, label=l)
        for s, l in zip(sizes, labels)
    ]
    seg_handles = [mpatches.Patch(color=seg_colors[s], label=s) for s in segments]
    first_legend = ax.legend(handles=seg_handles, title="Segment",
                              loc="upper left", framealpha=0.2, title_fontsize=8)
    ax.add_artist(first_legend)
    ax.legend(handles=legend_handles, title="Tenure",
              loc="lower right", framealpha=0.2, title_fontsize=8)

    add_source_note(fig)
    fig.tight_layout()
    return fig


# ─────────────────────────────────────────────
# 2. Violin + Box Plot — Spend by Segment
# ─────────────────────────────────────────────

def plot_violin_box(df: pd.DataFrame) -> plt.Figure:
    """
    Violin plot with embedded box plot showing spend distribution per segment.
    """
    apply_seaborn_theme(style="darkgrid")

    fig, ax = plt.subplots(figsize=(11, 6))
    fig.patch.set_facecolor(BG_DARK)
    ax.set_facecolor(BG_CARD)

    order = df.groupby("segment")["annual_spend"].median().sort_values(ascending=False).index

    sns.violinplot(
        data=df, x="segment", y="annual_spend",
        order=order, palette=PALETTE_PRIMARY[:len(order)],
        inner=None, alpha=0.35, ax=ax, cut=2, width=0.8
    )
    sns.boxplot(
        data=df, x="segment", y="annual_spend",
        order=order, palette=PALETTE_PRIMARY[:len(order)],
        width=0.18, linewidth=1.2, fliersize=2,
        flierprops=dict(marker="o", alpha=0.3, markersize=3),
        ax=ax
    )

    # Median annotations
    for i, seg in enumerate(order):
        med = df[df["segment"] == seg]["annual_spend"].median()
        ax.text(i, med + 200, f"Median\n${med:,.0f}",
                ha="center", va="bottom", fontsize=7,
                color=TEXT_PRIMARY, fontweight="bold")

    ax.set_title("Annual Spend Distribution by Customer Segment",
                 color=TEXT_PRIMARY, fontsize=15, pad=14)
    ax.set_xlabel("Segment", color=TEXT_SECONDARY)
    ax.set_ylabel("Annual Spend ($)", color=TEXT_SECONDARY)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"${v:,.0f}"))
    ax.tick_params(colors=TEXT_PRIMARY)

    add_source_note(fig)
    fig.tight_layout()
    return fig


# ─────────────────────────────────────────────
# 3. Pair Plot / Scatter Matrix
# ─────────────────────────────────────────────

def plot_pairplot(df: pd.DataFrame) -> plt.Figure:
    """
    Seaborn pair plot for multi-variable feature relationships.
    """
    apply_seaborn_theme(style="darkgrid")

    sample = df.sample(300, random_state=42)
    cols = ["age", "income", "annual_spend", "tenure_months", "satisfaction_score"]
    sub = sample[cols + ["segment"]].copy()

    g = sns.pairplot(
        sub, hue="segment", vars=cols,
        palette=PALETTE_PRIMARY[:sub["segment"].nunique()],
        plot_kws={"alpha": 0.45, "s": 20, "edgecolor": "none"},
        diag_kind="kde",
        diag_kws={"alpha": 0.5},
        corner=True
    )

    g.figure.suptitle("Pair Plot — Customer Feature Relationships",
                       color=TEXT_PRIMARY, fontsize=14, y=1.01)
    g.figure.patch.set_facecolor(BG_DARK)

    for ax in g.axes.flatten():
        if ax is not None:
            ax.set_facecolor(BG_CARD)
            ax.tick_params(colors=TEXT_SECONDARY, labelsize=7)
            ax.xaxis.label.set_color(TEXT_SECONDARY)
            ax.yaxis.label.set_color(TEXT_SECONDARY)

    add_source_note(g.figure)
    return g.figure


# ─────────────────────────────────────────────
# 4. Hexbin Density Plot
# ─────────────────────────────────────────────

def plot_hexbin(df: pd.DataFrame) -> plt.Figure:
    """
    Hexbin chart showing the density of income vs spend data points.
    Better than scatter for large datasets with overplotting.
    """
    apply_dark_theme()

    from src.utils.helpers import make_colormap
    custom_cmap = make_colormap(
        ["#1E293B", "#1E3A8A", "#2563EB", "#60A5FA", "#BFDBFE", "#DBEAFE"],
        "hexbin_cmap"
    )

    fig, ax = plt.subplots(figsize=(11, 7))
    fig.patch.set_facecolor(BG_DARK)
    ax.set_facecolor(BG_DARK)

    hb = ax.hexbin(
        df["income"] / 1_000,
        df["annual_spend"] / 1_000,
        gridsize=35,
        cmap=custom_cmap,
        mincnt=1,
        edgecolors=BG_DARK,
        linewidths=0.2,
    )

    cb = plt.colorbar(hb, ax=ax)
    cb.set_label("Number of Customers", color=TEXT_SECONDARY)
    cb.ax.tick_params(labelcolor=TEXT_SECONDARY)

    ax.set_title("Income vs. Annual Spend — Density Hexbin",
                 color=TEXT_PRIMARY, fontsize=15, pad=14)
    ax.set_xlabel("Annual Income ($K)", color=TEXT_SECONDARY)
    ax.set_ylabel("Annual Spend ($K)", color=TEXT_SECONDARY)
    ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"${v:.0f}K"))
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"${v:.0f}K"))
    ax.tick_params(colors=TEXT_PRIMARY)

    add_source_note(fig)
    fig.tight_layout()
    return fig
