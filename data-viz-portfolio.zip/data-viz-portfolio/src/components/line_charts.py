"""
line_charts.py
==============
Line chart visualizations: time series, multi-line, area, and candlestick.
Demonstrates trends, seasonality, and financial data.
"""

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.patches as mpatches
import numpy as np
import pandas as pd
from matplotlib.collections import LineCollection

from src.utils.theme import (
    apply_dark_theme, PALETTE_PRIMARY, PALETTE_MUTED,
    BG_DARK, BG_CARD, TEXT_PRIMARY, TEXT_SECONDARY
)
from src.utils.helpers import add_trend_line, add_source_note, save_figure


# ─────────────────────────────────────────────
# 1. Multi-Line Time Series — Revenue by Region
# ─────────────────────────────────────────────

def plot_multi_line(df: pd.DataFrame) -> plt.Figure:
    """
    Multi-line time series showing monthly revenue trends per region.
    Includes shaded confidence band and event annotations.
    """
    apply_dark_theme()

    monthly_region = (
        df.groupby(["date", "region"])["sales"]
        .sum()
        .reset_index()
    )
    monthly_region["sales_M"] = monthly_region["sales"] / 1_000_000
    regions = monthly_region["region"].unique()

    fig, ax = plt.subplots(figsize=(14, 6))
    fig.patch.set_facecolor(BG_DARK)
    ax.set_facecolor(BG_CARD)

    for i, region in enumerate(regions):
        subset = monthly_region[monthly_region["region"] == region]
        color = PALETTE_PRIMARY[i % len(PALETTE_PRIMARY)]
        ax.plot(subset["date"], subset["sales_M"],
                color=color, linewidth=2.0, label=region, marker="o",
                markersize=3, markerfacecolor=BG_DARK)

        # Shaded area below line
        ax.fill_between(subset["date"], 0, subset["sales_M"],
                        color=color, alpha=0.04)

    # Annotate peak event
    peak_row = monthly_region.loc[monthly_region["sales_M"].idxmax()]
    ax.annotate(
        f"Peak: ${peak_row['sales_M']:.1f}M\n({peak_row['region']})",
        xy=(peak_row["date"], peak_row["sales_M"]),
        xytext=(20, -25), textcoords="offset points",
        arrowprops=dict(arrowstyle="->", color="#FBBF24", lw=1.2),
        fontsize=8, color="#FBBF24", fontweight="bold"
    )

    # Vertical marker for new year
    for year in [2022, 2023]:
        ax.axvline(pd.Timestamp(f"{year}-01-01"), color="#475569",
                   linewidth=0.8, linestyle=":", alpha=0.8)
        ax.text(pd.Timestamp(f"{year}-01-15"), ax.get_ylim()[1] * 0.95,
                str(year), color=TEXT_SECONDARY, fontsize=8, va="top")

    ax.set_title("Monthly Revenue Trend by Region (3-Year Overview)",
                 color=TEXT_PRIMARY, fontsize=15, pad=14)
    ax.set_xlabel("Date", color=TEXT_SECONDARY)
    ax.set_ylabel("Revenue ($ Millions)", color=TEXT_SECONDARY)
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%b '%y"))
    ax.xaxis.set_major_locator(mdates.MonthLocator(interval=3))
    plt.setp(ax.get_xticklabels(), rotation=30, ha="right", color=TEXT_PRIMARY)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"${v:.0f}M"))
    ax.legend(loc="upper left", framealpha=0.2)

    add_source_note(fig)
    fig.tight_layout()
    return fig


# ─────────────────────────────────────────────
# 2. Area Chart — Cumulative Revenue
# ─────────────────────────────────────────────

def plot_area_chart(df: pd.DataFrame) -> plt.Figure:
    """
    Stacked area chart showing cumulative revenue contribution by product.
    """
    apply_dark_theme()

    pivot = (
        df.groupby(["date", "product"])["sales"]
        .sum()
        .unstack("product")
        .div(1_000_000)
        .fillna(0)
        .sort_index()
    )

    fig, ax = plt.subplots(figsize=(14, 6))
    fig.patch.set_facecolor(BG_DARK)
    ax.set_facecolor(BG_CARD)

    colors = PALETTE_PRIMARY[:len(pivot.columns)]
    ax.stackplot(
        pivot.index, pivot.T.values,
        labels=pivot.columns,
        colors=colors,
        alpha=0.75
    )

    ax.set_title("Cumulative Revenue Contribution by Product",
                 color=TEXT_PRIMARY, fontsize=15, pad=14)
    ax.set_xlabel("Date", color=TEXT_SECONDARY)
    ax.set_ylabel("Revenue ($ Millions)", color=TEXT_SECONDARY)
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%b '%y"))
    ax.xaxis.set_major_locator(mdates.MonthLocator(interval=3))
    plt.setp(ax.get_xticklabels(), rotation=30, ha="right", color=TEXT_PRIMARY)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"${v:.0f}M"))
    ax.legend(loc="upper left", framealpha=0.2, reverse=True)

    add_source_note(fig)
    fig.tight_layout()
    return fig


# ─────────────────────────────────────────────
# 3. Stock Candlestick Chart
# ─────────────────────────────────────────────

def plot_candlestick(df: pd.DataFrame, ticker: str = "ALPHA") -> plt.Figure:
    """
    Financial candlestick chart with volume bars.
    Shows OHLCV data for a selected ticker.
    """
    apply_dark_theme()

    data = df[df["ticker"] == ticker].tail(60).copy()
    data = data.reset_index(drop=True)

    fig, (ax1, ax2) = plt.subplots(
        2, 1, figsize=(14, 8),
        gridspec_kw={"height_ratios": [3, 1]},
        sharex=True
    )
    fig.patch.set_facecolor(BG_DARK)
    for ax in [ax1, ax2]:
        ax.set_facecolor(BG_CARD)

    x = np.arange(len(data))
    up = data["close"] >= data["open"]

    # Candle bodies
    for i, row in data.iterrows():
        color = "#4ADE80" if row["close"] >= row["open"] else "#F87171"
        # Body
        ax1.bar(i, abs(row["close"] - row["open"]),
                bottom=min(row["open"], row["close"]),
                color=color, width=0.7, alpha=0.85)
        # Wicks
        ax1.plot([i, i], [row["low"], row["high"]],
                 color=color, linewidth=0.8)

    # Moving averages
    data["ma20"] = data["close"].rolling(20).mean()
    data["ma50"] = data["close"].rolling(50).mean()
    ax1.plot(x, data["ma20"], color="#FBBF24", linewidth=1.2, label="MA20", alpha=0.8)
    ax1.plot(x, data["ma50"], color="#A78BFA", linewidth=1.2, label="MA50", alpha=0.8)

    # Volume bars
    vol_colors = ["#4ADE80" if u else "#F87171" for u in up]
    ax2.bar(x, data["volume"] / 1_000, color=vol_colors, alpha=0.7)
    ax2.set_ylabel("Volume (K)", color=TEXT_SECONDARY, fontsize=8)

    ax1.set_title(f"{ticker} — Price Action & Volume (Last 60 Trading Days)",
                  color=TEXT_PRIMARY, fontsize=15, pad=14)
    ax1.set_ylabel("Price ($)", color=TEXT_SECONDARY)
    ax1.legend(loc="upper left", framealpha=0.2)

    # x-axis labels (every 10 bars)
    tick_positions = x[::10]
    tick_labels = data.iloc[::10]["date"].dt.strftime("%b %d").tolist()
    ax2.set_xticks(tick_positions)
    ax2.set_xticklabels(tick_labels, rotation=30, ha="right", color=TEXT_PRIMARY, fontsize=8)

    # Color ticks
    ax1.tick_params(colors=TEXT_PRIMARY)
    ax2.tick_params(colors=TEXT_PRIMARY)

    fig.tight_layout(h_pad=0.5)
    add_source_note(fig)
    return fig


# ─────────────────────────────────────────────
# 4. Gradient Line Chart — Satisfaction Over Time
# ─────────────────────────────────────────────

def plot_gradient_line(df_customers: pd.DataFrame) -> plt.Figure:
    """
    Gradient-colored line chart where color encodes the rate of change.
    Visualizes customer satisfaction trend over tenure cohorts.
    """
    apply_dark_theme()

    # Bin by tenure and compute mean satisfaction
    bins = list(range(0, 97, 6))
    labels = [f"{b}-{b+6}mo" for b in bins[:-1]]
    df_customers["tenure_bin"] = pd.cut(
        df_customers["tenure_months"], bins=bins, labels=labels
    )
    trend = (
        df_customers.groupby("tenure_bin", observed=True)["satisfaction_score"]
        .mean()
        .reset_index()
    )

    x = np.arange(len(trend))
    y = trend["satisfaction_score"].values

    fig, ax = plt.subplots(figsize=(13, 5))
    fig.patch.set_facecolor(BG_DARK)
    ax.set_facecolor(BG_CARD)

    # Gradient segments
    from matplotlib.colors import Normalize
    from matplotlib.cm import ScalarMappable
    cmap = plt.get_cmap("RdYlGn")
    norm = Normalize(vmin=y.min(), vmax=y.max())

    for i in range(len(x) - 1):
        color = cmap(norm((y[i] + y[i + 1]) / 2))
        ax.plot(x[i:i+2], y[i:i+2], color=color, linewidth=3)

    # Scatter markers
    scatter = ax.scatter(x, y, c=y, cmap="RdYlGn", s=60, zorder=5,
                         edgecolors=BG_DARK, linewidth=1)
    plt.colorbar(scatter, ax=ax, label="Satisfaction Score", pad=0.01)

    # Reference line
    ax.axhline(y.mean(), color="#FBBF24", linewidth=1, linestyle="--",
               alpha=0.7, label=f"Avg: {y.mean():.2f}")

    ax.set_title("Customer Satisfaction by Tenure Cohort",
                 color=TEXT_PRIMARY, fontsize=15, pad=14)
    ax.set_xlabel("Tenure Cohort (Months)", color=TEXT_SECONDARY)
    ax.set_ylabel("Average Satisfaction Score (1–5)", color=TEXT_SECONDARY)
    ax.set_xticks(x)
    ax.set_xticklabels(trend["tenure_bin"], rotation=45, ha="right",
                       color=TEXT_PRIMARY, fontsize=7)
    ax.set_ylim(1, 5)
    ax.legend(framealpha=0.2)

    add_source_note(fig)
    fig.tight_layout()
    return fig
