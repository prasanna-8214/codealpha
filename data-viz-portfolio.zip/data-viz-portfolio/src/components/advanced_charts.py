"""
advanced_charts.py
==================
Advanced and specialized visualizations:
Funnel, Treemap, Radar/Spider, Choropleth (Plotly), 3D Surface.
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyArrowPatch
import matplotlib.patheffects as pe
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from src.utils.theme import (
    apply_dark_theme, PALETTE_PRIMARY, PALETTE_MUTED,
    BG_DARK, BG_CARD, TEXT_PRIMARY, TEXT_SECONDARY,
    PLOTLY_DARK_TEMPLATE
)
from src.utils.helpers import add_source_note, fmt_number


# ─────────────────────────────────────────────
# 1. Funnel Chart (Matplotlib)
# ─────────────────────────────────────────────

def plot_funnel(df: pd.DataFrame) -> plt.Figure:
    """
    Custom funnel chart showing conversion drop-off at each stage.
    Built from scratch using matplotlib trapezoids.
    """
    apply_dark_theme()

    stages = df["stage"].tolist()
    values = df["count"].tolist()
    max_val = values[0]
    widths = [v / max_val for v in values]
    conversion = [1.0] + [values[i] / values[i-1] for i in range(1, len(values))]

    fig, ax = plt.subplots(figsize=(10, 8))
    fig.patch.set_facecolor(BG_DARK)
    ax.set_facecolor(BG_DARK)
    ax.set_xlim(-0.1, 1.1)
    ax.set_ylim(-0.05, 1.05)
    ax.axis("off")

    n = len(stages)
    h = 1.0 / n

    for i, (stage, val, w, conv) in enumerate(zip(stages, values, widths, conversion)):
        y_top = 1.0 - i * h
        y_bot = y_top - h * 0.85

        w_top = widths[i] / 2
        w_bot = widths[i + 1] / 2 if i + 1 < len(widths) else widths[i] / 2 * 0.7

        color = PALETTE_PRIMARY[i % len(PALETTE_PRIMARY)]
        xs = [0.5 - w_top, 0.5 + w_top, 0.5 + w_bot, 0.5 - w_bot]
        ys = [y_top, y_top, y_bot, y_bot]
        ax.fill(xs, ys, color=color, alpha=0.85, zorder=2)
        ax.plot(xs + [xs[0]], ys + [ys[0]], color=BG_DARK, linewidth=1, zorder=3)

        # Labels
        y_mid = (y_top + y_bot) / 2
        ax.text(0.5, y_mid, stage, ha="center", va="center",
                color="white", fontsize=10, fontweight="bold", zorder=4)
        ax.text(0.5 + w_top + 0.03, y_top - 0.01, fmt_number(val),
                ha="left", va="top", color=TEXT_PRIMARY, fontsize=9)
        if i > 0:
            ax.text(0.5 + w_top + 0.03, y_top - 0.04, f"↓ {conv*100:.1f}%",
                    ha="left", va="top", color="#F87171", fontsize=8)

    ax.set_title("Marketing Conversion Funnel", color=TEXT_PRIMARY,
                 fontsize=16, pad=10, y=1.02)

    overall_conv = values[-1] / values[0] * 100
    ax.text(0.5, -0.04, f"Overall Conversion: {overall_conv:.2f}%",
            ha="center", color="#4ADE80", fontsize=10, fontweight="bold")

    add_source_note(fig)
    fig.tight_layout()
    return fig


# ─────────────────────────────────────────────
# 2. Radar / Spider Chart (Matplotlib)
# ─────────────────────────────────────────────

def plot_radar_chart(radar_data: dict) -> plt.Figure:
    """
    Radar / spider chart comparing multiple companies across KPI dimensions.
    """
    apply_dark_theme()

    categories = radar_data["categories"]
    companies = radar_data["companies"]
    N = len(categories)
    angles = [n / N * 2 * np.pi for n in range(N)]
    angles += angles[:1]

    fig, ax = plt.subplots(figsize=(9, 9), subplot_kw={"polar": True})
    fig.patch.set_facecolor(BG_DARK)
    ax.set_facecolor(BG_CARD)

    # Grid styling
    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(categories, color=TEXT_PRIMARY, fontsize=10)
    ax.set_ylim(0, 100)
    ax.set_yticks([20, 40, 60, 80, 100])
    ax.set_yticklabels(["20", "40", "60", "80", "100"], color=TEXT_SECONDARY, fontsize=7)
    ax.grid(color=TEXT_SECONDARY, linewidth=0.4, alpha=0.3)
    ax.spines["polar"].set_color(TEXT_SECONDARY)
    ax.spines["polar"].set_alpha(0.3)

    for i, (company, values) in enumerate(companies.items()):
        color = PALETTE_PRIMARY[i]
        vals = values + values[:1]
        ax.plot(angles, vals, "o-", linewidth=2, color=color, label=company, markersize=5)
        ax.fill(angles, vals, alpha=0.12, color=color)

    ax.set_title("Competitive KPI Radar — Multi-Company Comparison",
                 color=TEXT_PRIMARY, fontsize=14, pad=25)
    ax.legend(loc="upper right", bbox_to_anchor=(1.25, 1.1),
              framealpha=0.2, labelcolor=TEXT_PRIMARY)

    add_source_note(fig)
    return fig


# ─────────────────────────────────────────────
# 3. Treemap (Plotly)
# ─────────────────────────────────────────────

def plot_treemap_plotly(df: pd.DataFrame) -> go.Figure:
    """
    Interactive Plotly treemap showing hierarchical product revenue.
    """
    import plotly.io as pio

    fig = px.treemap(
        df,
        path=["category", "subcategory"],
        values="sales",
        color="sales",
        color_continuous_scale=["#1E3A8A", "#2563EB", "#60A5FA", "#BFDBFE"],
        title="Product Revenue Treemap — Category & Subcategory",
        hover_data={"items": True},
    )

    fig.update_layout(
        **PLOTLY_DARK_TEMPLATE["layout"],
        title_font_size=18,
        margin=dict(t=60, l=10, r=10, b=10),
        coloraxis_colorbar=dict(
            title="Sales ($)",
            tickformat="$,.0f",
            tickfont=dict(color=TEXT_SECONDARY),
            title_font=dict(color=TEXT_SECONDARY),
        )
    )
    fig.update_traces(
        textfont_size=12,
        marker_line_color=BG_DARK,
        marker_line_width=1.5,
    )

    return fig


# ─────────────────────────────────────────────
# 4. Choropleth Map — US State Sales (Plotly)
# ─────────────────────────────────────────────

def plot_choropleth(df_geo: pd.DataFrame) -> go.Figure:
    """
    Interactive US choropleth map showing state-level sales.
    Color encodes revenue, hover shows growth %.
    """
    fig = px.choropleth(
        df_geo,
        locations="state",
        locationmode="USA-states",
        color="sales",
        scope="usa",
        color_continuous_scale=["#1E3A8A", "#2563EB", "#60A5FA", "#BFDBFE"],
        labels={"sales": "Revenue ($)", "growth_pct": "YoY Growth (%)"},
        hover_name="state",
        hover_data={"sales": ":$,.0f", "growth_pct": ":.1f%", "customers": ":,"},
        title="US State Revenue Map",
    )

    fig.update_layout(
        **PLOTLY_DARK_TEMPLATE["layout"],
        geo=dict(
            bgcolor=BG_DARK,
            landcolor="#1E293B",
            showlakes=True,
            lakecolor=BG_DARK,
            showcoastlines=False,
            projection_type="albers usa",
        ),
        margin=dict(t=60, l=0, r=0, b=0),
        coloraxis_colorbar=dict(
            title="Revenue",
            tickformat="$,.0f",
            tickfont=dict(color=TEXT_SECONDARY),
            title_font=dict(color=TEXT_SECONDARY),
        )
    )

    return fig


# ─────────────────────────────────────────────
# 5. 3D Surface Plot (Plotly)
# ─────────────────────────────────────────────

def plot_3d_surface() -> go.Figure:
    """
    3D surface plot: revenue as a function of price and marketing spend.
    Simulates a business optimization landscape.
    """
    price = np.linspace(10, 200, 60)
    marketing = np.linspace(1_000, 100_000, 60)
    P, M = np.meshgrid(price, marketing)

    # Revenue model: peaks at moderate price, high marketing
    demand = 10_000 / (1 + 0.05 * (P - 80) ** 2)
    marketing_effect = 1 + 0.4 * np.log1p(M / 10_000)
    noise = np.random.normal(1, 0.02, P.shape)
    revenue = P * demand * marketing_effect * noise / 1_000_000

    fig = go.Figure(data=[
        go.Surface(
            x=P, y=M / 1000, z=revenue,
            colorscale=[
                [0, "#1E3A8A"], [0.3, "#2563EB"],
                [0.6, "#60A5FA"], [0.85, "#FCD34D"], [1.0, "#F87171"]
            ],
            colorbar=dict(
                title="Revenue ($M)",
                tickfont=dict(color=TEXT_SECONDARY),
                title_font=dict(color=TEXT_SECONDARY),
            ),
            opacity=0.9,
            lighting=dict(ambient=0.6, diffuse=0.8, specular=0.3),
        )
    ])

    fig.update_layout(
        **PLOTLY_DARK_TEMPLATE["layout"],
        title="3D Revenue Landscape — Price × Marketing Optimization",
        scene=dict(
            xaxis_title="Price ($)",
            yaxis_title="Marketing Spend ($K)",
            zaxis_title="Projected Revenue ($M)",
            bgcolor=BG_CARD,
            xaxis=dict(gridcolor=TEXT_SECONDARY, tickfont=dict(color=TEXT_SECONDARY)),
            yaxis=dict(gridcolor=TEXT_SECONDARY, tickfont=dict(color=TEXT_SECONDARY)),
            zaxis=dict(gridcolor=TEXT_SECONDARY, tickfont=dict(color=TEXT_SECONDARY)),
        ),
        margin=dict(t=60, l=0, r=0, b=0),
    )

    return fig


# ─────────────────────────────────────────────
# 6. Animated Bar Race (Plotly)
# ─────────────────────────────────────────────

def plot_animated_bar_race(df_sales: pd.DataFrame) -> go.Figure:
    """
    Animated bar chart race showing quarterly revenue rankings per product.
    """
    quarterly = (
        df_sales.groupby(["year", "quarter", "product"])["sales"]
        .sum()
        .reset_index()
    )
    quarterly["period"] = quarterly["year"].astype(str) + " " + quarterly["quarter"]
    quarterly["sales_M"] = quarterly["sales"] / 1_000_000

    fig = px.bar(
        quarterly,
        x="sales_M", y="product",
        animation_frame="period",
        color="product",
        orientation="h",
        color_discrete_sequence=PALETTE_PRIMARY,
        labels={"sales_M": "Revenue ($M)", "product": ""},
        title="Quarterly Revenue Rankings — Bar Chart Race",
        range_x=[0, quarterly["sales_M"].max() * 1.15],
    )

    fig.update_layout(
        **PLOTLY_DARK_TEMPLATE["layout"],
        showlegend=False,
        margin=dict(t=70, l=20, r=20, b=50),
        yaxis=dict(categoryorder="total ascending"),
    )

    fig.layout.updatemenus[0].buttons[0].args[1]["frame"]["duration"] = 600
    fig.layout.updatemenus[0].buttons[0].args[1]["transition"]["duration"] = 300

    return fig
