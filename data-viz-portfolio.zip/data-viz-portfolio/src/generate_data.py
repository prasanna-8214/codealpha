"""
generate_data.py
----------------
Generates synthetic datasets used across all visualization scripts.
Saves CSV files to the data/ directory.
"""

import os
import numpy as np
import pandas as pd
from faker import Faker
from datetime import datetime, timedelta

fake = Faker()
np.random.seed(42)

DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'data')
os.makedirs(DATA_DIR, exist_ok=True)


# ─── 1. Sales Data ────────────────────────────────────────────────────────────
def generate_sales_data(n=500):
    regions     = ['North', 'South', 'East', 'West']
    categories  = ['Electronics', 'Clothing', 'Food', 'Furniture', 'Sports']
    start_date  = datetime(2022, 1, 1)

    records = []
    for _ in range(n):
        date       = start_date + timedelta(days=np.random.randint(0, 730))
        region     = np.random.choice(regions)
        category   = np.random.choice(categories)
        units_sold = np.random.randint(1, 50)
        unit_price = round(np.random.uniform(10, 500), 2)
        discount   = round(np.random.uniform(0, 0.3), 2)
        revenue    = round(units_sold * unit_price * (1 - discount), 2)
        profit     = round(revenue * np.random.uniform(0.1, 0.4), 2)

        records.append({
            'date': date.strftime('%Y-%m-%d'),
            'region': region,
            'category': category,
            'units_sold': units_sold,
            'unit_price': unit_price,
            'discount': discount,
            'revenue': revenue,
            'profit': profit,
            'salesperson': fake.name(),
        })

    df = pd.DataFrame(records)
    path = os.path.join(DATA_DIR, 'sales_data.csv')
    df.to_csv(path, index=False)
    print(f"✅ sales_data.csv saved ({len(df)} rows)")
    return df


# ─── 2. World Population Data ─────────────────────────────────────────────────
def generate_population_data():
    countries = {
        'China': 1412, 'India': 1407, 'USA': 334, 'Indonesia': 277,
        'Pakistan': 231, 'Brazil': 215, 'Nigeria': 218, 'Bangladesh': 169,
        'Russia': 144, 'Ethiopia': 123, 'Mexico': 128, 'Japan': 125,
        'Philippines': 114, 'Egypt': 105, 'DR Congo': 100,
    }
    continents = {
        'China': 'Asia', 'India': 'Asia', 'USA': 'Americas',
        'Indonesia': 'Asia', 'Pakistan': 'Asia', 'Brazil': 'Americas',
        'Nigeria': 'Africa', 'Bangladesh': 'Asia', 'Russia': 'Europe',
        'Ethiopia': 'Africa', 'Mexico': 'Americas', 'Japan': 'Asia',
        'Philippines': 'Asia', 'Egypt': 'Africa', 'DR Congo': 'Africa',
    }
    gdp_per_capita = {
        'China': 12720, 'India': 2389, 'USA': 76398, 'Indonesia': 4788,
        'Pakistan': 1505, 'Brazil': 10294, 'Nigeria': 2184, 'Bangladesh': 2688,
        'Russia': 15444, 'Ethiopia': 1020, 'Mexico': 10948, 'Japan': 42226,
        'Philippines': 3623, 'Egypt': 4295, 'DR Congo': 648,
    }
    life_expectancy = {
        'China': 77.1, 'India': 70.2, 'USA': 78.9, 'Indonesia': 71.7,
        'Pakistan': 67.3, 'Brazil': 75.9, 'Nigeria': 55.2, 'Bangladesh': 73.0,
        'Russia': 72.6, 'Ethiopia': 67.8, 'Mexico': 75.1, 'Japan': 84.3,
        'Philippines': 72.7, 'Egypt': 72.0, 'DR Congo': 61.2,
    }

    records = []
    for country, pop in countries.items():
        records.append({
            'country': country,
            'population_millions': pop,
            'continent': continents[country],
            'gdp_per_capita_usd': gdp_per_capita[country],
            'life_expectancy': life_expectancy[country],
        })

    df = pd.DataFrame(records)
    path = os.path.join(DATA_DIR, 'world_population.csv')
    df.to_csv(path, index=False)
    print(f"✅ world_population.csv saved ({len(df)} rows)")
    return df


# ─── 3. Stock Price Data ──────────────────────────────────────────────────────
def generate_stock_data():
    tickers = ['AAPL', 'GOOGL', 'MSFT', 'AMZN', 'TSLA']
    start_prices = {'AAPL': 150, 'GOOGL': 2800, 'MSFT': 280, 'AMZN': 3400, 'TSLA': 700}
    dates = pd.date_range(start='2023-01-01', periods=365, freq='B')

    records = []
    for ticker in tickers:
        price = start_prices[ticker]
        for date in dates:
            change = price * np.random.normal(0.0003, 0.018)
            price  = max(1, price + change)
            volume = int(np.random.uniform(5e6, 50e6))
            records.append({
                'date': date.strftime('%Y-%m-%d'),
                'ticker': ticker,
                'close': round(price, 2),
                'volume': volume,
            })

    df = pd.DataFrame(records)
    path = os.path.join(DATA_DIR, 'stock_prices.csv')
    df.to_csv(path, index=False)
    print(f"✅ stock_prices.csv saved ({len(df)} rows)")
    return df


if __name__ == '__main__':
    print("🔄 Generating datasets...\n")
    generate_sales_data()
    generate_population_data()
    generate_stock_data()
    print("\n🎉 All datasets ready in the data/ directory.")
