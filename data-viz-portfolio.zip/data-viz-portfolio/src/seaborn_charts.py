"""
seaborn_charts.py
-----------------
Creates 5 advanced statistical visualizations using Seaborn.

Charts:
  1. Heatmap  — correlation matrix across numeric features
  2. Pairplot — pairwise relationships (population dataset)
  3. Violin   — revenue distribution per category
  4. Facet Grid — monthly profit trends per region
  5. Regression Plot — GDP vs life expectancy (bubble chart)
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from utils import load_sales, load_population, save_fig

# ─── Seaborn dark theme ───────────────────────────────────────────────────────
sns.set_theme(style='darkgrid', palette='deep')
plt.rcParams.update({
    'figure.facecolor': '#0F172A',
    'axes.facecolor'  : '#1E293B',
    'text.color'      : '#F1F5F9',
    'axes.labelcolor' : '#CBD5E1',
    'axes.titlecolor' : '#F1F5F9',
    'xtick.color'     : '#94A3B8',
    'ytick.color'     : '#94A3B8',
    'grid.color'      : '#334155',
})
CMAP = 'coolwarm'


def chart1_heatmap(df):
    """Correlation heatmap of numeric features."""
    numeric = df[['units_sold', 'unit_price', 'discount', 'revenue', 'profit']]
    corr = numeric.corr()

    fig, ax = plt.subplots(figsize=(8, 6))
    mask = np.triu(np.ones_like(corr, dtype=bool))
    sns.heatmap(corr, mask=mask, annot=True, fmt='.2f',
                cmap=CMAP, center=0, linewidths=0.5,
                linecolor='#0F172A', ax=ax,
                annot_kws={'size': 11, 'color': 'white'})
    ax.set_title('Feature Correlation Matrix', fontsize=15, fontweight='bold', pad=12)
    plt.tight_layout()
    save_fig('07_correlation_heatmap.png')
    plt.close()


def chart2_violin(df):
    """Violin + strip plot: revenue distribution by category."""
    fig, ax = plt.subplots(figsize=(12, 7))
    order = df.groupby('category')['revenue'].median().sort_values(ascending=False).index

    sns.violinplot(data=df, x='category', y='revenue', order=order,
                   palette='muted', inner=None, alpha=0.7, ax=ax)
    sns.stripplot(data=df, x='category', y='revenue', order=order,
                  color='white', alpha=0.25, size=2.5, jitter=True, ax=ax)

    ax.set_title('Revenue Distribution by Product Category', fontsize=15, fontweight='bold')
    ax.set_xlabel('Category')
    ax.set_ylabel('Revenue ($)')
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v,_: f'${v:,.0f}'))
    plt.tight_layout()
    save_fig('08_violin_revenue_category.png')
    plt.close()


def chart3_facet_profit(df):
    """Facet grid: monthly profit trends per region."""
    df = df.copy()
    df['month'] = df['date'].dt.to_period('M').dt.to_timestamp()
    monthly = df.groupby(['month', 'region'])['profit'].sum().reset_index()

    g = sns.FacetGrid(monthly, col='region', col_wrap=2,
                      height=4, aspect=1.5,
                      sharey=False,
                      gridspec_kws={'hspace': 0.4, 'wspace': 0.3})
    g.map_dataframe(sns.lineplot, x='month', y='profit',
                    color='#2563EB', linewidth=2)
    g.map_dataframe(sns.scatterplot, x='month', y='profit',
                    color='#F59E0B', s=40, zorder=5)

    g.set_titles(col_template="{col_name} Region", size=12, fontweight='bold')
    g.set_axis_labels("Month", "Profit ($)")

    for ax in g.axes.flatten():
        ax.set_facecolor('#1E293B')
        ax.tick_params(labelrotation=30)
        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v,_: f'${v/1000:.0f}K'))

    g.figure.set_facecolor('#0F172A')
    g.figure.suptitle('Monthly Profit Trends by Region',
                       y=1.02, fontsize=15, fontweight='bold', color='#F1F5F9')
    save_fig('09_facet_profit_region.png')
    plt.close()


def chart4_bubble_gdp_life(pop):
    """Bubble scatter: GDP per capita vs life expectancy, sized by population."""
    continent_colors = {
        'Asia'    : '#2563EB',
        'Africa'  : '#16A34A',
        'Americas': '#DC2626',
        'Europe'  : '#D97706',
    }

    fig, ax = plt.subplots(figsize=(12, 7))
    for cont, grp in pop.groupby('continent'):
        scatter = ax.scatter(
            grp['gdp_per_capita_usd'],
            grp['life_expectancy'],
            s=grp['population_millions'] * 0.7,
            alpha=0.7,
            color=continent_colors.get(cont, '#94A3B8'),
            edgecolors='white', linewidths=0.5,
            label=cont,
            zorder=3,
        )
        for _, row in grp.iterrows():
            ax.annotate(row['country'],
                        (row['gdp_per_capita_usd'], row['life_expectancy']),
                        fontsize=7.5, color='#CBD5E1',
                        xytext=(4, 4), textcoords='offset points')

    ax.set_xscale('log')
    ax.set_xlabel('GDP per Capita (USD, log scale)')
    ax.set_ylabel('Life Expectancy (years)')
    ax.set_title('GDP per Capita vs Life Expectancy\n(bubble size = population)',
                 fontsize=14, fontweight='bold')
    ax.legend(title='Continent', loc='lower right')
    ax.grid(alpha=0.3, which='both')
    ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda v,_: f'${v:,.0f}'))
    plt.tight_layout()
    save_fig('10_bubble_gdp_life.png')
    plt.close()


def chart5_clustermap(df):
    """Clustermap: average revenue per region/category."""
    pivot = df.pivot_table(values='revenue', index='region',
                           columns='category', aggfunc='mean')

    g = sns.clustermap(pivot, cmap='Blues', annot=True, fmt='.0f',
                       figsize=(10, 6), linewidths=0.5,
                       linecolor='#0F172A',
                       dendrogram_ratio=0.12,
                       cbar_pos=(0.02, 0.8, 0.03, 0.18))
    g.fig.set_facecolor('#0F172A')
    g.ax_heatmap.set_facecolor('#1E293B')
    g.ax_heatmap.set_title('Avg Revenue: Region × Category',
                            fontsize=14, fontweight='bold', color='#F1F5F9', pad=12)
    save_fig('11_clustermap_region_category.png')
    plt.close()


if __name__ == '__main__':
    print("📊 Generating Seaborn charts...\n")
    df  = load_sales()
    pop = load_population()

    chart1_heatmap(df)
    chart2_violin(df)
    chart3_facet_profit(df)
    chart4_bubble_gdp_life(pop)
    chart5_clustermap(df)
    print("\n✅ All Seaborn charts saved to assets/")
