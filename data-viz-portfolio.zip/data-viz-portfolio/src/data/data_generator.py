"""
data_generator.py
=================
Synthetic dataset generator for all visualizations in the portfolio.
Produces realistic, structured data for sales, demographics, financials, and more.
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import random


# ─────────────────────────────────────────────
# Reproducibility
# ─────────────────────────────────────────────
SEED = 42
np.random.seed(SEED)
random.seed(SEED)


# ─────────────────────────────────────────────
# 1. Sales Performance Data
# ─────────────────────────────────────────────
def generate_sales_data(n_months: int = 36) -> pd.DataFrame:
    """
    Generate monthly sales data across regions, products, and channels.
    Returns a DataFrame suitable for time-series, bar, and KPI charts.
    """
    regions = ["North", "South", "East", "West", "Central"]
    products = ["Product A", "Product B", "Product C", "Product D"]
    channels = ["Online", "Retail", "Wholesale", "Direct"]

    start_date = datetime(2021, 1, 1)
    dates = [start_date + timedelta(days=30 * i) for i in range(n_months)]

    records = []
    for date in dates:
        for region in regions:
            for product in products:
                channel = random.choice(channels)
                base_sales = np.random.randint(50_000, 200_000)
                # Seasonal boost in Q4
                seasonal = 1.3 if date.month in [10, 11, 12] else 1.0
                trend = 1 + (date.year - 2021) * 0.08 + (date.month - 1) * 0.005
                noise = np.random.normal(1.0, 0.08)
                sales = int(base_sales * seasonal * trend * noise)
                units = int(sales / np.random.randint(50, 300))
                records.append({
                    "date": date,
                    "year": date.year,
                    "month": date.month,
                    "month_name": date.strftime("%b"),
                    "quarter": f"Q{(date.month - 1) // 3 + 1}",
                    "region": region,
                    "product": product,
                    "channel": channel,
                    "sales": sales,
                    "units": units,
                    "profit": int(sales * np.random.uniform(0.15, 0.35)),
                    "returns": int(units * np.random.uniform(0.01, 0.05)),
                })

    return pd.DataFrame(records)


# ─────────────────────────────────────────────
# 2. Customer Demographics Data
# ─────────────────────────────────────────────
def generate_customer_data(n: int = 1000) -> pd.DataFrame:
    """
    Generate synthetic customer demographic and behavioral data.
    Useful for scatter plots, histograms, and violin plots.
    """
    age = np.random.randint(18, 75, n)
    income = np.random.lognormal(mean=10.8, sigma=0.6, size=n).astype(int)
    income = np.clip(income, 20_000, 500_000)

    segments = np.random.choice(
        ["Premium", "Standard", "Basic", "Trial"],
        size=n, p=[0.15, 0.40, 0.30, 0.15]
    )
    genders = np.random.choice(["Male", "Female", "Non-binary"], size=n, p=[0.48, 0.48, 0.04])

    # Spend correlates with income + segment
    base_spend = income * np.random.uniform(0.01, 0.06, n)
    segment_mult = {"Premium": 2.5, "Standard": 1.0, "Basic": 0.5, "Trial": 0.1}
    spend = np.array([base_spend[i] * segment_mult[segments[i]] for i in range(n)])
    spend = np.clip(spend, 10, 50_000).astype(int)

    tenure = np.random.randint(1, 96, n)  # months
    satisfaction = np.clip(np.random.normal(3.8, 0.9, n), 1, 5).round(1)
    churn = (satisfaction < 2.5) | (np.random.rand(n) < 0.05)

    return pd.DataFrame({
        "customer_id": [f"CUST-{i:05d}" for i in range(n)],
        "age": age,
        "age_group": pd.cut(age, bins=[18, 25, 35, 45, 55, 65, 75],
                            labels=["18-24", "25-34", "35-44", "45-54", "55-64", "65+"]),
        "gender": genders,
        "income": income,
        "segment": segments,
        "annual_spend": spend,
        "tenure_months": tenure,
        "satisfaction_score": satisfaction,
        "churned": churn.astype(int),
        "city": np.random.choice(
            ["New York", "Los Angeles", "Chicago", "Houston", "Phoenix",
             "Philadelphia", "San Antonio", "San Diego", "Dallas", "Austin"],
            size=n
        ),
    })


# ─────────────────────────────────────────────
# 3. Financial / Stock-like Time Series
# ─────────────────────────────────────────────
def generate_stock_data(
    tickers: list = None,
    start_date: str = "2020-01-01",
    end_date: str = "2023-12-31"
) -> pd.DataFrame:
    """
    Generate simulated stock price data using geometric Brownian motion.
    Returns OHLCV-style DataFrame for line and candlestick charts.
    """
    if tickers is None:
        tickers = ["ALPHA", "BETA", "GAMMA", "DELTA"]

    date_range = pd.date_range(start=start_date, end=end_date, freq="B")  # business days
    records = []

    for ticker in tickers:
        price = np.random.uniform(50, 300)
        mu = np.random.uniform(0.0003, 0.0008)
        sigma = np.random.uniform(0.012, 0.025)

        for date in date_range:
            ret = np.random.normal(mu, sigma)
            price = max(price * (1 + ret), 1.0)
            high = price * np.random.uniform(1.001, 1.025)
            low = price * np.random.uniform(0.975, 0.999)
            open_p = np.random.uniform(low, high)
            volume = int(np.random.lognormal(14, 0.7))
            records.append({
                "date": date,
                "ticker": ticker,
                "open": round(open_p, 2),
                "high": round(high, 2),
                "low": round(low, 2),
                "close": round(price, 2),
                "volume": volume,
            })

    return pd.DataFrame(records)


# ─────────────────────────────────────────────
# 4. Correlation / Feature Matrix Data
# ─────────────────────────────────────────────
def generate_feature_data(n: int = 500) -> pd.DataFrame:
    """
    Generate a multi-feature dataset with controlled correlations.
    Perfect for heatmaps and scatter plot matrices.
    """
    x1 = np.random.normal(0, 1, n)
    x2 = 0.7 * x1 + 0.3 * np.random.normal(0, 1, n)   # highly correlated with x1
    x3 = -0.5 * x1 + np.random.normal(0, 1, n)          # negatively correlated
    x4 = np.random.normal(0, 1, n)                        # independent
    x5 = 0.4 * x2 + 0.6 * np.random.normal(0, 1, n)
    x6 = np.random.uniform(-3, 3, n)                      # uniform noise
    target = 2 * x1 - x3 + 0.5 * x5 + np.random.normal(0, 0.5, n)

    return pd.DataFrame({
        "Feature_A": x1,
        "Feature_B": x2,
        "Feature_C": x3,
        "Feature_D": x4,
        "Feature_E": x5,
        "Feature_F": x6,
        "Target": target,
    })


# ─────────────────────────────────────────────
# 5. Funnel / Conversion Data
# ─────────────────────────────────────────────
def generate_funnel_data() -> pd.DataFrame:
    """
    Generate marketing funnel data for funnel charts.
    """
    stages = ["Impressions", "Clicks", "Sign-ups", "Free Trial", "Paid Conversion", "Retained"]
    values = [1_000_000, 85_000, 22_000, 9_500, 3_200, 2_100]
    return pd.DataFrame({"stage": stages, "count": values})


# ─────────────────────────────────────────────
# 6. Geographic Sales Data (US States)
# ─────────────────────────────────────────────
def generate_geo_data() -> pd.DataFrame:
    """
    Generate US state-level sales data for choropleth maps.
    """
    state_abbrevs = [
        "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA",
        "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD",
        "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ",
        "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC",
        "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY"
    ]
    np.random.seed(SEED)
    sales = np.random.randint(100_000, 5_000_000, len(state_abbrevs))
    growth = np.random.uniform(-5, 25, len(state_abbrevs)).round(1)
    return pd.DataFrame({
        "state": state_abbrevs,
        "sales": sales,
        "growth_pct": growth,
        "customers": (sales / np.random.uniform(200, 800, len(state_abbrevs))).astype(int),
    })


# ─────────────────────────────────────────────
# 7. Radar / Spider Chart Data
# ─────────────────────────────────────────────
def generate_radar_data() -> dict:
    """
    Generate multi-metric comparison data for radar charts.
    Compares performance across business dimensions.
    """
    categories = ["Revenue", "Customer Satisfaction", "Market Share",
                  "Innovation", "Operational Efficiency", "Brand Strength"]
    companies = {
        "Company A": [85, 78, 72, 90, 65, 88],
        "Company B": [70, 88, 85, 65, 80, 75],
        "Company C": [90, 65, 68, 75, 90, 70],
    }
    return {"categories": categories, "companies": companies}


# ─────────────────────────────────────────────
# 8. Treemap Data
# ─────────────────────────────────────────────
def generate_treemap_data() -> pd.DataFrame:
    """
    Generate hierarchical product/category data for treemaps.
    """
    categories = {
        "Electronics": ["Smartphones", "Laptops", "Tablets", "Accessories", "Audio"],
        "Clothing": ["Men's", "Women's", "Kids'", "Sports", "Footwear"],
        "Home": ["Furniture", "Decor", "Kitchen", "Garden", "Bedding"],
        "Food": ["Beverages", "Snacks", "Fresh Produce", "Dairy", "Frozen"],
    }
    records = []
    for cat, subs in categories.items():
        for sub in subs:
            records.append({
                "category": cat,
                "subcategory": sub,
                "sales": np.random.randint(50_000, 800_000),
                "items": np.random.randint(10, 500),
            })
    return pd.DataFrame(records)


# ─────────────────────────────────────────────
# Convenience: load all datasets at once
# ─────────────────────────────────────────────
def load_all_datasets() -> dict:
    """Return a dictionary of all generated datasets."""
    return {
        "sales": generate_sales_data(),
        "customers": generate_customer_data(),
        "stocks": generate_stock_data(),
        "features": generate_feature_data(),
        "funnel": generate_funnel_data(),
        "geo": generate_geo_data(),
        "radar": generate_radar_data(),
        "treemap": generate_treemap_data(),
    }


if __name__ == "__main__":
    datasets = load_all_datasets()
    for name, df in datasets.items():
        if isinstance(df, pd.DataFrame):
            print(f"✅ {name:10s} → {df.shape[0]:,} rows × {df.shape[1]} cols")
        else:
            print(f"✅ {name:10s} → dict with keys: {list(df.keys())}")
